# ESCUDO DO MESTRE 🎲

Aplicativo Android pessoal de anotações para mestres de RPG.

## Primeira versão
- Tema escuro por padrão
- Cartões com miniaturas quadradas
- Criar, editar, excluir e pesquisar notas
- Marcadores por nota
- Campo de texto para registrar conexões entre notas
- Armazenamento local no aparelho
- Nome e ícone com tema D20

## Gerar APK
O GitHub Actions compila automaticamente ao enviar alterações para `main`.
Abra **Actions**, selecione **Build Android APK** e baixe o artefato `escudo-do-mestre-apk` quando a execução terminar.
