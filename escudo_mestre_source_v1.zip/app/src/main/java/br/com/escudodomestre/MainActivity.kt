package br.com.escudodomestre

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

private val Bg = Color(0xFF101010)
private val Card = Color(0xFF202020)
private val Ink = Color(0xFFF2F0EA)
private val Muted = Color(0xFFAAA69D)
private val Accent = Color(0xFFD6C9A8)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "",
    var body: String = "",
    var cover: String = "",
    var markers: String = "",
    var links: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp() }
    }
}

@Composable
fun EscudoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("escudo_notas", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }
    val type = remember { object : TypeToken<MutableList<Note>>() {}.type }
    val notes = remember {
        mutableStateListOf<Note>().apply {
            val saved = runCatching {
                gson.fromJson<MutableList<Note>>(prefs.getString("notes", "[]"), type)
            }.getOrNull()
            addAll(saved ?: mutableListOf())
        }
    }
    var search by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Note?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    fun saveNotes() {
        prefs.edit().putString("notes", gson.toJson(notes)).apply()
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            editing?.cover = it.toString()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Accent,
        onBackground = Ink, onSurface = Ink
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg)
                .statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Seu grimório de anotações", color = Muted, fontSize = 12.sp)
                }
                Text("◈ D20", color = Accent, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Pesquisar notas e marcadores") },
                singleLine = true, shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Minhas notas", color = Ink, fontSize = 19.sp,
                    fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("${notes.size} notas", color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))

            val filtered = notes.filter {
                it.title.contains(search, true) || it.markers.contains(search, true)
            }

            if (filtered.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎲", fontSize = 42.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (search.isBlank()) "Seu escudo está pronto." else "Nenhuma nota encontrada.",
                            color = Ink, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (search.isBlank()) "Crie sua primeira nota para começar." else "Tente outro título ou marcador.",
                            color = Muted, fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                .background(Card)
                                .clickable { editing = note.copy(); showEditor = true }
                                .padding(10.dp)
                        ) {
                            if (note.cover.isNotBlank()) {
                                AndroidView(
                                    factory = { ImageView(it).apply {
                                        scaleType = ImageView.ScaleType.CENTER_CROP
                                        setImageURI(Uri.parse(note.cover))
                                    } },
                                    update = { it.setImageURI(Uri.parse(note.cover)) },
                                    modifier = Modifier.fillMaxWidth().height(112.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                            } else {
                                Box(
                                    Modifier.fillMaxWidth().height(112.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF303030)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("D20", color = Accent, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                                }
                            }
                            Spacer(Modifier.height(9.dp))
                            Text(note.title.ifBlank { "Sem título" }, color = Ink,
                                fontWeight = FontWeight.SemiBold, maxLines = 2)
                            if (note.markers.isNotBlank()) {
                                Text(note.markers, color = Accent, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = { editing = Note(); showEditor = true },
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
            ) { Text("+ Nova nota", fontWeight = FontWeight.Bold) }
        }
    }

    if (showEditor && editing != null) {
        val note = editing!!
        Dialog(onDismissRequest = { showEditor = false }) {
            Surface(shape = RoundedCornerShape(20.dp), color = Card, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (notes.any { it.id == note.id }) "Editar nota" else "Nova nota",
                        color = Ink, fontWeight = FontWeight.Bold, fontSize = 19.sp
                    )
                    OutlinedTextField(note.title, { note.title = it }, label = { Text("Título") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(note.body, { note.body = it }, label = { Text("Anotação") }, modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp))
                    OutlinedTextField(note.markers, { note.markers = it }, label = { Text("Marcadores (separe por vírgula)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(note.links, { note.links = it }, label = { Text("Conectar com títulos de outras notas") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(
                        onClick = { imagePicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (note.cover.isBlank()) "Adicionar capa quadrada" else "Trocar capa") }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { showEditor = false }) { Text("Cancelar") }
                        Spacer(Modifier.weight(1f))
                        Button(
                            onClick = {
                                val index = notes.indexOfFirst { it.id == note.id }
                                if (index >= 0) notes[index] = note else notes.add(0, note)
                                saveNotes()
                                showEditor = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                        ) { Text("Salvar") }
                    }
                    if (notes.any { it.id == note.id }) {
                        TextButton(onClick = {
                            notes.removeAll { it.id == note.id }
                            saveNotes()
                            showEditor = false
                        }) { Text("Excluir nota", color = Color(0xFFFF7777)) }
                    }
                }
            }
        }
    }
}
