# ESCUDO DO MESTRE 1.10

Atualização corretiva do editor de notas.

## Correção principal
- As imagens inseridas no texto deixam de ser desenhadas pelo callback de margem de cada linha.
- A margem lateral continua reservada pelo `LeadingMarginSpan2`, mantendo o texto ao lado da imagem.
- Cada imagem é pintada uma única vez no `NoteEditText.onDraw`, ancorada na primeira linha do parágrafo.
- Isso evita a repetição em faixas/fragmentos da imagem que aparecia durante a digitação.

Mantém o identificador Android `br.com.escudodomestre` e incrementa `versionCode` para 11 (`versionName` 1.10).
