# ESCUDO DO MESTRE 1.11

Versão Android do bloco de notas para campanhas de RPG.

## Correção desta versão
- A duração do contorno lateral de imagens passa a ser calculada com a altura real de linha do próprio EditText, depois da configuração tipográfica e do estilo do papel.
- Isso corrige o recuo lateral que persistia algumas linhas abaixo da imagem em determinados aparelhos/fontes.
- Mantém o identificador do aplicativo e os dados locais das versões anteriores.

## Compilar
Use o workflow `.github/workflows/android.yml` no GitHub Actions.
