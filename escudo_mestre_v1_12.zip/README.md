# ESCUDO DO MESTRE 1.12

Atualização do editor de notas para campanhas de RPG.

## Correção desta versão
- Corrigido o recuo lateral das imagens inseridas no texto.
- O espaço lateral é reservado somente durante as primeiras linhas correspondentes à altura da imagem.
- Depois da base da imagem, o texto volta a ocupar a largura completa da página.
- Mantém o desenho único da imagem, o fluxo de texto e as funcionalidades anteriores.
- Mantém o identificador do aplicativo e os dados locais das versões anteriores.

## Compilar
Use o workflow `.github/workflows/android.yml` no GitHub Actions.
