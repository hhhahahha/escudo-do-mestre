# ESCUDO DO MESTRE 1.13

Aplicativo Android pessoal de anotações para campanhas de RPG.

## Correção nesta versão

Ajusta o fluxo de texto ao redor das imagens incorporadas. O editor agora mede a altura real das linhas após o layout do Android e atualiza dinamicamente quantas linhas devem reservar a coluna lateral da imagem. Assim, quando o texto ultrapassa a borda inferior da imagem, as linhas seguintes voltam a utilizar toda a largura da página.

## Compilação

O projeto usa Java 17 e Gradle 8.9. O workflow de GitHub Actions está em `.github/workflows/android.yml` e produz `app-debug.apk` como artefato.

## Compatibilidade

O identificador do aplicativo foi mantido para permitir a atualização sobre a instalação existente. `versionCode` 14 e `versionName` 1.13.
