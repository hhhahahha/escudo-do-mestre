# ESCUDO DO MESTRE 1.14

Correção do fluxo de texto ao redor de imagens. O editor aplica margens independentes a cada parágrafo que cruza a altura da imagem e remove a margem dos parágrafos abaixo dela, medindo a posição real das linhas no layout Android.

- Application ID: `br.com.escudodomestre`
- versionCode: `15`
- versionName: `1.14`
- Build: GitHub Actions, Java 17 e Gradle 8.9
