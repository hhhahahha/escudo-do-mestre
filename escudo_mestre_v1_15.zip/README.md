# ESCUDO DO MESTRE 1.15

Correção do fluxo de texto ao redor de imagens no editor. As margens de texto agora notificam o TextView por meio de `UpdateLayout` quando a quantidade de linhas laterais muda, forçando a reconstrução do layout sem substituir o `Editable` nem reposicionar o cursor. Parágrafos posteriores começam sem margem lateral e recebem margem somente quando a medição real do layout confirma que ainda cruzam a altura da imagem.

- Application ID: `br.com.escudodomestre`
- versionCode: `16`
- versionName: `1.15`
- Build: GitHub Actions, Java 17 e Gradle 8.9
