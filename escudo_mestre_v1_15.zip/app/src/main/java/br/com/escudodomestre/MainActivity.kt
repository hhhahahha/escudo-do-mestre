package br.com.escudodomestre

import android.content.Context
import android.graphics.Matrix
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.EditText
import android.graphics.drawable.Drawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.Spanned
import android.text.style.ReplacementSpan
import android.text.style.LeadingMarginSpan
import android.text.style.UpdateLayout
import android.text.Layout
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.text.InputType
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Label
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.UUID
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF191919)
private val Card = Color(0xFF202020)
private val CardRaised = Color(0xFF282828)
private val Ink = Color(0xFFF2F0EA)
private val Muted = Color(0xFFAAA69D)
private val Accent = Color(0xFFD6C9A8)
private val Danger = Color(0xFFE58A82)
private const val TRASH_RETENTION_MS = 7L * 24L * 60L * 60L * 1000L

/**
 * Keep the old field names and String representation for markers/links so notes
 * created by version 1.0 remain readable after updating the APK.
 */
data class NoteBlock(
    val id: String = UUID.randomUUID().toString(),
    // "text" or "image". Flat fields keep Gson migration straightforward.
    val kind: String = "text",
    val text: String = "",
    val image: String = "",
    val imageWidthFraction: Float = 1f,
    val imageScale: Float = 1f,
    val imageOffsetX: Float = 0f,
    val imageOffsetY: Float = 0f,
    val imageAspectRatio: Float = 1.7778f
)

data class NotePage(
    val id: String = UUID.randomUUID().toString(),
    val body: String = "",
    val image: String = "",
    val imageScale: Float = 1f,
    val imageOffsetX: Float = 0f,
    val imageOffsetY: Float = 0f,
    val imageAspectRatio: Float = 1.7778f,
    val blocks: List<NoteBlock> = emptyList()
)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val cover: String = "",
    val markers: String = "",
    val links: String = "",
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val coverScale: Float = 1f,
    val coverOffsetX: Float = 0f,
    val coverOffsetY: Float = 0f,
    val coverAspectRatio: Float = 1.7778f,
    val pages: List<NotePage> = emptyList(),
    // 0 = active note; otherwise epoch millis when moved to the trash.
    val deletedAt: Long = 0L,
    // Paper appearance is shared by all numbered pages in the same note.
    val paperTone: String = "black",
    val paperStyle: String = "blank"
)

/** ZIP backup keeps note data and the actual image bytes together, so restored images
 * do not depend on gallery URIs from the old installation. */
data class NotesBackup(
    val formatVersion: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: List<Note> = emptyList(),
    val markers: List<String> = emptyList()
)

private fun exportNotesBackup(
    context: Context,
    destination: Uri,
    notes: List<Note>,
    markers: List<String>,
    gson: Gson
) {
    val imageEntries = linkedMapOf<String, String>()
    fun archiveImageReference(value: String): String {
        if (value.isBlank()) return value
        return imageEntries.getOrPut(value) { "media/image_${imageEntries.size + 1}.bin" }
    }

    val portableNotes = notes.map { note ->
        note.copy(
            cover = archiveImageReference(note.cover),
            pages = note.pages.orEmpty().map { page ->
                page.copy(
                    image = archiveImageReference(page.image),
                    blocks = page.blocks.orEmpty().map { block ->
                        if (block.kind == "image") block.copy(image = archiveImageReference(block.image)) else block
                    }
                )
            }
        )
    }
    val backup = NotesBackup(notes = portableNotes, markers = markers)
    val output = context.contentResolver.openOutputStream(destination)
        ?: error("Não foi possível abrir o destino do backup.")

    ZipOutputStream(BufferedOutputStream(output)).use { zip ->
        zip.putNextEntry(ZipEntry("backup.json"))
        zip.write(gson.toJson(backup).toByteArray(Charsets.UTF_8))
        zip.closeEntry()

        imageEntries.forEach { (sourceUri, archivePath) ->
            val input = context.contentResolver.openInputStream(Uri.parse(sourceUri))
                ?: error("Não foi possível ler uma imagem da nota. Tente selecionar a imagem novamente antes do backup.")
            zip.putNextEntry(ZipEntry(archivePath))
            input.use { it.copyTo(zip) }
            zip.closeEntry()
        }
    }
}

private fun importNotesBackup(
    context: Context,
    source: Uri,
    gson: Gson
): NotesBackup {
    val root = File(context.filesDir, "restored-backup-media/${UUID.randomUUID()}").apply { mkdirs() }
    val restoredMedia = mutableMapOf<String, String>()
    var manifest: String? = null
    val input = context.contentResolver.openInputStream(source)
        ?: error("Não foi possível abrir o arquivo de backup.")

    ZipInputStream(BufferedInputStream(input)).use { zip ->
        var entry = zip.nextEntry
        while (entry != null) {
            val name = entry.name.replace('\\', '/')
            when {
                name == "backup.json" -> {
                    manifest = zip.readBytes().toString(Charsets.UTF_8)
                }
                name.startsWith("media/") && !name.contains("..") && !entry.isDirectory -> {
                    val fileName = name.substringAfterLast('/')
                    val outFile = File(root, fileName)
                    outFile.outputStream().buffered().use { zip.copyTo(it) }
                    restoredMedia[name] = Uri.fromFile(outFile).toString()
                }
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }
    }

    val json = manifest ?: error("Este arquivo não contém um backup válido do ESCUDO DO MESTRE.")
    val parsed = gson.fromJson(json, NotesBackup::class.java)
        ?: error("Não foi possível interpretar o backup.")
    if (parsed.formatVersion != 1) error("A versão deste backup não é compatível com este aplicativo.")

    fun restoreImage(value: String): String = restoredMedia[value] ?: value
    val restoredNotes = parsed.notes.map { note ->
        note.copy(
            cover = restoreImage(note.cover),
            pages = note.pages.orEmpty().map { page ->
                page.copy(
                    image = restoreImage(page.image),
                    blocks = page.blocks.orEmpty().map { block ->
                        if (block.kind == "image") block.copy(image = restoreImage(block.image)) else block
                    }
                )
            }
        )
    }
    return parsed.copy(notes = restoredNotes)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp() }
    }
}

private fun splitValues(raw: String): List<String> = raw
    .split(',', '\n')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .distinctBy { it.lowercase() }

private fun parseIds(raw: String): Set<String> = raw
    .split(',')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .toSet()

private fun safeScale(note: Note): Float = note.coverScale.takeIf { it >= 1f } ?: 1f

private fun safeAspectRatio(value: Float, fallback: Float = 1.7778f): Float =
    (value.takeIf { it.isFinite() && it > 0.05f } ?: fallback).coerceIn(0.25f, 4f)

private fun collapseAdjacentTextBlocks(source: List<NoteBlock>): List<NoteBlock> {
    val result = mutableListOf<NoteBlock>()
    source.forEach { block ->
        val previous = result.lastOrNull()
        if (block.kind != "image" && previous != null && previous.kind != "image") {
            val separator = if (previous.text.isNotEmpty() && block.text.isNotEmpty()) "\n\n" else ""
            result[result.lastIndex] = previous.copy(text = previous.text + separator + block.text)
        } else {
            result.add(block)
        }
    }
    if (result.isEmpty()) result.add(NoteBlock())
    if (result.last().kind == "image") result.add(NoteBlock())
    return result
}

private fun normalizePageBlocks(page: NotePage): List<NoteBlock> {
    val saved = page.blocks.orEmpty()
    if (saved.isNotEmpty()) {
        val normalized = saved.map { block ->
            if (block.kind == "image") block.copy(
                imageWidthFraction = block.imageWidthFraction.takeIf { it.isFinite() }?.coerceIn(0.15f, 1f) ?: 1f,
                imageScale = block.imageScale.takeIf { it.isFinite() && it >= 1f } ?: 1f,
                imageAspectRatio = safeAspectRatio(block.imageAspectRatio)
            ) else block
        }
        return collapseAdjacentTextBlocks(normalized)
    }
    return listOf(NoteBlock(text = page.body))
}

/** Native editor that keeps notebook guides aligned to the actual text baselines. */
private class NoteEditText(context: Context) : EditText(context) {
    var applyingModel: Boolean = false
    var renderedVersion: Int = -1
    var paperStyle: String = "blank"
    var paperTone: String = "black"
    var paperStepPx: Float = 0f
    private var imageMarginReflowPosted: Boolean = false

    /**
     * Recalculate the wrap height from the real TextView layout, not from a
     * guessed line-height. TextView.getLineHeight() can differ from the actual
     * laid-out baselines (font padding, line spacing, accessibility font scale,
     * and OEM text metrics all affect it). When the estimate is too large, the
     * text remains trapped in the side column below the image.
     *
     * We count only visual lines whose top is still above the image bottom.
     * This also grows the margin as the user types more text next to a tall image.
     */
    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        updateImageFlowLineCounts()
    }

    private fun updateImageFlowLineCounts() {
        if (imageMarginReflowPosted) return
        val textLayout = layout ?: return
        // Editable is required because changing a custom span's internal line
        // count does not, by itself, notify TextView that its cached StaticLayout
        // is stale. We re-attach the UpdateLayout span below so TextView rebuilds
        // the paragraph layout without replacing the Editable or disturbing IME
        // composing text / cursor position.
        val editable = text as? Editable ?: return
        if (editable.isEmpty() || textLayout.lineCount <= 0) return

        var needsReflow = false
        val spans = editable.getSpans(0, editable.length, ImageFlowMarginSpan::class.java)
        spans.forEach { span ->
            // The image anchor is a real span, so its offset follows the cursor as
            // the user inserts or deletes text before the picture.
            val imageOffset = editable.getSpanStart(span.imageAnchor)
            val paragraphStart = editable.getSpanStart(span)
            val paragraphEnd = editable.getSpanEnd(span)
            if (imageOffset < 0 || paragraphStart < 0 || paragraphEnd <= paragraphStart) return@forEach

            val imageLine = textLayout.getLineForOffset(imageOffset.coerceIn(0, editable.length - 1))
                .coerceIn(0, textLayout.lineCount - 1)
            val imageTop = textLayout.getLineTop(imageLine)
            val imageBottom = imageTop + span.imageHeightPx

            // The span is paragraph-scoped. Count only this paragraph's visual
            // lines whose vertical boxes intersect the image rectangle. Since
            // imageBottom is absolute in the TextView layout, later paragraphs
            // naturally receive zero lines once they begin below the image.
            val firstLine = textLayout.getLineForOffset(paragraphStart)
                .coerceIn(0, textLayout.lineCount - 1)
            val lastOffset = (paragraphEnd - 1).coerceIn(paragraphStart, editable.length - 1)
            val lastLine = textLayout.getLineForOffset(lastOffset)
                .coerceIn(firstLine, textLayout.lineCount - 1)

            var occupiedLines = 0
            for (line in firstLine..lastLine) {
                val lineTop = textLayout.getLineTop(line)
                val lineBottom = textLayout.getLineBottom(line)
                if (lineTop >= imageBottom) break
                if (lineTop < imageBottom && lineBottom > imageTop) occupiedLines++
            }

            if (span.updateLineCount(occupiedLines)) {
                // LeadingMarginSpan2 values are read when TextView builds its
                // layout. Merely calling requestLayout() leaves TextView's cached
                // StaticLayout unchanged. Remove/re-add this UpdateLayout span to
                // fire TextView's SpanWatcher and force a true text reflow. The
                // Editable itself is retained, so selection and typing continue.
                val start = editable.getSpanStart(span)
                val end = editable.getSpanEnd(span)
                val flags = editable.getSpanFlags(span)
                if (start >= 0 && end > start) {
                    editable.removeSpan(span)
                    editable.setSpan(span, start, end, flags)
                    needsReflow = true
                }
            }
        }

        if (needsReflow && !imageMarginReflowPosted) {
            imageMarginReflowPosted = true
            post {
                imageMarginReflowPosted = false
                requestLayout()
                invalidate()
            }
        }
    }

    override fun onDraw(canvas: AndroidCanvas) {
        if (paperStyle == "ruled" || paperStyle == "grid") {
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = resources.displayMetrics.density * 0.7f
                color = if (paperTone == "white") {
                    android.graphics.Color.argb(58, 35, 35, 35)
                } else {
                    android.graphics.Color.argb(66, 235, 235, 235)
                }
            }
            val step = paperStepPx.takeIf { it > 0f } ?: (26f * resources.displayMetrics.density)
            val textLayout = layout
            val firstBaseline = if (textLayout != null && textLayout.lineCount > 0) {
                textLayout.getLineBaseline(0).toFloat()
            } else {
                -paint.fontMetrics.ascent
            }

            var y = firstBaseline
            while (y < height + step) {
                if (y >= 0f) canvas.drawLine(paddingLeft.toFloat(), y, (width - paddingRight).toFloat(), y, linePaint)
                y += step
            }

            if (paperStyle == "grid") {
                var x = paddingLeft.toFloat()
                while (x <= width - paddingRight) {
                    canvas.drawLine(x, 0f, x, height.toFloat(), linePaint)
                    x += step
                }
            }
        }

        // Draw the text first. The inline-image margin span only reserves the text
        // column; drawing the bitmap from drawLeadingMargin caused Android to clip
        // and replay the top strip once per visual line. Paint each image exactly
        // once here, anchored to the first text line of its paragraph.
        super.onDraw(canvas)
        val editable = text as? Spanned ?: return
        val textLayout = layout ?: return
        val imageSpans = editable.getSpans(0, editable.length, NoteInlineImageSpan::class.java)
        imageSpans.forEach { span ->
            val spanStart = editable.getSpanStart(span)
            if (spanStart < 0 || spanStart >= editable.length) return@forEach
            val line = textLayout.getLineForOffset(spanStart)
            val direction = textLayout.getParagraphDirection(line)
            val imageWidth = span.drawable.bounds.width()
            val imageHeight = span.drawable.bounds.height()
            val left = if (direction >= 0) {
                compoundPaddingLeft - scrollX
            } else {
                width - compoundPaddingRight - imageWidth + scrollX
            }
            val top = extendedPaddingTop + textLayout.getLineTop(line) - scrollY
            val right = left + imageWidth
            val bottom = top + imageHeight
            if (right <= 0 || left >= width || bottom <= 0 || top >= height) return@forEach

            val save = canvas.save()
            canvas.clipRect(0, 0, width, height)
            canvas.translate(left.toFloat(), top.toFloat())
            span.drawable.setBounds(0, 0, imageWidth, imageHeight)
            span.drawable.draw(canvas)
            canvas.restoreToCount(save)
        }
    }
}

/** Zero-width anchor: the image itself is painted in the paragraph's leading margin. */
private class NoteInlineImageSpan(val block: NoteBlock, val drawable: Drawable) : ReplacementSpan() {
    override fun getSize(
        paint: Paint,
        text: CharSequence,
        start: Int,
        end: Int,
        fm: Paint.FontMetricsInt?
    ): Int = 0

    override fun draw(
        canvas: AndroidCanvas,
        text: CharSequence,
        start: Int,
        end: Int,
        x: Float,
        top: Int,
        y: Int,
        bottom: Int,
        paint: Paint
    ) = Unit
}

/**
 * Floats the image in the paragraph's left margin. Text receives the remaining
 * column beside the image, then expands to the full width after its height ends.
 */
private class ImageFlowMarginSpan(
    val imageAnchor: NoteInlineImageSpan,
    val imageWidthPx: Int,
    val imageHeightPx: Int,
    initialImageLineCount: Int,
    private val gapPx: Int
) : LeadingMarginSpan.LeadingMarginSpan2, UpdateLayout {
    @Volatile
    private var measuredImageLineCount: Int = initialImageLineCount.coerceAtLeast(0)

    /** Returns true only when the layout must be recalculated. */
    val currentImageLineCount: Int
        get() = measuredImageLineCount

    fun updateLineCount(value: Int): Boolean {
        val safeValue = value.coerceAtLeast(0)
        if (measuredImageLineCount == safeValue) return false
        measuredImageLineCount = safeValue
        return true
    }

    // LeadingMarginSpan2 marks only the first N visual lines as `first=true`.
    // The count is continuously measured from the actual layout, so the next
    // line after the image bottom returns to the full page width.
    override fun getLeadingMargin(first: Boolean): Int =
        if (first) imageWidthPx + gapPx else 0

    override fun getLeadingMarginLineCount(): Int = measuredImageLineCount

    override fun drawLeadingMargin(
        c: AndroidCanvas,
        p: Paint,
        x: Int,
        dir: Int,
        top: Int,
        baseline: Int,
        bottom: Int,
        text: CharSequence,
        start: Int,
        end: Int,
        first: Boolean,
        layout: Layout
    ) {
        // Intentionally empty. The bitmap is painted once by NoteEditText.onDraw;
        // LeadingMarginSpan only controls how many lines reserve the side column.
    }
}

private fun configurePaperEditor(edit: NoteEditText, style: String, tone: String) {
    edit.paperStyle = style
    edit.paperTone = tone
    val step = 26f * edit.resources.displayMetrics.density
    edit.paperStepPx = step
    if (style == "ruled" || style == "grid") {
        val metrics = edit.paint.fontMetrics
        val fontHeight = metrics.descent - metrics.ascent
        edit.setLineSpacing((step - fontHeight).coerceAtLeast(0f), 1f)
    } else {
        edit.setLineSpacing(0f, 1.25f)
    }
    edit.invalidate()
}

private fun loadInlineDrawable(context: Context, block: NoteBlock, availableWidthPx: Int): Drawable? {
    return runCatching {
        val uri = Uri.parse(block.image)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
        val targetWidth = (availableWidthPx * block.imageWidthFraction.coerceIn(0.15f, 1f)).toInt().coerceAtLeast(72)
        val targetHeight = (targetWidth / safeAspectRatio(block.imageAspectRatio)).toInt().coerceAtLeast(48)
        var sample = 1
        while (bounds.outWidth / sample > targetWidth * 2 || bounds.outHeight / sample > targetHeight * 2) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: return@runCatching null
        BitmapDrawable(context.resources, bitmap).apply { setBounds(0, 0, targetWidth, targetHeight) }
    }.getOrNull()
}

private fun blocksToEditable(
    context: Context,
    blocks: List<NoteBlock>,
    availableWidthPx: Int,
    actualLineHeightPx: Int
): SpannableStringBuilder {
    val builder = SpannableStringBuilder()
    val flowImages = mutableListOf<Triple<Int, NoteBlock, NoteInlineImageSpan>>()
    collapseAdjacentTextBlocks(blocks).forEach { block ->
        if (block.kind == "image") {
            // A float starts a new paragraph. Following text shares the free column
            // at the right until the image's bottom, then returns to full width.
            if (builder.isNotEmpty() && builder.last() != '\n') builder.append('\n')
            val start = builder.length
            builder.append('\uFFFC')
            val drawable = loadInlineDrawable(context, block, availableWidthPx)
            if (drawable != null) {
                val imageAnchor = NoteInlineImageSpan(block, drawable)
                builder.setSpan(imageAnchor, start, start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                flowImages.add(Triple(start, block, imageAnchor))
            } else {
                builder.replace(start, start + 1, "[imagem indisponível]")
            }
        } else {
            builder.append(block.text)
        }
    }

    val density = context.resources.displayMetrics.density
    // Seed the span with an estimate. NoteEditText.onLayout replaces this with
    // a count measured from the actual visual line positions before the final draw.
    val lineHeight = actualLineHeightPx.coerceAtLeast((14f * density).toInt().coerceAtLeast(1))
    val gapPx = (7f * density).toInt().coerceAtLeast(1)

    val orderedImages = flowImages.sortedBy { it.first }
    orderedImages.forEachIndexed { imageIndex, (imageStart, _, imageAnchor) ->
        val drawable = imageAnchor.drawable
        val nextImageStart = orderedImages.getOrNull(imageIndex + 1)?.first ?: builder.length
        val imageHeight = drawable.bounds.height()
        val estimatedLineCount = kotlin.math.ceil(imageHeight.toFloat() / lineHeight.toFloat())
            .toInt().coerceAtLeast(1)

        // LeadingMarginSpan2 is paragraph-scoped on Android. Applying one span
        // only to the paragraph where the image anchor lives makes later text
        // paragraphs jump to inconsistent columns. Attach a companion span to
        // every paragraph up to the next image, then measure each paragraph's
        // actual vertical overlap with the image in NoteEditText.onLayout().
        var paragraphStart = imageStart
        var firstParagraph = true
        while (paragraphStart < nextImageStart && paragraphStart < builder.length) {
            val newline = builder.indexOf("\n", paragraphStart)
            val paragraphEnd = if (newline >= 0 && newline < nextImageStart) {
                newline + 1
            } else {
                nextImageStart
            }
            if (paragraphEnd <= paragraphStart) break

            builder.setSpan(
                ImageFlowMarginSpan(
                    imageAnchor = imageAnchor,
                    imageWidthPx = drawable.bounds.width(),
                    imageHeightPx = imageHeight,
                    // Later paragraphs begin with no side margin. The first real
                    // TextView layout determines whether they still intersect the
                    // image; onLayout then activates only the lines that overlap.
                    // Seeding them with one line traps paragraphs below tall images
                    // when OEM TextView layout does not invalidate cached spans.
                    initialImageLineCount = if (firstParagraph) estimatedLineCount else 0,
                    gapPx = gapPx
                ),
                paragraphStart,
                paragraphEnd,
                Spanned.SPAN_PARAGRAPH
            )
            paragraphStart = paragraphEnd
            firstParagraph = false
        }
    }
    return builder
}

private fun editableToBlocks(editable: Editable): List<NoteBlock> {
    val spans = editable.getSpans(0, editable.length, NoteInlineImageSpan::class.java)
        .sortedBy { editable.getSpanStart(it) }
    if (spans.isEmpty()) return listOf(NoteBlock(text = editable.toString()))

    val result = mutableListOf<NoteBlock>()
    var cursor = 0
    spans.forEach { span ->
        val start = editable.getSpanStart(span).coerceIn(cursor, editable.length)
        val end = editable.getSpanEnd(span).coerceIn(start, editable.length)
        if (start > cursor) result.add(NoteBlock(text = editable.subSequence(cursor, start).toString()))
        if (end > start) result.add(span.block)
        cursor = end
    }
    if (cursor < editable.length) result.add(NoteBlock(text = editable.subSequence(cursor, editable.length).toString()))
    return collapseAdjacentTextBlocks(result)
}

private fun caretOffsetAfterImage(blocks: List<NoteBlock>, imageId: String): Int {
    var offset = 0
    var previousCharacter: Char? = null
    blocks.forEach { block ->
        if (block.kind == "image") {
            if (offset > 0 && previousCharacter != '\n') offset += 1 // synthetic paragraph break added by blocksToEditable
            if (block.id == imageId) return offset + 1
            offset += 1
            previousCharacter = '\uFFFC'
        } else {
            offset += block.text.length
            if (block.text.isNotEmpty()) previousCharacter = block.text.last()
        }
    }
    return offset
}

private fun locateTextBlockAtCursor(blocks: List<NoteBlock>, cursorPosition: Int): Pair<String, Int>? {
    var remaining = cursorPosition.coerceAtLeast(0)
    blocks.forEach { block ->
        if (block.kind == "image") {
            remaining = (remaining - 1).coerceAtLeast(0)
        } else {
            if (remaining <= block.text.length) return block.id to remaining
            remaining -= block.text.length
        }
    }
    val lastText = blocks.lastOrNull { it.kind != "image" } ?: return null
    return lastText.id to lastText.text.length
}

private fun pageBodyFromBlocks(blocks: List<NoteBlock>): String =
    blocks.filter { it.kind != "image" }.joinToString("\n\n") { it.text }

private fun normalizePages(note: Note): List<NotePage> {
    val stored = note.pages.orEmpty()
    if (stored.isNotEmpty()) {
        return stored.map { page ->
            val normalizedBlocks = normalizePageBlocks(page)
            page.copy(
                imageScale = page.imageScale.takeIf { it >= 1f } ?: 1f,
                imageAspectRatio = safeAspectRatio(page.imageAspectRatio),
                blocks = normalizedBlocks,
                body = pageBodyFromBlocks(normalizedBlocks)
            )
        }
    }
    // Migration for notes created before numbered pages existed.
    val firstBlocks = listOf(NoteBlock(text = note.body))
    return listOf(
        NotePage(
            body = note.body,
            image = note.cover,
            imageScale = note.coverScale.takeIf { it >= 1f } ?: 1f,
            imageOffsetX = note.coverOffsetX,
            imageOffsetY = note.coverOffsetY,
            imageAspectRatio = safeAspectRatio(note.coverAspectRatio),
            blocks = firstBlocks
        )
    )
}

private fun readImageAspectRatio(context: Context, uri: Uri): Float {
    return runCatching {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        if (options.outWidth > 0 && options.outHeight > 0) {
            safeAspectRatio(options.outWidth.toFloat() / options.outHeight.toFloat())
        } else 1.7778f
    }.getOrDefault(1.7778f)
}

private fun applyCoverMatrix(view: ImageView, scale: Float, offsetX: Float, offsetY: Float) {
    val drawable = view.drawable ?: return
    val viewW = view.width.toFloat()
    val viewH = view.height.toFloat()
    val imageW = drawable.intrinsicWidth.toFloat()
    val imageH = drawable.intrinsicHeight.toFloat()
    if (viewW <= 0f || viewH <= 0f || imageW <= 0f || imageH <= 0f) return

    val fit = max(viewW / imageW, viewH / imageH)
    val finalScale = fit * scale.coerceAtLeast(1f)
    val drawnW = imageW * finalScale
    val drawnH = imageH * finalScale
    val tx = (viewW - drawnW) / 2f + offsetX * viewW
    val ty = (viewH - drawnH) / 2f + offsetY * viewH
    val matrix = Matrix().apply {
        setScale(finalScale, finalScale)
        postTranslate(tx, ty)
    }
    view.imageMatrix = matrix
}

@Composable
fun EscudoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("escudo_notas", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }
    val noteType = remember { object : TypeToken<List<Note>>() {}.type }
    val markerType = remember { object : TypeToken<List<String>>() {}.type }

    val notes = remember {
        mutableStateListOf<Note>().apply {
            val loaded = runCatching {
                gson.fromJson<List<Note>>(prefs.getString("notes", "[]"), noteType)
            }.getOrNull().orEmpty()
            val cutoff = System.currentTimeMillis() - TRASH_RETENTION_MS
            val retained = loaded.filter { it.deletedAt <= 0L || it.deletedAt > cutoff }
            val normalized = retained.map { old ->
                // Keep notes from older APKs readable while introducing numbered pages.
                val normalizedPages = normalizePages(old)
                old.copy(
                    coverScale = safeScale(old),
                    pages = normalizedPages,
                    body = normalizedPages.firstOrNull()?.body ?: old.body,
                    cover = normalizedPages.firstOrNull()?.image ?: old.cover,
                    coverAspectRatio = normalizedPages.firstOrNull()?.imageAspectRatio
                        ?: safeAspectRatio(old.coverAspectRatio)
                )
            }
            addAll(normalized)
            if (normalized.size != loaded.size) {
                prefs.edit().putString("notes", gson.toJson(normalized)).apply()
            }
        }
    }
    val savedMarkers = remember {
        mutableStateListOf<String>().apply {
            val fromPrefs = runCatching {
                gson.fromJson<List<String>>(prefs.getString("saved_markers", "[]"), markerType)
            }.getOrNull().orEmpty()
            val fromNotes = notes.flatMap { splitValues(it.markers) }
            addAll((fromPrefs + fromNotes).distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
        }
    }

    var search by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var showingArchived by remember { mutableStateOf(false) }
    var showingTrash by remember { mutableStateOf(false) }
    var activeMarker by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<NotesBackup?>(null) }

    val backupCreator = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            val result = runCatching { exportNotesBackup(context, uri, notes.toList(), savedMarkers.toList(), gson) }
            backupMessage = result.fold(
                { "Backup criado com ${notes.size} ficha(s), incluindo imagens. No seletor de arquivos, escolha Google Drive para guardar na nuvem. O backup é manual: faça um novo quando quiser atualizar a cópia." },
                { "Não foi possível criar o backup: ${it.message ?: "erro ao gravar arquivo"}" }
            )
        }
    }
    val backupRestorer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val result = runCatching { importNotesBackup(context, uri, gson) }
            result.onSuccess { pendingRestore = it }
                .onFailure { backupMessage = "Não foi possível restaurar: ${it.message ?: "arquivo inválido"}" }
        }
    }

    fun purgeExpiredTrash() {
        val cutoff = System.currentTimeMillis() - TRASH_RETENTION_MS
        val expiredIds = notes.filter { it.deletedAt > 0L && it.deletedAt <= cutoff }
            .map { it.id }.toSet()
        if (expiredIds.isEmpty()) return
        notes.removeAll { it.id in expiredIds }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in expiredIds }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
    }

    fun persist() {
        purgeExpiredTrash()
        prefs.edit()
            .putString("notes", gson.toJson(notes))
            .putString("saved_markers", gson.toJson(savedMarkers))
            .apply()
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            purgeExpiredTrash()
            prefs.edit().putString("notes", gson.toJson(notes)).apply()
        }
    }

    fun registerMarker(value: String) {
        val clean = value.trim().removePrefix("#")
        if (clean.isNotEmpty() && savedMarkers.none { it.equals(clean, ignoreCase = true) }) {
            savedMarkers.add(clean)
            savedMarkers.sortBy { it.lowercase() }
            persist()
        }
    }

    fun saveNote(updated: Note) {
        splitValues(updated.markers).forEach { registerMarker(it) }
        val index = notes.indexOfFirst { it.id == updated.id }
        if (index >= 0) notes[index] = updated else notes.add(0, updated)
        persist()
    }

    fun deleteNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        val movedAt = System.currentTimeMillis()
        for (i in notes.indices) {
            if (notes[i].id in ids && notes[i].deletedAt <= 0L) {
                notes[i] = notes[i].copy(deletedAt = movedAt)
            }
        }
        persist()
    }

    fun restoreTrashNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        for (i in notes.indices) {
            if (notes[i].id in ids && notes[i].deletedAt > 0L) {
                notes[i] = notes[i].copy(deletedAt = 0L)
            }
        }
        persist()
    }

    fun permanentlyDeleteNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        notes.removeAll { it.id in ids }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in ids }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun emptyTrash() {
        val trashedIds = notes.filter { it.deletedAt > 0L }.map { it.id }.toSet()
        if (trashedIds.isEmpty()) return
        notes.removeAll { it.id in trashedIds }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in trashedIds }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun applyMarkersToNotes(ids: Set<String>, markers: Set<String>, remove: Boolean) {
        if (markers.isEmpty()) return
        markers.forEach { if (!remove) registerMarker(it) }
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val existing = splitValues(current.markers).toMutableSet()
                val next = if (remove) {
                    existing.filterNot { old -> markers.any { it.equals(old, true) } }.toSet()
                } else {
                    (existing + markers).toSet()
                }
                notes[i] = current.copy(markers = next.joinToString(", "))
            }
        }
        persist()
    }

    fun archiveNotes(ids: Set<String>, archived: Boolean) {
        for (i in notes.indices) {
            if (notes[i].id in ids) notes[i] = notes[i].copy(archived = archived)
        }
        persist()
    }

    fun relateSelectedNotes(ids: Set<String>) {
        if (ids.size < 2) return
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val related = parseIds(current.links).toMutableSet()
                related.addAll(ids - current.id)
                notes[i] = current.copy(links = related.joinToString(","))
            }
        }
        persist()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg,
        surface = Card,
        surfaceVariant = CardRaised,
        primary = Accent,
        onPrimary = Bg,
        onBackground = Ink,
        onSurface = Ink,
        secondary = Muted
    )) {
        if (editingNote != null) {
            EditorScreen(
                note = editingNote!!,
                allNotes = notes.toList(),
                knownMarkers = savedMarkers.toList(),
                onSave = { updated -> saveNote(updated); editingNote = null },
                onAutoSave = ::saveNote,
                onOpenLinked = { current, targetId ->
                    saveNote(current)
                    editingNote = notes.firstOrNull { it.id == targetId }?.copy()
                }
            )
        } else {
            NotesHome(
                notes = notes,
                knownMarkers = savedMarkers,
                search = search,
                onSearchChange = { search = it },
                showingArchived = showingArchived,
                showingTrash = showingTrash,
                onShowArchived = { showingTrash = false; showingArchived = true; activeMarker = null },
                onShowTrash = { showingTrash = true; showingArchived = false; activeMarker = null },
                onShowNotes = { showingTrash = false; showingArchived = false; activeMarker = null },
                activeMarker = activeMarker,
                onSelectMarker = { marker -> showingTrash = false; showingArchived = false; activeMarker = marker },
                onOpenNote = { editingNote = it.copy(coverScale = safeScale(it)) },
                onNewNote = { editingNote = Note() },
                onBulkApplyMarkers = ::applyMarkersToNotes,
                onBulkArchive = ::archiveNotes,
                onBulkRelate = ::relateSelectedNotes,
                onBulkDelete = ::deleteNotes,
                onRestoreTrash = ::restoreTrashNotes,
                onDeleteForever = ::permanentlyDeleteNotes,
                onEmptyTrash = ::emptyTrash,
                onCreateBackup = {
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())
                    backupCreator.launch("ESCUDO-DO-MESTRE-backup-$stamp.zip")
                },
                onRestoreBackup = { backupRestorer.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
            )
        }
    }

    if (pendingRestore != null) {
        val backup = pendingRestore!!
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restaurar backup do Drive") },
            text = { Text("O arquivo contém ${backup.notes.size} ficha(s) e ${backup.markers.size} marcador(es). Você pode mesclar com as notas atuais ou substituir tudo.") },
            confirmButton = {
                TextButton(onClick = {
                    val merged = notes.toMutableList()
                    backup.notes.forEach { restored ->
                        val index = merged.indexOfFirst { it.id == restored.id }
                        if (index >= 0) merged[index] = restored else merged.add(0, restored)
                    }
                    notes.clear(); notes.addAll(merged)
                    backup.markers.forEach { marker ->
                        if (savedMarkers.none { it.equals(marker, true) }) savedMarkers.add(marker)
                    }
                    savedMarkers.sortBy { it.lowercase() }
                    persist()
                    pendingRestore = null
                    backupMessage = "Backup mesclado. ${backup.notes.size} ficha(s) foram importadas."
                }) { Text("Mesclar") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingRestore = null }) { Text("Cancelar") }
                    TextButton(onClick = {
                        notes.clear(); notes.addAll(backup.notes)
                        savedMarkers.clear(); savedMarkers.addAll(backup.markers.distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
                        persist()
                        pendingRestore = null
                        backupMessage = "Backup restaurado. As notas atuais foram substituídas."
                    }) { Text("Substituir tudo", color = Danger) }
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
    if (backupMessage != null) {
        AlertDialog(
            onDismissRequest = { backupMessage = null },
            title = { Text("Backup do ESCUDO DO MESTRE") },
            text = { Text(backupMessage!! ) },
            confirmButton = { TextButton(onClick = { backupMessage = null }) { Text("OK") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NotesHome(
    notes: List<Note>,
    knownMarkers: List<String>,
    search: String,
    onSearchChange: (String) -> Unit,
    showingArchived: Boolean,
    showingTrash: Boolean,
    onShowArchived: () -> Unit,
    onShowTrash: () -> Unit,
    onShowNotes: () -> Unit,
    activeMarker: String?,
    onSelectMarker: (String) -> Unit,
    onOpenNote: (Note) -> Unit,
    onNewNote: () -> Unit,
    onBulkApplyMarkers: (Set<String>, Set<String>, Boolean) -> Unit,
    onBulkArchive: (Set<String>, Boolean) -> Unit,
    onBulkRelate: (Set<String>) -> Unit,
    onBulkDelete: (Set<String>) -> Unit,
    onRestoreTrash: (Set<String>) -> Unit,
    onDeleteForever: (Set<String>) -> Unit,
    onEmptyTrash: () -> Unit,
    onCreateBackup: () -> Unit,
    onRestoreBackup: () -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val selectedIds = remember { mutableStateListOf<String>() }
    var showBulkMarkers by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showPermanentDeleteConfirmation by remember { mutableStateOf(false) }
    var showEmptyTrashConfirmation by remember { mutableStateOf(false) }
    val selectedNotes = notes.filter { it.id in selectedIds }
    val allSelectedArchived = selectedNotes.isNotEmpty() && selectedNotes.all { it.archived }

    fun toggleSelected(id: String) {
        if (id in selectedIds) selectedIds.remove(id) else selectedIds.add(id)
    }
    fun openOrSelect(note: Note) {
        if (showingTrash || selectedIds.isNotEmpty()) toggleSelected(note.id) else onOpenNote(note)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Panel,
                drawerContentColor = Ink
            ) {
                Column(
                    Modifier.fillMaxHeight().statusBarsPadding().padding(horizontal = 18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Spacer(Modifier.height(20.dp))
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Organização do grimório", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        value = search,
                        onValueChange = onSearchChange,
                        modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp, max = 54.dp),
                        singleLine = true,
                        textStyle = TextStyle(color = Ink, fontSize = 12.sp),
                        placeholder = { Text("Pesquisar notas e palavras", fontSize = 11.sp) },
                        shape = RoundedCornerShape(12.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                    )
                    Spacer(Modifier.height(16.dp))
                    NavigationDrawerItem(
                        label = { Text("Todas as notas") },
                        selected = !showingArchived && !showingTrash && activeMarker == null,
                        onClick = { selectedIds.clear(); onShowNotes(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        label = { Text("Arquivadas") },
                        selected = showingArchived && !showingTrash,
                        onClick = { selectedIds.clear(); onShowArchived(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        label = { Text("Lixeira (${notes.count { it.deletedAt > 0L }})") },
                        selected = showingTrash,
                        onClick = { selectedIds.clear(); onShowTrash(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("SEGURANÇA DAS NOTAS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    NavigationDrawerItem(
                        label = { Text("Salvar backup na nuvem (ZIP)") },
                        selected = false,
                        onClick = { scope.launch { drawerState.close() }; onCreateBackup() },
                        colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Ink)
                    )
                    NavigationDrawerItem(
                        label = { Text("Restaurar backup do Drive") },
                        selected = false,
                        onClick = { scope.launch { drawerState.close() }; onRestoreBackup() },
                        colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Ink)
                    )
                    HorizontalDivider(color = Color(0xFF373737), modifier = Modifier.padding(vertical = 12.dp))
                    Text("MARCADORES SALVOS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (knownMarkers.isEmpty()) {
                        Text("Seus marcadores aparecerão aqui quando você criar o primeiro.", color = Muted, fontSize = 11.sp)
                    } else {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            knownMarkers.forEach { marker ->
                                FilterChip(
                                    selected = activeMarker == marker,
                                    onClick = { selectedIds.clear(); onSelectMarker(marker); scope.launch { drawerState.close() } },
                                    label = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Outlined.Label, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(marker, maxLines = 1)
                                        }
                                    }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("Dica: deslize da borda esquerda para abrir este painel.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    ) {
        val filtered = notes
            .filter { if (showingTrash) it.deletedAt > 0L else it.deletedAt <= 0L }
            // A marker view deliberately spans both active and archived notes.
            .filter { showingTrash || activeMarker != null || it.archived == showingArchived }
            .filter { activeMarker == null || splitValues(it.markers).any { tag -> tag.equals(activeMarker, true) } }
            .filter {
                search.isBlank() || it.title.contains(search, true) ||
                    it.body.contains(search, true) || it.markers.contains(search, true) ||
                    it.pages.orEmpty().any { page -> page.body.contains(search, true) }
            }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.title })

        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectedIds.isNotEmpty()) {
                    TextButton(onClick = { selectedIds.clear() }, contentPadding = PaddingValues(8.dp)) {
                        Text("✕", color = Ink, fontSize = 21.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${selectedIds.size} selecionada(s)", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Toque em outras fichas para incluí-las", color = Muted, fontSize = 11.sp)
                    }
                } else {
                    TextButton(onClick = { scope.launch { drawerState.open() } }, contentPadding = PaddingValues(8.dp)) {
                        Text("☰", color = Ink, fontSize = 24.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("ESCUDO DO MESTRE", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("Seu grimório de anotações", color = Muted, fontSize = 11.sp)
                    }
                    Text("◈ D20", color = Accent, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp, max = 56.dp),
                singleLine = true,
                textStyle = TextStyle(color = Ink, fontSize = 12.sp),
                placeholder = { Text("Pesquisar notas ou palavras dentro delas", fontSize = 12.sp) },
                shape = RoundedCornerShape(13.dp),
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        TextButton(onClick = { onSearchChange("") }) { Text("Limpar") }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
            )
            Text("Segure uma ficha para selecionar várias e editar marcadores em grupo.",
                color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            showingTrash -> "Lixeira"
                            showingArchived -> "Arquivadas"
                            activeMarker != null -> "#${activeMarker}"
                            else -> "Minhas notas"
                        },
                        color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text("${filtered.size} notas", color = Muted, fontSize = 11.sp)
                }
                if (showingTrash) {
                    TextButton(onClick = { showEmptyTrashConfirmation = true }) {
                        Text("Esvaziar", color = Danger)
                    }
                } else if (activeMarker != null || showingArchived) {
                    TextButton(onClick = onShowNotes) { Text("Ver todas", color = Accent) }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◈", color = Accent, fontSize = 41.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when {
                                search.isNotBlank() -> "Nenhuma nota encontrada"
                                showingTrash -> "A lixeira está vazia"
                                showingArchived -> "Nada arquivado por enquanto"
                                activeMarker != null -> "Nenhuma nota com este marcador"
                                else -> "Seu escudo está pronto"
                            },
                            color = Ink, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (showingTrash) "As fichas excluídas ficarão aqui por 7 dias."
                            else "Crie uma nota ou ajuste sua pesquisa.",
                            color = Muted, fontSize = 11.sp
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 145.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        NoteCard(
                            note = note,
                            selected = note.id in selectedIds,
                            onClick = { openOrSelect(note) },
                            onLongClick = { toggleSelected(note.id) }
                        )
                    }
                }
            }
            if (selectedIds.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (showingTrash) {
                        Button(
                            onClick = {
                                onRestoreTrash(selectedIds.toSet())
                                selectedIds.clear()
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Restaurar", fontSize = 11.sp) }
                        OutlinedButton(
                            onClick = { showPermanentDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
                        ) { Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Apagar", fontSize = 11.sp) }
                    } else {
                        OutlinedButton(
                            onClick = { showBulkMarkers = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Icon(Icons.Outlined.Label, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Marcadores", fontSize = 9.sp) }
                        OutlinedButton(
                            onClick = {
                                onBulkRelate(selectedIds.toSet())
                                selectedIds.clear()
                            },
                            enabled = selectedIds.size >= 2,
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Icon(Icons.Outlined.Link, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Relacionar", fontSize = 9.sp) }
                        OutlinedButton(
                            onClick = { showDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
                        ) { Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Lixeira", fontSize = 9.sp) }
                        Button(
                            onClick = {
                                onBulkArchive(selectedIds.toSet(), !allSelectedArchived)
                                selectedIds.clear()
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(if (allSelectedArchived) "Restaurar" else "Arquivar", fontSize = 9.sp) }
                    }
                }
            } else if (!showingTrash) {
                Button(
                    onClick = onNewNote,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("+ Nova nota", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 5.dp))
                }
            }

            if (showBulkMarkers) {
                BulkMarkerDialog(
                    selectedCount = selectedIds.size,
                    knownMarkers = knownMarkers,
                    onDismiss = { showBulkMarkers = false },
                    onApply = { markers, remove ->
                        onBulkApplyMarkers(selectedIds.toSet(), markers, remove)
                        showBulkMarkers = false
                        selectedIds.clear()
                    }
                )
            }
            if (showDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirmation = false },
                    title = { Text("Mover para a lixeira?") },
                    text = { Text("${selectedIds.size} ficha(s) ficarão na lixeira por 7 dias. Nesse período, você poderá restaurá-las ou apagá-las definitivamente.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onBulkDelete(selectedIds.toSet())
                            selectedIds.clear()
                            showDeleteConfirmation = false
                        }) { Text("Mover para a lixeira", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
            if (showPermanentDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showPermanentDeleteConfirmation = false },
                    title = { Text("Apagar definitivamente?") },
                    text = { Text("${selectedIds.size} ficha(s) serão removidas agora. Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onDeleteForever(selectedIds.toSet())
                            selectedIds.clear()
                            showPermanentDeleteConfirmation = false
                        }) { Text("Apagar definitivamente", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showPermanentDeleteConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
            if (showEmptyTrashConfirmation) {
                AlertDialog(
                    onDismissRequest = { showEmptyTrashConfirmation = false },
                    title = { Text("Esvaziar lixeira?") },
                    text = { Text("Todas as fichas na lixeira serão apagadas definitivamente. Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onEmptyTrash()
                            selectedIds.clear()
                            showEmptyTrashConfirmation = false
                        }) { Text("Esvaziar lixeira", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showEmptyTrashConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    note: Note,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val shape = RoundedCornerShape(17.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) Accent else Color.Transparent,
                shape = shape
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = if (selected) CardRaised else Card)
    ) {
        Column(Modifier.padding(9.dp)) {
            Box {
                if (note.cover.isNotBlank()) {
                    CoverImage(
                        uri = note.cover,
                        scale = safeScale(note),
                        offsetX = note.coverOffsetX,
                        // Move portrait artwork down inside the square viewport so the face
                        // and upper body are shown instead of the abdomen.
                        offsetY = (note.coverOffsetY + 0.28f).coerceIn(-1f, 1f),
                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                    )
                } else {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                            .background(Color(0xFF303030)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◈ D20", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (selected) {
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(7.dp)
                            .size(27.dp).clip(RoundedCornerShape(50)).background(Accent),
                        contentAlignment = Alignment.Center
                    ) { Text("✓", color = Bg, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(note.title.ifBlank { "Sem título" }, color = Ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, modifier = Modifier.weight(1f))
                if (note.pinned) Text("📌", fontSize = 11.sp)
            }
            if (note.body.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(note.body, color = Muted, fontSize = 11.sp, maxLines = 2)
            }
            val tags = splitValues(note.markers).take(2)
            val relationCount = parseIds(note.links).size
            if (tags.isNotEmpty() || relationCount > 0) {
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (tags.isNotEmpty()) {
                        Icon(Icons.Outlined.Label, contentDescription = "Marcadores", tint = Accent, modifier = Modifier.size(13.dp))
                        Text(tags.joinToString("  ") { it }, color = Accent, fontSize = 10.sp, maxLines = 1)
                    }
                    if (relationCount > 0) {
                        Icon(Icons.Outlined.Link, contentDescription = "Notas relacionadas", tint = Muted, modifier = Modifier.size(13.dp))
                        Text(relationCount.toString(), color = Muted, fontSize = 10.sp)
                    }
                }
            }
            if (note.archived) {
                Spacer(Modifier.height(5.dp))
                Text("ARQUIVADA", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BulkMarkerDialog(
    selectedCount: Int,
    knownMarkers: List<String>,
    onDismiss: () -> Unit,
    onApply: (Set<String>, Boolean) -> Unit
) {
    val choices = remember(knownMarkers) {
        mutableStateListOf<String>().apply { addAll(knownMarkers) }
    }
    val selectedMarkers = remember { mutableStateListOf<String>() }
    var newMarker by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Marcadores • $selectedCount fichas") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 430.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    if (removing) "Escolha os marcadores que serão removidos das fichas selecionadas."
                    else "Escolha os marcadores que serão adicionados às fichas selecionadas.",
                    color = Muted, fontSize = 11.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remover marcadores", modifier = Modifier.weight(1f), color = Ink)
                    Switch(checked = removing, onCheckedChange = { removing = it })
                }
                if (choices.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        choices.forEach { marker ->
                            val isSelected = selectedMarkers.any { it.equals(marker, true) }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) selectedMarkers.removeAll { it.equals(marker, true) }
                                    else selectedMarkers.add(marker)
                                },
                                label = { Text("#${marker}") }
                            )
                        }
                    }
                } else {
                    Text("Ainda não existem marcadores salvos.", color = Muted, fontSize = 11.sp)
                }
                OutlinedTextField(
                    value = newMarker,
                    onValueChange = { newMarker = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Criar marcador") }
                )
                OutlinedButton(
                    onClick = {
                        val clean = newMarker.trim().removePrefix("#")
                        if (clean.isNotEmpty() && choices.none { it.equals(clean, true) }) {
                            choices.add(clean)
                            selectedMarkers.add(clean)
                        }
                        newMarker = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Adicionar marcador à lista") }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onApply(selectedMarkers.toSet(), removing) },
                enabled = selectedMarkers.isNotEmpty()
            ) { Text(if (removing) "Remover" else "Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel,
        titleContentColor = Ink,
        textContentColor = Ink
    )
}

@Composable
private fun CoverImage(
    uri: String,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.MATRIX } },
        update = { view ->
            if (view.tag != uri) {
                runCatching { view.setImageURI(Uri.parse(uri)) }
                view.tag = uri
            }
            view.post { applyCoverMatrix(view, scale.coerceAtLeast(1f), offsetX, offsetY) }
        },
        modifier = modifier
    )
}

@Composable
private fun PaperStyleSample(
    style: String,
    tone: String,
    selected: Boolean,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val paper = when (tone) {
        "white" -> Color(0xFFF1F0EA)
        "gray" -> Color(0xFF45454B)
        else -> Bg
    }
    val line = if (tone == "white") Color(0x55333333) else Color(0x55FFFFFF)
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(7.dp))
                .background(paper)
                .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Muted.copy(alpha = 0.45f), RoundedCornerShape(7.dp))
        ) {
            ComposeCanvas(Modifier.fillMaxSize().padding(4.dp)) {
                val gap = 9.dp.toPx()
                if (style == "ruled" || style == "grid") {
                    var y = gap
                    while (y < size.height) {
                        drawLine(line, Offset(0f, y), Offset(size.width, y), 0.7.dp.toPx())
                        y += gap
                    }
                }
                if (style == "grid") {
                    var x = gap
                    while (x < size.width) {
                        drawLine(line, Offset(x, 0f), Offset(x, size.height), 0.7.dp.toPx())
                        x += gap
                    }
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = if (selected) Accent else Ink, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun EditorScreen(
    note: Note,
    allNotes: List<Note>,
    knownMarkers: List<String>,
    onSave: (Note) -> Unit,
    onAutoSave: (Note) -> Unit,
    onOpenLinked: (Note, String) -> Unit
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var title by remember(note.id) { mutableStateOf(note.title) }
    var pages by remember(note.id) { mutableStateOf(normalizePages(note)) }
    var activePageIndex by remember(note.id) { mutableIntStateOf(0) }
    var selectedLinks by remember(note.id) { mutableStateOf(parseIds(note.links)) }
    var pageIndexToDelete by remember(note.id) { mutableIntStateOf(-1) }
    var pinned by remember(note.id) { mutableStateOf(note.pinned) }
    var archived by remember(note.id) { mutableStateOf(note.archived) }
    var paperTone by remember(note.id) { mutableStateOf(note.paperTone?.takeIf { it in setOf("black", "white", "gray") } ?: "black") }
    var paperStyle by remember(note.id) { mutableStateOf(note.paperStyle?.takeIf { it in setOf("blank", "ruled", "grid") } ?: "blank") }
    val selectedMarkers = remember(note.id) {
        mutableStateListOf<String>().apply { addAll(splitValues(note.markers)) }
    }

    var activeEditText by remember(note.id) { mutableStateOf<NoteEditText?>(null) }
    var editorResetToken by remember(note.id) { mutableIntStateOf(0) }
    var pendingCaretAfterReset by remember(note.id) { mutableIntStateOf(-1) }

    var pendingInsertPage by remember(note.id) { mutableIntStateOf(0) }
    var pendingInsertBlockId by remember(note.id) { mutableStateOf<String?>(null) }
    var pendingInsertCursor by remember(note.id) { mutableIntStateOf(0) }
    var pendingImagePurpose by remember(note.id) { mutableStateOf("inline") }

    // Temporary image-insertion adjustment. Width/crop are fixed after confirmation.
    var imageAdjusting by remember(note.id) { mutableStateOf(false) }
    var pendingImageUri by remember(note.id) { mutableStateOf<String?>(null) }
    var pendingScale by remember(note.id) { mutableFloatStateOf(1f) }
    var pendingOffsetX by remember(note.id) { mutableFloatStateOf(0f) }
    var pendingOffsetY by remember(note.id) { mutableFloatStateOf(0f) }
    var pendingAspectRatio by remember(note.id) { mutableFloatStateOf(1.7778f) }
    var pendingWidthFraction by remember(note.id) { mutableFloatStateOf(0.55f) }

    var showMoreMenu by remember(note.id) { mutableStateOf(false) }
    var showMarkerDialog by remember(note.id) { mutableStateOf(false) }
    var showRelatedDialog by remember(note.id) { mutableStateOf(false) }
    var showPaperDialog by remember(note.id) { mutableStateOf(false) }
    var newMarker by remember(note.id) { mutableStateOf("") }
    var imageToDelete by remember(note.id) { mutableStateOf<Pair<Int, String>?>(null) }
    var imageActionsFor by remember(note.id) { mutableStateOf<String?>(null) }
    var lastTouchX by remember(note.id) { mutableFloatStateOf(0f) }
    var lastTouchY by remember(note.id) { mutableFloatStateOf(0f) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pendingImageUri = it.toString()
            pendingScale = 1f
            pendingOffsetX = 0f
            pendingOffsetY = 0f
            pendingAspectRatio = readImageAspectRatio(context, it)
            pendingWidthFraction = 0.55f
            imageAdjusting = true
        }
    }

    fun updatePage(index: Int, updated: NotePage) {
        if (index !in pages.indices) return
        pages = pages.toMutableList().also { it[index] = updated }
    }

    fun currentPage(): NotePage = pages.getOrNull(activePageIndex) ?: pages.first()

    fun currentNote(): Note {
        val normalizedPages = pages.map { page ->
            val storedBlocks = collapseAdjacentTextBlocks(page.blocks.ifEmpty { listOf(NoteBlock(text = page.body)) })
            page.copy(body = pageBodyFromBlocks(storedBlocks), blocks = storedBlocks)
        }
        val first = normalizedPages.firstOrNull() ?: NotePage(blocks = listOf(NoteBlock()))
        return note.copy(
            title = title.trim(),
            body = first.body,
            cover = first.image,
            markers = selectedMarkers.joinToString(", "),
            links = selectedLinks.joinToString(","),
            archived = archived,
            pinned = pinned,
            paperTone = paperTone,
            paperStyle = paperStyle,
            coverScale = first.imageScale.coerceIn(1f, 3.5f),
            coverOffsetX = first.imageOffsetX,
            coverOffsetY = first.imageOffsetY,
            coverAspectRatio = safeAspectRatio(first.imageAspectRatio),
            pages = normalizedPages
        )
    }

    fun saveAndExit() {
        keyboard?.hide()
        onSave(currentNote())
    }

    fun selectPage(index: Int) {
        if (index !in pages.indices || index == activePageIndex) return
        keyboard?.hide()
        activePageIndex = index
        editorResetToken++
        pendingCaretAfterReset = -1
    }

    fun addPage() {
        val newPage = NotePage(blocks = listOf(NoteBlock()))
        pages = pages + newPage
        activePageIndex = pages.lastIndex
        editorResetToken++
        pendingCaretAfterReset = 0
        showMoreMenu = false
    }

    fun prepareImageInsertion() {
        val pageIndex = activePageIndex.coerceIn(0, pages.lastIndex)
        val page = pages[pageIndex]
        val location = locateTextBlockAtCursor(page.blocks, activeEditText?.selectionStart ?: 0)
            ?: (page.blocks.lastOrNull { it.kind != "image" }?.let { it.id to it.text.length })
        pendingInsertPage = pageIndex
        pendingInsertBlockId = location?.first
        pendingInsertCursor = location?.second ?: 0
        pendingImagePurpose = "inline"
        showMoreMenu = false
        keyboard?.hide()
        imagePicker.launch(arrayOf("image/*"))
    }

    fun prepareCoverImage() {
        // The cover shown on the closed card always comes from page 1.
        pendingInsertPage = 0
        pendingInsertBlockId = null
        pendingInsertCursor = 0
        pendingImagePurpose = "cover"
        showMoreMenu = false
        keyboard?.hide()
        imagePicker.launch(arrayOf("image/*"))
    }

    fun insertAdjustedImage() {
        val uri = pendingImageUri ?: return
        val isCoverImage = pendingImagePurpose == "cover"
        val pageIndex = pendingInsertPage.coerceIn(0, pages.lastIndex)
        val page = pages[pageIndex]
        if (isCoverImage) {
            updatePage(pageIndex, page.copy(
                image = uri,
                imageScale = pendingScale.coerceIn(1f, 4f),
                imageOffsetX = pendingOffsetX,
                imageOffsetY = pendingOffsetY,
                imageAspectRatio = safeAspectRatio(pendingAspectRatio)
            ))
            pendingCaretAfterReset = -1
        } else {
            val blocks = page.blocks.toMutableList()
            val targetIndex = blocks.indexOfFirst { it.id == pendingInsertBlockId && it.kind != "image" }
            val imageBlock = NoteBlock(
                kind = "image",
                image = uri,
                imageWidthFraction = pendingWidthFraction.coerceIn(0.15f, 1f),
                imageScale = pendingScale.coerceIn(1f, 4f),
                imageOffsetX = pendingOffsetX,
                imageOffsetY = pendingOffsetY,
                imageAspectRatio = safeAspectRatio(pendingAspectRatio)
            )
            if (targetIndex >= 0) {
                val target = blocks[targetIndex]
                val cursor = pendingInsertCursor.coerceIn(0, target.text.length)
                val beforeText = target.text.substring(0, cursor)
                val afterText = target.text.substring(cursor)
                blocks.removeAt(targetIndex)
                blocks.addAll(targetIndex, listOf(target.copy(text = beforeText), imageBlock, NoteBlock(text = afterText)))
            } else {
                blocks.add(imageBlock)
                blocks.add(NoteBlock())
            }
            val normalized = collapseAdjacentTextBlocks(blocks)
            updatePage(pageIndex, page.copy(blocks = normalized, body = pageBodyFromBlocks(normalized)))
            pendingCaretAfterReset = caretOffsetAfterImage(normalized, imageBlock.id)
        }
        if (!isCoverImage) activePageIndex = pageIndex
        editorResetToken++
        pendingImageUri = null
        pendingInsertBlockId = null
        imageAdjusting = false
    }

    fun removeImageBlock(pageIndex: Int, blockId: String) {
        if (pageIndex !in pages.indices) return
        val page = pages[pageIndex]
        val remaining = page.blocks.filterNot { it.id == blockId }
        val safeBlocks = collapseAdjacentTextBlocks(remaining)
        updatePage(pageIndex, page.copy(blocks = safeBlocks, body = pageBodyFromBlocks(safeBlocks)))
        editorResetToken++
        imageToDelete = null
    }

    fun moveInlineImage(blockId: String, direction: Int) {
        val page = currentPage()
        val blocks = page.blocks.toMutableList()
        val index = blocks.indexOfFirst { it.id == blockId && it.kind == "image" }
        if (index < 0) return
        if (direction < 0) {
            if (index == 0 || blocks[index - 1].kind == "image") return
            val previous = blocks[index - 1]
            if (previous.text.isEmpty()) return
            val moved = previous.text.last()
            blocks[index - 1] = previous.copy(text = previous.text.dropLast(1))
            if (index + 1 < blocks.size && blocks[index + 1].kind != "image") {
                blocks[index + 1] = blocks[index + 1].copy(text = moved + blocks[index + 1].text)
            } else {
                blocks.add(index + 1, NoteBlock(text = moved.toString()))
            }
        } else {
            if (index + 1 >= blocks.size || blocks[index + 1].kind == "image") return
            val next = blocks[index + 1]
            if (next.text.isEmpty()) return
            val moved = next.text.first()
            if (index > 0 && blocks[index - 1].kind != "image") {
                blocks[index - 1] = blocks[index - 1].copy(text = blocks[index - 1].text + moved)
            } else {
                blocks.add(index, NoteBlock(text = moved.toString()))
            }
            val newImageIndex = blocks.indexOfFirst { it.id == blockId }
            blocks[newImageIndex + 1] = next.copy(text = next.text.drop(1))
        }
        val normalized = collapseAdjacentTextBlocks(blocks)
        updatePage(activePageIndex, page.copy(blocks = normalized, body = pageBodyFromBlocks(normalized)))
        pendingCaretAfterReset = caretOffsetAfterImage(normalized, blockId)
        editorResetToken++
        imageActionsFor = null
    }

    val markerSnapshot = selectedMarkers.toList()
    LaunchedEffect(title, pages, selectedLinks, markerSnapshot, pinned, archived, paperTone, paperStyle, imageAdjusting) {
        if (!imageAdjusting) {
            delay(650)
            val draft = currentNote()
            val hasContent = draft.title.isNotBlank() || draft.pages.any { page ->
                page.body.isNotBlank() || page.image.isNotBlank() || page.blocks.any { it.kind == "image" }
            } || draft.links.isNotBlank()
            if (hasContent) onAutoSave(draft)
        }
    }

    BackHandler {
        when {
            imageAdjusting -> {
                imageAdjusting = false
                pendingImageUri = null
                pendingInsertBlockId = null
            }
            showMoreMenu -> showMoreMenu = false
            showMarkerDialog -> showMarkerDialog = false
            showRelatedDialog -> showRelatedDialog = false
            showPaperDialog -> showPaperDialog = false
            imageActionsFor != null -> imageActionsFor = null
            else -> saveAndExit()
        }
    }

    if (imageAdjusting && pendingImageUri != null) {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding().padding(horizontal = 18.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    imageAdjusting = false
                    pendingImageUri = null
                    pendingInsertBlockId = null
                }) { Text("Cancelar", color = Ink, fontSize = 11.sp) }
                Text(if (pendingImagePurpose == "cover") "Imagem da capa" else "Adicionar imagem no texto",
                    color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { insertAdjustedImage() }) {
                    Text("Confirmar", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            Text("Ajuste a largura, o zoom e o enquadramento antes de inserir. Depois de confirmar, remova e insira novamente para mudar o tamanho.",
                color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                val previewWidth = maxWidth * pendingWidthFraction
                val desiredHeight = (previewWidth / safeAspectRatio(pendingAspectRatio)).coerceAtMost(maxHeight)
                CoverImage(
                    uri = pendingImageUri.orEmpty(), scale = pendingScale, offsetX = pendingOffsetX, offsetY = pendingOffsetY,
                    modifier = Modifier.width(previewWidth).height(desiredHeight).clip(RoundedCornerShape(16.dp))
                        .pointerInput(pendingImageUri) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                pendingOffsetX = (pendingOffsetX + dragAmount.x / size.width.toFloat()).coerceIn(-1f, 1f)
                                pendingOffsetY = (pendingOffsetY + dragAmount.y / size.height.toFloat()).coerceIn(-1f, 1f)
                            }
                        }
                )
            }
            Text("Largura da imagem", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Slider(value = pendingWidthFraction, onValueChange = { pendingWidthFraction = it }, valueRange = 0.15f..1f)
            Text("Zoom", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Slider(value = pendingScale, onValueChange = { pendingScale = it }, valueRange = 1f..4f)
            OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Escolher outra imagem", fontSize = 11.sp)
            }
            Spacer(Modifier.height(12.dp))
        }
    } else {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding()
        ) {
            // Fixed header and page strip. Only the note content scrolls.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { saveAndExit() }) { Text("←", color = Ink, fontSize = 23.sp) }
                Text(if (note.title.isBlank() && title.isBlank()) "Nova nota" else "Nota",
                    color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { saveAndExit() }) {
                    Text("✓", color = Accent, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                pages.forEachIndexed { index, _ ->
                    val isSelected = index == activePageIndex
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(if (isSelected) Accent else CardRaised)
                            .combinedClickable(
                                onClick = { selectPage(index) },
                                onLongClick = { pageIndexToDelete = index }
                            ).padding(horizontal = 15.dp, vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${index + 1}", color = if (isSelected) Bg else Ink,
                            fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }

            val activePage = currentPage()
            val paperComposeColor = when (paperTone) {
                "white" -> Color(0xFFF1F0EA)
                "gray" -> Color(0xFF45454B)
                else -> Bg
            }
            val paperInk = if (paperTone == "white") Color(0xFF181818) else Ink
            val paperMuted = if (paperTone == "white") Color(0xFF66645F) else Muted
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                    .background(paperComposeColor)
                    .padding(horizontal = 20.dp).padding(top = 10.dp, bottom = 16.dp)
            ) {
                if (activePage.image.isNotBlank()) {
                    CoverImage(
                        uri = activePage.image,
                        scale = activePage.imageScale,
                        offsetX = activePage.imageOffsetX,
                        offsetY = activePage.imageOffsetY,
                        modifier = Modifier.fillMaxWidth().aspectRatio(safeAspectRatio(activePage.imageAspectRatio))
                            .clip(RoundedCornerShape(14.dp))
                    )
                    Spacer(Modifier.height(14.dp))
                }

                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(color = paperInk, fontSize = 20.sp, fontWeight = FontWeight.Medium, lineHeight = 26.sp),
                    cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    decorationBox = { inner ->
                        Box {
                            if (title.isEmpty()) Text("Título", color = paperMuted, fontSize = 20.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.height(14.dp))

                // One native EditText renders text and floating images in the same paragraph flow.
                key(activePage.id) {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 390.dp),
                        factory = { viewContext ->
                            NoteEditText(viewContext).apply {
                                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                                setTextColor(if (paperTone == "white") android.graphics.Color.rgb(24, 24, 24) else android.graphics.Color.rgb(242, 240, 234))
                                setHintTextColor(if (paperTone == "white") android.graphics.Color.rgb(102, 100, 95) else android.graphics.Color.rgb(170, 166, 157))
                                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                                setPadding(0, 0, 0, 0)
                                includeFontPadding = false
                                gravity = Gravity.TOP or Gravity.START
                                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                                imeOptions = EditorInfo.IME_ACTION_NONE
                                isSingleLine = false
                                minLines = 8
                                hint = "Comece a escrever..."
                                val available = (resources.displayMetrics.widthPixels - (40 * resources.displayMetrics.density).toInt()).coerceAtLeast(240)
                                applyingModel = true
                                configurePaperEditor(this, paperStyle, paperTone)
                                setText(blocksToEditable(viewContext, activePage.blocks, available, getLineHeight()))
                                applyingModel = false
                                renderedVersion = editorResetToken
                                activeEditText = this

                                addTextChangedListener(object : TextWatcher {
                                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                                    override fun afterTextChanged(editable: Editable?) {
                                        if (applyingModel || editable == null) return
                                        val blocks = editableToBlocks(editable)
                                        val idx = activePageIndex
                                        val page = pages.getOrNull(idx) ?: return
                                        if (blocks != page.blocks) {
                                            updatePage(idx, page.copy(blocks = blocks, body = pageBodyFromBlocks(blocks)))
                                        }
                                    }
                                })

                                setOnTouchListener { _, event ->
                                    if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                                        lastTouchX = event.x
                                        lastTouchY = event.y
                                    }
                                    false
                                }
                                setOnLongClickListener {
                                    val layout = layout
                                    val editable = text as? Editable
                                    if (layout == null || editable == null || editable.isEmpty()) return@setOnLongClickListener false
                                    val line = layout.getLineForVertical((lastTouchY + scrollY - totalPaddingTop).toInt().coerceIn(0, (layout.height - 1).coerceAtLeast(0)))
                                    val offset = layout.getOffsetForHorizontal(line, lastTouchX + scrollX - totalPaddingLeft)
                                    val flowSpan = editable.getSpans(0, editable.length, ImageFlowMarginSpan::class.java)
                                        .firstOrNull { candidate ->
                                            val spanStart = editable.getSpanStart(candidate).coerceAtLeast(0)
                                            val firstLine = layout.getLineForOffset(spanStart.coerceAtMost(editable.length))
                                            val lineIsBesideImage = candidate.currentImageLineCount > 0 &&
                                                line >= firstLine && line < firstLine + candidate.currentImageLineCount
                                            val touchIsInsideImageColumn = lastTouchX <= candidate.imageWidthPx + 10 * resources.displayMetrics.density
                                            lineIsBesideImage && touchIsInsideImageColumn
                                        }
                                    val anchor = editable.getSpans(0, editable.length, NoteInlineImageSpan::class.java)
                                        .firstOrNull { offset >= editable.getSpanStart(it) && offset <= editable.getSpanEnd(it) }
                                    val imageId = flowSpan?.imageAnchor?.block?.id ?: anchor?.block?.id
                                    if (imageId != null) {
                                        imageActionsFor = imageId
                                        true
                                    } else false
                                }
                            }
                        },
                        update = { edit ->
                            activeEditText = edit
                            edit.setTextColor(if (paperTone == "white") android.graphics.Color.rgb(24, 24, 24) else android.graphics.Color.rgb(242, 240, 234))
                            edit.setHintTextColor(if (paperTone == "white") android.graphics.Color.rgb(102, 100, 95) else android.graphics.Color.rgb(170, 166, 157))
                            if (edit.paperStyle != paperStyle || edit.paperTone != paperTone || edit.paperStepPx <= 0f) {
                                configurePaperEditor(edit, paperStyle, paperTone)
                            }
                            if (edit.renderedVersion != editorResetToken) {
                                val available = (edit.width.takeIf { it > 0 } ?: edit.resources.displayMetrics.widthPixels) - edit.paddingLeft - edit.paddingRight
                                edit.applyingModel = true
                                edit.setText(blocksToEditable(context, activePage.blocks, available.coerceAtLeast(240), edit.getLineHeight()))
                                edit.applyingModel = false
                                edit.renderedVersion = editorResetToken
                                val selection = if (pendingCaretAfterReset >= 0) pendingCaretAfterReset else edit.text.length
                                edit.setSelection(selection.coerceIn(0, edit.text.length))
                                pendingCaretAfterReset = -1
                            }
                        }
                    )
                }
                Spacer(Modifier.height(16.dp))
            }

            // Compact action rail sits immediately above the keyboard.
            Row(
                Modifier.fillMaxWidth().padding(start = 9.dp, end = 12.dp, top = 1.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    IconButton(onClick = { showMoreMenu = true }) {
                        Text("⋮", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(expanded = showMoreMenu, onDismissRequest = { showMoreMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Criar nova página", fontSize = 12.sp) },
                            onClick = { addPage() }
                        )
                        DropdownMenuItem(
                            text = { Text("Adicionar imagem no texto", fontSize = 12.sp) },
                            onClick = { prepareImageInsertion() }
                        )
                        DropdownMenuItem(
                            text = { Text(if (currentPage().image.isBlank()) "Adicionar imagem de capa" else "Trocar imagem de capa", fontSize = 12.sp) },
                            onClick = { prepareCoverImage() }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text(if (pinned) "Desafixar nota" else "Fixar nota", fontSize = 12.sp) },
                            onClick = { pinned = !pinned; showMoreMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text(if (archived) "Restaurar nota" else "Arquivar nota", fontSize = 12.sp) },
                            onClick = { archived = !archived; showMoreMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Marcadores", fontSize = 12.sp) },
                            onClick = { showMoreMenu = false; showMarkerDialog = true }
                        )
                    }
                }
                IconButton(onClick = { showPaperDialog = true }) {
                    Icon(Icons.Outlined.Palette, contentDescription = "Fundo da nota", tint = Accent)
                }
                IconButton(onClick = { showRelatedDialog = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Link, contentDescription = "Notas relacionadas", tint = Accent)
                        if (selectedLinks.isNotEmpty()) {
                            Spacer(Modifier.width(4.dp))
                            Text(selectedLinks.size.toString(), color = Accent, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            }
        }
    }

    if (showPaperDialog) {
        AlertDialog(
            onDismissRequest = { showPaperDialog = false },
            title = { Text("Fundo da nota", fontSize = 15.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Cor do fundo", color = Muted, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            Triple("black", "Preto", Color(0xFF101010)),
                            Triple("white", "Branco", Color(0xFFF1F0EA)),
                            Triple("gray", "Cinza", Color(0xFF45454B))
                        ).forEach { (tone, label, swatch) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    paperTone = tone
                                }
                            ) {
                                Box(
                                    Modifier.size(30.dp).clip(CircleShape)
                                        .background(swatch)
                                        .border(
                                            width = if (paperTone == tone) 3.dp else 1.dp,
                                            color = if (paperTone == tone) Accent else Muted.copy(alpha = 0.55f),
                                            shape = CircleShape
                                        )
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(label, color = Ink, fontSize = 10.sp)
                            }
                        }
                    }
                    HorizontalDivider(color = Color(0x33444444))
                    Text("Estilo do papel", color = Muted, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("blank" to "Vazio", "ruled" to "Linhas", "grid" to "Grade").forEach { (style, label) ->
                            PaperStyleSample(
                                style = style,
                                tone = paperTone,
                                selected = paperStyle == style,
                                label = label,
                                modifier = Modifier.weight(1f),
                                onClick = { paperStyle = style }
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPaperDialog = false }) { Text("Concluir") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (showRelatedDialog) {
        val relatedNotes = allNotes.filter { it.deletedAt <= 0L && it.id in selectedLinks }
        AlertDialog(
            onDismissRequest = { showRelatedDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Link, contentDescription = null, tint = Accent)
                    Spacer(Modifier.width(8.dp))
                    Text("Notas relacionadas (${relatedNotes.size})", fontSize = 15.sp)
                }
            },
            text = {
                if (relatedNotes.isEmpty()) {
                    Text("Nenhuma nota relacionada.", color = Muted, fontSize = 12.sp)
                } else {
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        relatedNotes.forEach { other ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Card)
                                    .clickable {
                                        showRelatedDialog = false
                                        onOpenLinked(currentNote(), other.id)
                                    }.padding(horizontal = 12.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(other.title.ifBlank { "Sem título" }, color = Ink, fontSize = 12.sp,
                                    modifier = Modifier.weight(1f), maxLines = 1)
                                Text("Abrir ↗", color = Accent, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showRelatedDialog = false }) { Text("Fechar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (showMarkerDialog) {
        AlertDialog(
            onDismissRequest = { showMarkerDialog = false },
            title = { Text("Marcadores da nota", fontSize = 16.sp) },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Text("Toque nos marcadores para adicionar ou remover desta nota.", color = Muted, fontSize = 11.sp)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (knownMarkers + selectedMarkers).distinctBy { it.lowercase() }.forEach { marker ->
                            val checked = selectedMarkers.any { it.equals(marker, true) }
                            FilterChip(
                                selected = checked,
                                onClick = {
                                    if (checked) selectedMarkers.removeAll { it.equals(marker, true) }
                                    else selectedMarkers.add(marker)
                                },
                                label = { Text("#${marker}", fontSize = 11.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = newMarker,
                        onValueChange = { newMarker = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Novo marcador", fontSize = 11.sp) }
                    )
                    OutlinedButton(
                        onClick = {
                            val clean = newMarker.trim().removePrefix("#")
                            if (clean.isNotEmpty() && selectedMarkers.none { it.equals(clean, true) }) selectedMarkers.add(clean)
                            newMarker = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Adicionar marcador", fontSize = 11.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { showMarkerDialog = false }) { Text("Concluir") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (pageIndexToDelete >= 0) {
        val deletingPageNumber = pageIndexToDelete + 1
        AlertDialog(
            onDismissRequest = { pageIndexToDelete = -1 },
            title = { Text("Excluir página $deletingPageNumber?") },
            text = { Text("O texto e as imagens desta página serão removidos. As outras páginas serão mantidas.") },
            confirmButton = {
                TextButton(onClick = {
                    val target = pageIndexToDelete
                    if (pages.size > 1 && target in pages.indices) {
                        pages = pages.toMutableList().also { it.removeAt(target) }
                        activePageIndex = when {
                            target < activePageIndex -> activePageIndex - 1
                            target == activePageIndex -> minOf(target, pages.lastIndex)
                            else -> activePageIndex
                        }.coerceIn(0, pages.lastIndex)
                        editorResetToken++
                        pendingCaretAfterReset = -1
                    }
                    pageIndexToDelete = -1
                }) { Text("Excluir página", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { pageIndexToDelete = -1 }) { Text("Cancelar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (imageActionsFor != null) {
        val imageId = imageActionsFor!!
        AlertDialog(
            onDismissRequest = { imageActionsFor = null },
            title = { Text("Imagem selecionada", fontSize = 15.sp) },
            text = { Text("Você pode deslocar a imagem dentro do texto ou removê-la. Para alterar o tamanho, remova e insira novamente.", fontSize = 12.sp) },
            confirmButton = {
                Row {
                    TextButton(onClick = { moveInlineImage(imageId, -1) }) { Text("← Mover") }
                    TextButton(onClick = { moveInlineImage(imageId, 1) }) { Text("Mover →") }
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { imageToDelete = activePageIndex to imageId; imageActionsFor = null }) {
                        Text("Remover", color = Danger)
                    }
                    TextButton(onClick = { imageActionsFor = null }) { Text("Fechar") }
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (imageToDelete != null) {
        val target = imageToDelete!!
        AlertDialog(
            onDismissRequest = { imageToDelete = null },
            title = { Text("Remover imagem?") },
            text = { Text("A imagem será removida do texto. Para alterar o tamanho, remova e insira novamente.") },
            confirmButton = {
                TextButton(onClick = { removeImageBlock(target.first, target.second) }) {
                    Text("Remover imagem", color = Danger)
                }
            },
            dismissButton = { TextButton(onClick = { imageToDelete = null }) { Text("Cancelar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
}

