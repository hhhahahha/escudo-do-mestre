# ESCUDO DO MESTRE 1.16

Atualização baseada na versão 1.15.

## Alterações
- Removida do menu do editor a opção de inserir imagens no corpo do texto. A seleção e edição de imagem de capa continuam disponíveis.
- Imagens inline já existentes continuam sendo lidas/renderizadas para não descartar conteúdo antigo, mas não é possível inserir novas pelo editor.
- Adicionada a seção **Conta do mestre** ao painel lateral, aberto por gesto de deslizar.
- Adicionado perfil local com nome e e-mail, salvo no aparelho.
- Adicionado seletor nativo de conta Google do Android para preencher o e-mail do perfil.

## Limite importante da conta nesta versão
O perfil é local. Selecionar uma conta Google apenas associa o endereço de e-mail ao perfil neste aparelho; não é autenticação OAuth, não cria uma conta online e não ativa sincronização entre dispositivos. Para login real por Google/e-mail e sincronização em nuvem, é necessário configurar um projeto Firebase/Google com credenciais próprias do aplicativo.

## Compatibilidade
- Application ID: `br.com.escudodomestre`
- versionCode: `17`
- versionName: `1.16`
- Min SDK: 26
- Build esperado: GitHub Actions, Java 17 e Gradle 8.9
