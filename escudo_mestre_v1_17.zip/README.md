# ESCUDO DO MESTRE 1.17

Atualização baseada na versão 1.16.

## Alterações
- Painel lateral reorganizado com cabeçalho de perfil no topo.
- Foto de perfil circular, selecionável pela galeria/arquivos do Android.
- Botão **Editar perfil** logo abaixo da foto e do nome.
- Campos locais de nome de exibição, nome de usuário, e-mail e biografia curta.
- A foto do perfil e os dados são persistidos nas preferências locais do aplicativo.
- O seletor de conta Google existente continua disponível dentro de Editar perfil e preenche o campo de e-mail.

## Limite importante da conta nesta versão
O perfil é local. Selecionar uma conta Google apenas preenche o endereço de e-mail; isso não é autenticação OAuth, não cria uma conta online e não ativa sincronização entre dispositivos. Para login real por Google/e-mail e sincronização em nuvem, é necessário configurar um projeto Firebase/Google com credenciais próprias do aplicativo.

## Compatibilidade
- Application ID: `br.com.escudodomestre`
- versionCode: `18`
- versionName: `1.17`
- Min SDK: 26
- Build esperado: GitHub Actions, Java 17 e Gradle 8.9
