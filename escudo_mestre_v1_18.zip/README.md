# ESCUDO DO MESTRE 1.18

Atualização baseada na versão 1.17.

## Alterações
- A foto de perfil agora abre uma etapa de ajuste antes de ser salva.
- Arraste a imagem para reposicionar e use dois dedos para ampliar ou reduzir.
- A prévia circular mostra o enquadramento do avatar.
- A imagem recortada é salva dentro do armazenamento privado do aplicativo, sem depender do endereço temporário da galeria.

## Sobre a sincronização na nuvem
A conta desta versão continua sendo um perfil local. O seletor de conta Google não autentica o usuário nem sincroniza notas. A sincronização real exige um projeto Firebase pertencente ao usuário e o arquivo `google-services.json` correspondente ao aplicativo `br.com.escudodomestre`. Esse arquivo ainda não foi fornecido, então esta versão não declara nem simula sincronização ativa. Assim que o arquivo de configuração for disponibilizado, será possível integrar login, banco de dados e armazenamento de imagens na nuvem.

## Compatibilidade
- Application ID: `br.com.escudodomestre`
- versionCode: `19`
- versionName: `1.18`
- Min SDK: 26
- Build: GitHub Actions, Java 17 e Gradle 8.9
