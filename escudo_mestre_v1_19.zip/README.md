# ESCUDO DO MESTRE 1.19 – Firebase

## Recursos da versão
- Cadastro e login por e-mail e senha usando Firebase Authentication.
- Recuperação de senha por e-mail.
- Perfil individual na nuvem: nome de exibição, nome de usuário, e-mail, biografia e foto.
- Foto de perfil ajustável antes de salvar, com controle de ampliação e posição.
- Foto compactada em JPEG/Base64 e guardada no documento de perfil do Cloud Firestore, sem Firebase Storage.
- Sincronização de fichas, textos, páginas textuais, marcadores, vínculos, arquivamento e lixeira por usuário.
- Ao entrar pela primeira vez em uma conta sem fichas na nuvem, os dados locais deste aparelho são enviados para essa conta.
- Mantém o identificador Android `br.com.escudodomestre`; versão `1.19`, código `20`.

## Limitação sem Cloud Storage
Capas e imagens anexadas dentro das fichas permanecem locais e não são transferidas para outros aparelhos. A foto do perfil é sincronizada pelo Firestore em formato compactado. Não é necessário ativar Firebase Storage para o funcionamento descrito acima.

## Projeto Firebase
- Projeto: `escudo-do-mestre-167d6`
- App Android: `br.com.escudodomestre`
- Configuração: `app/google-services.json`
- Authentication: provedor E-mail/senha habilitado no console.
- Cloud Firestore: edição Standard, região `southamerica-east1`, banco `(default)`.

## Segurança obrigatória
Antes de usar a sincronização, publique o conteúdo de `firebase/firestore.rules` na aba **Regras** do Cloud Firestore no Firebase Console. As regras permitem que cada usuário autenticado leia e grave somente em `users/{seu UID}/...`.

## Compilação
O workflow `.github/workflows/android.yml` extrai `escudo_mestre_v1_19.zip`, compila com Java 17 e Gradle 8.9 e publica o APK como artefato `ESCUDO-DO-MESTRE-APK-v1.19`.
