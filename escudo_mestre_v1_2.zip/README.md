# ESCUDO DO MESTRE 1.2 🎲

Atualização de organização de capas e marcadores para o aplicativo Android pessoal de notas e fichas de RPG.

## Mudanças desta versão
- A capa confirmada aparece no topo da nota aberta, acima do título e do texto.
- Os controles de enquadramento ficam em uma tela temporária aberta ao escolher ou tocar na capa; depois de confirmar, os controles desaparecem.
- Ajuste da capa por arraste e zoom, com opção de trocar ou remover.
- Marcadores saíram do editor de cada nota.
- Pressione e segure um cartão para entrar no modo de seleção múltipla; toque em outros cartões para incluir ou retirar da seleção.
- A barra de seleção em grupo permite adicionar ou remover marcadores de várias notas de uma vez e arquivar/restaurar as notas selecionadas.
- Marcadores continuam guardados no painel lateral. Ao escolher um marcador, a lista mostra notas ativas e arquivadas que usam aquele marcador.
- A pesquisa continua procurando títulos, marcadores e palavras dentro do conteúdo.
- As ligações entre notas, o tema escuro e o armazenamento local foram mantidos.
- Mantém o mesmo applicationId e o formato de dados anterior para permitir atualização preservando dados locais.

## Compilação
O workflow do GitHub Actions gera um APK de depuração ao receber um push na branch `main`.
