package br.com.escudodomestre

import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.math.max

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF191919)
private val Card = Color(0xFF202020)
private val CardRaised = Color(0xFF282828)
private val Ink = Color(0xFFF2F0EA)
private val Muted = Color(0xFFAAA69D)
private val Accent = Color(0xFFD6C9A8)
private val Danger = Color(0xFFE58A82)

/**
 * Keep the old field names and String representation for markers/links so notes
 * created by version 1.0 remain readable after updating the APK.
 */
data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val cover: String = "",
    val markers: String = "",
    val links: String = "",
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val coverScale: Float = 1f,
    val coverOffsetX: Float = 0f,
    val coverOffsetY: Float = 0f
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp() }
    }
}

private fun splitValues(raw: String): List<String> = raw
    .split(',', '\n')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .distinctBy { it.lowercase() }

private fun parseIds(raw: String): Set<String> = raw
    .split(',')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .toSet()

private fun safeScale(note: Note): Float = note.coverScale.takeIf { it >= 1f } ?: 1f

private fun applyCoverMatrix(view: ImageView, scale: Float, offsetX: Float, offsetY: Float) {
    val drawable = view.drawable ?: return
    val viewW = view.width.toFloat()
    val viewH = view.height.toFloat()
    val imageW = drawable.intrinsicWidth.toFloat()
    val imageH = drawable.intrinsicHeight.toFloat()
    if (viewW <= 0f || viewH <= 0f || imageW <= 0f || imageH <= 0f) return

    val fit = max(viewW / imageW, viewH / imageH)
    val finalScale = fit * scale.coerceAtLeast(1f)
    val drawnW = imageW * finalScale
    val drawnH = imageH * finalScale
    val tx = (viewW - drawnW) / 2f + offsetX * viewW
    val ty = (viewH - drawnH) / 2f + offsetY * viewH
    val matrix = Matrix().apply {
        setScale(finalScale, finalScale)
        postTranslate(tx, ty)
    }
    view.imageMatrix = matrix
}

@Composable
fun EscudoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("escudo_notas", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }
    val noteType = remember { object : TypeToken<List<Note>>() {}.type }
    val markerType = remember { object : TypeToken<List<String>>() {}.type }

    val notes = remember {
        mutableStateListOf<Note>().apply {
            val loaded = runCatching {
                gson.fromJson<List<Note>>(prefs.getString("notes", "[]"), noteType)
            }.getOrNull().orEmpty()
            addAll(loaded.map { old ->
                // Older notes did not store cover adjustments or archive/pin state.
                old.copy(coverScale = safeScale(old))
            })
        }
    }
    val savedMarkers = remember {
        mutableStateListOf<String>().apply {
            val fromPrefs = runCatching {
                gson.fromJson<List<String>>(prefs.getString("saved_markers", "[]"), markerType)
            }.getOrNull().orEmpty()
            val fromNotes = notes.flatMap { splitValues(it.markers) }
            addAll((fromPrefs + fromNotes).distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
        }
    }

    var search by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var showingArchived by remember { mutableStateOf(false) }
    var activeMarker by remember { mutableStateOf<String?>(null) }

    fun persist() {
        prefs.edit()
            .putString("notes", gson.toJson(notes))
            .putString("saved_markers", gson.toJson(savedMarkers))
            .apply()
    }

    fun registerMarker(value: String) {
        val clean = value.trim().removePrefix("#")
        if (clean.isNotEmpty() && savedMarkers.none { it.equals(clean, ignoreCase = true) }) {
            savedMarkers.add(clean)
            savedMarkers.sortBy { it.lowercase() }
            persist()
        }
    }

    fun saveNote(updated: Note) {
        splitValues(updated.markers).forEach { registerMarker(it) }
        val index = notes.indexOfFirst { it.id == updated.id }
        if (index >= 0) notes[index] = updated else notes.add(0, updated)
        persist()
    }

    fun deleteNote(id: String) {
        notes.removeAll { it.id == id }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it == id }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun applyMarkersToNotes(ids: Set<String>, markers: Set<String>, remove: Boolean) {
        if (markers.isEmpty()) return
        markers.forEach { if (!remove) registerMarker(it) }
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val existing = splitValues(current.markers).toMutableSet()
                val next = if (remove) {
                    existing.filterNot { old -> markers.any { it.equals(old, true) } }.toSet()
                } else {
                    (existing + markers).toSet()
                }
                notes[i] = current.copy(markers = next.joinToString(", "))
            }
        }
        persist()
    }

    fun archiveNotes(ids: Set<String>, archived: Boolean) {
        for (i in notes.indices) {
            if (notes[i].id in ids) notes[i] = notes[i].copy(archived = archived)
        }
        persist()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg,
        surface = Card,
        surfaceVariant = CardRaised,
        primary = Accent,
        onPrimary = Bg,
        onBackground = Ink,
        onSurface = Ink,
        secondary = Muted
    )) {
        if (editingNote != null) {
            EditorScreen(
                note = editingNote!!,
                allNotes = notes.toList(),
                onSave = { updated -> saveNote(updated); editingNote = null },
                onAutoSave = ::saveNote,
                onDelete = { id -> deleteNote(id); editingNote = null },
                onOpenLinked = { current, targetId ->
                    saveNote(current)
                    editingNote = notes.firstOrNull { it.id == targetId }?.copy()
                }
            )
        } else {
            NotesHome(
                notes = notes,
                knownMarkers = savedMarkers,
                search = search,
                onSearchChange = { search = it },
                showingArchived = showingArchived,
                onShowArchived = { showingArchived = true; activeMarker = null },
                onShowNotes = { showingArchived = false; activeMarker = null },
                activeMarker = activeMarker,
                onSelectMarker = { marker -> showingArchived = false; activeMarker = marker },
                onOpenNote = { editingNote = it.copy(coverScale = safeScale(it)) },
                onNewNote = { editingNote = Note() },
                onBulkApplyMarkers = ::applyMarkersToNotes,
                onBulkArchive = ::archiveNotes
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NotesHome(
    notes: List<Note>,
    knownMarkers: List<String>,
    search: String,
    onSearchChange: (String) -> Unit,
    showingArchived: Boolean,
    onShowArchived: () -> Unit,
    onShowNotes: () -> Unit,
    activeMarker: String?,
    onSelectMarker: (String) -> Unit,
    onOpenNote: (Note) -> Unit,
    onNewNote: () -> Unit,
    onBulkApplyMarkers: (Set<String>, Set<String>, Boolean) -> Unit,
    onBulkArchive: (Set<String>, Boolean) -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val selectedIds = remember { mutableStateListOf<String>() }
    var showBulkMarkers by remember { mutableStateOf(false) }
    val selectedNotes = notes.filter { it.id in selectedIds }
    val allSelectedArchived = selectedNotes.isNotEmpty() && selectedNotes.all { it.archived }

    fun toggleSelected(id: String) {
        if (id in selectedIds) selectedIds.remove(id) else selectedIds.add(id)
    }
    fun openOrSelect(note: Note) {
        if (selectedIds.isNotEmpty()) toggleSelected(note.id) else onOpenNote(note)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Panel,
                drawerContentColor = Ink
            ) {
                Column(
                    Modifier.fillMaxHeight().statusBarsPadding().padding(horizontal = 18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Spacer(Modifier.height(20.dp))
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Organização do grimório", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        value = search,
                        onValueChange = onSearchChange,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Pesquisar notas e palavras") },
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                    )
                    Spacer(Modifier.height(16.dp))
                    NavigationDrawerItem(
                        label = { Text("Todas as notas") },
                        selected = !showingArchived && activeMarker == null,
                        onClick = { onShowNotes(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        label = { Text("Arquivadas") },
                        selected = showingArchived,
                        onClick = { onShowArchived(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    HorizontalDivider(color = Color(0xFF373737), modifier = Modifier.padding(vertical = 12.dp))
                    Text("MARCADORES SALVOS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (knownMarkers.isEmpty()) {
                        Text("Seus marcadores aparecerão aqui quando você criar o primeiro.", color = Muted, fontSize = 12.sp)
                    } else {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            knownMarkers.forEach { marker ->
                                FilterChip(
                                    selected = activeMarker == marker,
                                    onClick = { onSelectMarker(marker); scope.launch { drawerState.close() } },
                                    label = { Text("#${marker}", maxLines = 1) }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("Dica: deslize da borda esquerda para abrir este painel.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    ) {
        val filtered = notes
            // A marker view deliberately spans both active and archived notes.
            .filter { activeMarker != null || it.archived == showingArchived }
            .filter { activeMarker == null || splitValues(it.markers).any { tag -> tag.equals(activeMarker, true) } }
            .filter {
                search.isBlank() || it.title.contains(search, true) ||
                    it.body.contains(search, true) || it.markers.contains(search, true)
            }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.title })

        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectedIds.isNotEmpty()) {
                    TextButton(onClick = { selectedIds.clear() }, contentPadding = PaddingValues(8.dp)) {
                        Text("✕", color = Ink, fontSize = 22.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${selectedIds.size} selecionada(s)", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Toque em outras fichas para incluí-las", color = Muted, fontSize = 11.sp)
                    }
                } else {
                    TextButton(onClick = { scope.launch { drawerState.open() } }, contentPadding = PaddingValues(8.dp)) {
                        Text("☰", color = Ink, fontSize = 25.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("ESCUDO DO MESTRE", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Seu grimório de anotações", color = Muted, fontSize = 12.sp)
                    }
                    Text("◈ D20", color = Accent, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Pesquisar notas ou palavras dentro delas") },
                shape = RoundedCornerShape(15.dp),
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        TextButton(onClick = { onSearchChange("") }) { Text("Limpar") }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
            )
            Text("Segure uma ficha para selecionar várias e editar marcadores em grupo.",
                color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            showingArchived -> "Arquivadas"
                            activeMarker != null -> "#${activeMarker}"
                            else -> "Minhas notas"
                        },
                        color = Ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text("${filtered.size} notas", color = Muted, fontSize = 11.sp)
                }
                if (activeMarker != null || showingArchived) {
                    TextButton(onClick = onShowNotes) { Text("Ver todas", color = Accent) }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◈", color = Accent, fontSize = 42.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when {
                                search.isNotBlank() -> "Nenhuma nota encontrada"
                                showingArchived -> "Nada arquivado por enquanto"
                                activeMarker != null -> "Nenhuma nota com este marcador"
                                else -> "Seu escudo está pronto"
                            },
                            color = Ink, fontWeight = FontWeight.SemiBold
                        )
                        Text("Crie uma nota ou ajuste sua pesquisa.", color = Muted, fontSize = 12.sp)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 145.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        NoteCard(
                            note = note,
                            selected = note.id in selectedIds,
                            onClick = { openOrSelect(note) },
                            onLongClick = { toggleSelected(note.id) }
                        )
                    }
                }
            }
            if (selectedIds.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { showBulkMarkers = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Marcadores") }
                    Button(
                        onClick = {
                            onBulkArchive(selectedIds.toSet(), !allSelectedArchived)
                            selectedIds.clear()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text(if (allSelectedArchived) "Restaurar" else "Arquivar") }
                }
            } else {
                Button(
                    onClick = onNewNote,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("+ Nova nota", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 5.dp))
                }
            }

            if (showBulkMarkers) {
                BulkMarkerDialog(
                    selectedCount = selectedIds.size,
                    knownMarkers = knownMarkers,
                    onDismiss = { showBulkMarkers = false },
                    onApply = { markers, remove ->
                        onBulkApplyMarkers(selectedIds.toSet(), markers, remove)
                        showBulkMarkers = false
                        selectedIds.clear()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    note: Note,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val shape = RoundedCornerShape(17.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) Accent else Color.Transparent,
                shape = shape
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = if (selected) CardRaised else Card)
    ) {
        Column(Modifier.padding(9.dp)) {
            Box {
                if (note.cover.isNotBlank()) {
                    CoverImage(
                        uri = note.cover,
                        scale = safeScale(note),
                        offsetX = note.coverOffsetX,
                        offsetY = note.coverOffsetY,
                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                    )
                } else {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                            .background(Color(0xFF303030)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◈ D20", color = Accent, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (selected) {
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(7.dp)
                            .size(27.dp).clip(RoundedCornerShape(50)).background(Accent),
                        contentAlignment = Alignment.Center
                    ) { Text("✓", color = Bg, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(note.title.ifBlank { "Sem título" }, color = Ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, modifier = Modifier.weight(1f))
                if (note.pinned) Text("📌", fontSize = 12.sp)
            }
            if (note.body.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(note.body, color = Muted, fontSize = 11.sp, maxLines = 2)
            }
            val tags = splitValues(note.markers).take(2)
            if (tags.isNotEmpty()) {
                Spacer(Modifier.height(7.dp))
                Text(tags.joinToString("  ") { "#${it}" }, color = Accent, fontSize = 10.sp, maxLines = 1)
            }
            if (note.archived) {
                Spacer(Modifier.height(5.dp))
                Text("ARQUIVADA", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BulkMarkerDialog(
    selectedCount: Int,
    knownMarkers: List<String>,
    onDismiss: () -> Unit,
    onApply: (Set<String>, Boolean) -> Unit
) {
    val choices = remember(knownMarkers) {
        mutableStateListOf<String>().apply { addAll(knownMarkers) }
    }
    val selectedMarkers = remember { mutableStateListOf<String>() }
    var newMarker by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Marcadores • $selectedCount fichas") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 430.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    if (removing) "Escolha os marcadores que serão removidos das fichas selecionadas."
                    else "Escolha os marcadores que serão adicionados às fichas selecionadas.",
                    color = Muted, fontSize = 12.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remover marcadores", modifier = Modifier.weight(1f), color = Ink)
                    Switch(checked = removing, onCheckedChange = { removing = it })
                }
                if (choices.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        choices.forEach { marker ->
                            val isSelected = selectedMarkers.any { it.equals(marker, true) }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) selectedMarkers.removeAll { it.equals(marker, true) }
                                    else selectedMarkers.add(marker)
                                },
                                label = { Text("#${marker}") }
                            )
                        }
                    }
                } else {
                    Text("Ainda não existem marcadores salvos.", color = Muted, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = newMarker,
                    onValueChange = { newMarker = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Criar marcador") }
                )
                OutlinedButton(
                    onClick = {
                        val clean = newMarker.trim().removePrefix("#")
                        if (clean.isNotEmpty() && choices.none { it.equals(clean, true) }) {
                            choices.add(clean)
                            selectedMarkers.add(clean)
                        }
                        newMarker = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Adicionar marcador à lista") }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onApply(selectedMarkers.toSet(), removing) },
                enabled = selectedMarkers.isNotEmpty()
            ) { Text(if (removing) "Remover" else "Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel,
        titleContentColor = Ink,
        textContentColor = Ink
    )
}

@Composable
private fun CoverImage(
    uri: String,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.MATRIX } },
        update = { view ->
            if (view.tag != uri) {
                runCatching { view.setImageURI(Uri.parse(uri)) }
                view.tag = uri
            }
            view.post { applyCoverMatrix(view, scale.coerceAtLeast(1f), offsetX, offsetY) }
        },
        modifier = modifier
    )
}

@Composable
private fun EditorScreen(
    note: Note,
    allNotes: List<Note>,
    onSave: (Note) -> Unit,
    onAutoSave: (Note) -> Unit,
    onDelete: (String) -> Unit,
    onOpenLinked: (Note, String) -> Unit
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var title by remember(note.id) { mutableStateOf(note.title) }
    var body by remember(note.id) { mutableStateOf(note.body) }
    var coverUri by remember(note.id) { mutableStateOf(note.cover) }
    var coverScale by remember(note.id) { mutableFloatStateOf(safeScale(note)) }
    var coverOffsetX by remember(note.id) { mutableFloatStateOf(note.coverOffsetX) }
    var coverOffsetY by remember(note.id) { mutableFloatStateOf(note.coverOffsetY) }
    var selectedLinks by remember(note.id) { mutableStateOf(parseIds(note.links)) }
    var pinned by remember(note.id) { mutableStateOf(note.pinned) }
    var archived by remember(note.id) { mutableStateOf(note.archived) }

    // Cover controls live in their own temporary screen. The editor itself only
    // shows the finished cover at the top, keeping the writing area uncluttered.
    var coverAdjusting by remember(note.id) { mutableStateOf(false) }
    var pendingCoverUri by remember(note.id) { mutableStateOf<String?>(null) }
    var pendingScale by remember(note.id) { mutableFloatStateOf(safeScale(note)) }
    var pendingOffsetX by remember(note.id) { mutableFloatStateOf(note.coverOffsetX) }
    var pendingOffsetY by remember(note.id) { mutableFloatStateOf(note.coverOffsetY) }

    fun currentNote(): Note = note.copy(
        title = title.trim(),
        body = body,
        cover = coverUri,
        // Markers are now managed from the note-card multi-selection menu.
        markers = note.markers,
        links = selectedLinks.joinToString(","),
        archived = archived,
        pinned = pinned,
        coverScale = coverScale.coerceIn(1f, 3.5f),
        coverOffsetX = coverOffsetX,
        coverOffsetY = coverOffsetY
    )

    fun saveAndExit() {
        keyboard?.hide()
        onSave(currentNote())
    }

    fun openCoverAdjuster() {
        pendingCoverUri = coverUri.takeIf { it.isNotBlank() }
        pendingScale = coverScale
        pendingOffsetX = coverOffsetX
        pendingOffsetY = coverOffsetY
        if (pendingCoverUri != null) coverAdjusting = true
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pendingCoverUri = it.toString()
            pendingScale = 1f
            pendingOffsetX = 0f
            pendingOffsetY = 0f
            coverAdjusting = true
        }
    }

    LaunchedEffect(title, body, coverUri, selectedLinks, pinned, archived, coverScale, coverOffsetX, coverOffsetY, coverAdjusting) {
        if (!coverAdjusting) {
            delay(700)
            val draft = currentNote()
            val hasContent = draft.title.isNotBlank() || draft.body.isNotBlank() ||
                draft.cover.isNotBlank() || draft.markers.isNotBlank() || draft.links.isNotBlank()
            if (hasContent) onAutoSave(draft)
        }
    }

    BackHandler {
        if (coverAdjusting) {
            coverAdjusting = false
            pendingCoverUri = null
        } else {
            saveAndExit()
        }
    }

    if (coverAdjusting && pendingCoverUri != null) {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding().padding(horizontal = 18.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {
                    coverAdjusting = false
                    pendingCoverUri = null
                }) { Text("Cancelar", color = Ink) }
                Text("Ajustar capa", color = Ink, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = {
                    coverUri = pendingCoverUri.orEmpty()
                    coverScale = pendingScale.coerceIn(1f, 3.5f)
                    coverOffsetX = pendingOffsetX
                    coverOffsetY = pendingOffsetY
                    coverAdjusting = false
                    pendingCoverUri = null
                }) { Text("Confirmar", color = Accent, fontWeight = FontWeight.Bold) }
            }
            Text("Arraste a imagem para escolher o enquadramento.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            CoverImage(
                uri = pendingCoverUri.orEmpty(),
                scale = pendingScale,
                offsetX = pendingOffsetX,
                offsetY = pendingOffsetY,
                modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(18.dp))
                    .pointerInput(pendingCoverUri) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            pendingOffsetX = (pendingOffsetX + dragAmount.x / size.width.toFloat()).coerceIn(-1f, 1f)
                            pendingOffsetY = (pendingOffsetY + dragAmount.y / size.height.toFloat()).coerceIn(-1f, 1f)
                        }
                    }
            )
            Spacer(Modifier.height(14.dp))
            Text("Zoom", color = Ink, fontWeight = FontWeight.Medium)
            Slider(value = pendingScale, onValueChange = { pendingScale = it }, valueRange = 1f..3.5f)
            OutlinedButton(
                onClick = { imagePicker.launch(arrayOf("image/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Escolher outra imagem") }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        coverUri = ""
                        coverScale = 1f
                        coverOffsetX = 0f
                        coverOffsetY = 0f
                        pendingCoverUri = null
                        coverAdjusting = false
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Remover capa") }
                Button(
                    onClick = {
                        coverUri = pendingCoverUri.orEmpty()
                        coverScale = pendingScale.coerceIn(1f, 3.5f)
                        coverOffsetX = pendingOffsetX
                        coverOffsetY = pendingOffsetY
                        coverAdjusting = false
                        pendingCoverUri = null
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                ) { Text("Confirmar capa", fontWeight = FontWeight.Bold) }
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { saveAndExit() }) { Text("←", color = Ink, fontSize = 28.sp) }
                Text(if (note.title.isBlank() && title.isBlank()) "Nova nota" else "Nota", color = Muted,
                    fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { pinned = !pinned }) {
                    Text(if (pinned) "📌" else "Fixar", color = if (pinned) Accent else Muted)
                }
                TextButton(onClick = { archived = !archived }) {
                    Text(if (archived) "Restaurar" else "Arquivar", color = Accent, fontSize = 12.sp)
                }
                TextButton(onClick = { saveAndExit() }) {
                    Text("✓", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp).padding(bottom = 28.dp)
            ) {
                Spacer(Modifier.height(10.dp))

                // A chosen cover stays at the very top of the opened note. The
                // crop/zoom controls only appear in the dedicated adjust screen.
                if (coverUri.isNotBlank()) {
                    CoverImage(
                        uri = coverUri,
                        scale = coverScale,
                        offsetX = coverOffsetX,
                        offsetY = coverOffsetY,
                        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { openCoverAdjuster() }
                    )
                } else {
                    OutlinedButton(
                        onClick = { imagePicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("＋ Adicionar capa") }
                }

                Spacer(Modifier.height(12.dp))
                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    decorationBox = { inner ->
                        Box {
                            if (title.isEmpty()) Text("Título", color = Muted, fontSize = 27.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.height(22.dp))
                BasicTextField(
                    value = body,
                    onValueChange = { body = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 360.dp),
                    textStyle = TextStyle(color = Ink, fontSize = 17.sp, lineHeight = 26.sp),
                    cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Default
                    ),
                    decorationBox = { inner ->
                        Box {
                            if (body.isEmpty()) Text("Comece a escrever...", color = Muted, fontSize = 17.sp)
                            inner()
                        }
                    }
                )

                Spacer(Modifier.height(24.dp))
                HorizontalDivider(color = Color(0xFF333333))
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("CONEXÕES ENTRE NOTAS", color = Muted, fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${selectedLinks.size} ligada(s)", color = Accent, fontSize = 10.sp)
                }
                Text("Selecione outras notas para criar ligações entre suas fichas.", color = Muted, fontSize = 11.sp,
                    modifier = Modifier.padding(top = 5.dp, bottom = 9.dp))
                val candidates = allNotes.filter { it.id != note.id && !it.archived }
                if (candidates.isEmpty()) {
                    Text("Crie outra nota para começar a fazer conexões.", color = Muted, fontSize = 12.sp)
                } else {
                    candidates.forEach { other ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel)
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = selectedLinks.contains(other.id),
                                onCheckedChange = { checked ->
                                    selectedLinks = if (checked) selectedLinks + other.id else selectedLinks - other.id
                                },
                                colors = CheckboxDefaults.colors(checkedColor = Accent, checkmarkColor = Bg)
                            )
                            Text(other.title.ifBlank { "Sem título" }, color = Ink,
                                modifier = Modifier.weight(1f), maxLines = 1)
                            TextButton(onClick = { onOpenLinked(currentNote(), other.id) }) {
                                Text("Abrir", color = Accent, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(5.dp))
                    }
                }

                Spacer(Modifier.height(28.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { onDelete(note.id) }, modifier = Modifier.weight(1f)) {
                        Text("Excluir", color = Danger)
                    }
                    Button(
                        onClick = { saveAndExit() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                    ) { Text("Salvar nota", fontWeight = FontWeight.Bold) }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}
