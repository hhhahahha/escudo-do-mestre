# ESCUDO DO MESTRE 1.20

Atualização de desempenho e sincronização:
- Escritas do Firestore agrupadas após pausa nos salvamentos automáticos.
- Gravação das fichas em lote, com preparação JSON fora da thread de interface.
- Evita reenvio completo imediatamente após carregar os dados da nuvem.
- Filtragem das notas derivada do estado e leitura repetida de marcadores reduzida.
- Chave permanente de assinatura configurada por GitHub Actions Secret (não incluída neste ZIP).

## GitHub Actions: chave permanente

Antes de executar o workflow, crie em Settings > Secrets and variables > Actions um segredo chamado `ANDROID_SIGNING_BUNDLE` e cole o conteúdo completo de `ANDROID_SIGNING_BUNDLE.txt` fornecido separadamente.

O valor desse segredo contém a chave privada de assinatura. Nunca publique esse conteúdo no repositório, em Issues, comentários ou capturas de tela. Guarde também o arquivo `.jks` e o segredo em local privado e seguro.

O workflow gera um APK `release` assinado com essa mesma chave para todas as versões futuras.

## Observação de atualização

As versões anteriores foram assinadas com chaves de depuração diferentes. O Android não permite atualizar um APK com uma assinatura diferente. Para adotar a chave permanente pela primeira vez, será necessária uma reinstalação única. Faça backup do ZIP antes. Os dados textuais e o perfil estão na nuvem; imagens anexadas às fichas são locais e devem ser restauradas pelo ZIP de backup.
