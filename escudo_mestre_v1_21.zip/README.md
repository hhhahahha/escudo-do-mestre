# ESCUDO DO MESTRE 1.21

## Novidades
- Tela inicial reorganizada com busca, acesso ao perfil, seção de notas fixadas, cartões com capas e botão quadrado para criar nota.
- Menu lateral com Notas, marcadores em ordem alfabética, Arquivados, Lixeira e Configurações.
- Recebimento de imagens por arrastar e soltar de outros aplicativos Android. Ao soltar uma imagem dentro de uma nota, o app abre o ajuste da capa; a imagem não é inserida no texto.
- Capas compactadas em JPEG (até 512 px) e sincronizadas com as notas pelo Firestore, sem exigir Firebase Storage.
- Login, perfil, fichas, notas, marcadores, arquivo e lixeira mantidos.

## Observações
- O arrastar e soltar depende de o aplicativo de origem, como o Smart Hub do Infinix XOS, entregar a imagem ao Android como conteúdo compatível. Validar no aparelho após instalar esta versão.
- Nesta versão, o destino do Smart Hub aceita imagens como capas. PDF e outros arquivos não são convertidos em capa; imagens de páginas adicionais e imagens dentro de blocos permanecem armazenadas localmente.
- A sincronização de capas usa Firestore. As imagens são reduzidas para limitar o tamanho de cada documento; notas que ultrapassarem o limite de segurança do app não serão enviadas.
- O APK é assinado pelo GitHub Actions com a chave configurada no segredo `ANDROID_SIGNING_BUNDLE`. O arquivo de chave privada não deve ser incluído no repositório.
