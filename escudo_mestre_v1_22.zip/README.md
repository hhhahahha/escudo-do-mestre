# ESCUDO DO MESTRE 1.22

## Novidades
- Ícones dourados no menu lateral para Notas, Marcadores, Arquivados, Lixeira e Configurações.
- Toque longo em cartões para selecionar notas e acessar ações rápidas de fixar/desafixar e compartilhar.
- Alternância entre visualização em grade e em lista pelo botão no fim da barra de pesquisa.
- Compartilhamento pelo menu de três pontos dentro da nota e pela seleção por toque longo. O conteúdo textual de todas as páginas e os marcadores são enviados a outros aplicativos Android.
- Mantidos login, perfil, capas, sincronização pelo Firestore e recebimento de imagens do Smart Hub como capa.

## Observações
- A partilha externa exporta texto e marcadores. A capa não é anexada ao compartilhamento nesta versão.
- O arrastar e soltar do Smart Hub depende de o app de origem entregar uma imagem como conteúdo compatível com o Android.
- As capas continuam compactadas e sincronizadas pelo Firestore; não é necessário ativar Firebase Storage.
- O APK usa a chave permanente configurada no segredo `ANDROID_SIGNING_BUNDLE`. Não coloque a chave privada no repositório.
