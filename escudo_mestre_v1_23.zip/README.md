# ESCUDO DO MESTRE

Versão 1.23: correção do enquadramento das capas, imagem individual por página, sincronização das imagens de todas as páginas com Firestore e compartilhamento de notas em PDF com imagens.
