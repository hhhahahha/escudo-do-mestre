# ESCUDO DO MESTRE

Versão 1.24: correção do listener de layout e do recálculo das capas; imagens independentes por página mantidas; compartilhamento nativo do Android com texto e imagens originais como anexos, sem gerar PDF.
