ESCUDO DO MESTRE 1.25

Atualização com galeria de imagens para a capa, pré-visualização e arrastar imagens para o Smart Hub, além de caixinhas expansíveis de título editável em duas colunas. Mantém Firebase Auth e Firestore.
