ESCUDO DO MESTRE 1.26

Notas com caixinhas em janela flutuante, galeria de capa, carregamento assíncrono de imagens e sincronização Firestore.
