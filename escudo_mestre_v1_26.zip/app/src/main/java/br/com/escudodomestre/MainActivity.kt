package br.com.escudodomestre

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.ContextWrapper
import android.graphics.Matrix
import android.graphics.Bitmap
import android.util.Base64
import android.util.LruCache
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import android.widget.Toast
import android.widget.EditText
import android.graphics.drawable.Drawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.Spanned
import android.text.style.ReplacementSpan
import android.text.style.LeadingMarginSpan
import android.text.style.UpdateLayout
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.text.InputType
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import androidx.activity.ComponentActivity
import androidx.core.content.FileProvider
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ViewList
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Label
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Person
import androidx.compose.runtime.*
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.mimeTypes
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import com.google.gson.Gson
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.Executors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF191919)
private val Card = Color(0xFF202020)
private val CardRaised = Color(0xFF282828)
private val Ink = Color(0xFFF2F0EA)
private val Muted = Color(0xFFAAA69D)
private val Accent = Color(0xFFD6C9A8)
private val Danger = Color(0xFFE58A82)
private const val TRASH_RETENTION_MS = 7L * 24L * 60L * 60L * 1000L
private const val MAX_COVER_GALLERY_IMAGES = 6
private const val CLOUD_IMAGE_MAX_SIDE = 768
private const val CLOUD_IMAGE_JPEG_QUALITY = 78

private fun findActivity(context: Context): Activity? {
    var current = context
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}

/** Copy one original page image into a temporary FileProvider-readable location. */
private fun copyNoteImageForSharing(context: Context, source: String, index: Int): Uri? = runCatching {
    if (source.isBlank()) return null
    val directory = File(context.cacheDir, "shared-notes").apply { mkdirs() }
    val now = System.currentTimeMillis()
    directory.listFiles()?.filter {
        it.name.startsWith("share-") && now - it.lastModified() > 24L * 60L * 60L * 1000L
    }?.forEach { it.delete() }

    val sourceUri = Uri.parse(source)
    val mime = if (source.startsWith(CLOUD_COVER_PREFIX)) {
        "image/jpeg"
    } else {
        context.contentResolver.getType(sourceUri).orEmpty()
    }
    val pathExtension = sourceUri.lastPathSegment?.substringAfterLast('.', "").orEmpty().lowercase()
    val extension = when (mime.lowercase()) {
        "image/jpeg", "image/jpg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        "image/heic" -> "heic"
        "image/heif" -> "heif"
        else -> pathExtension.takeIf { it in setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "heif") }
            ?.let { if (it == "jpeg") "jpg" else it } ?: "img"
    }
    val target = File(directory, "share-${now}-$index.$extension")
    if (source.startsWith(CLOUD_COVER_PREFIX)) {
        target.writeBytes(Base64.decode(source.removePrefix(CLOUD_COVER_PREFIX), Base64.DEFAULT))
    } else {
        val input = if (sourceUri.scheme == "file") {
            sourceUri.path?.let { File(it).inputStream() }
        } else {
            context.contentResolver.openInputStream(sourceUri)
        } ?: error("Não foi possível ler uma das imagens da nota.")
        input.use { stream -> target.outputStream().use { output -> stream.copyTo(output) } }
    }
    require(target.length() > 0L) { "A imagem selecionada está vazia." }
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", target)
}.getOrNull()

private data class NoteShareImage(val source: String, val label: String)

/** Collect page headers and inline images in page order, without converting their formats. */
private fun collectNoteShareImages(note: Note): List<NoteShareImage> {
    val result = mutableListOf<NoteShareImage>()
    val seen = mutableSetOf<String>()
    normalizePages(note).forEachIndexed { pageIndex, page ->
        val pageImage = page.image.ifBlank { if (pageIndex == 0) note.cover else "" }
        val pageImages = if (pageIndex == 0 && note.coverGallery.orEmpty().isNotEmpty()) {
            note.coverGallery.orEmpty()
        } else listOf(pageImage)
        pageImages.forEachIndexed { imageIndex, image ->
            if (image.isNotBlank() && seen.add(image)) {
                val label = if (pageIndex == 0 && imageIndex > 0) "Imagem ${imageIndex + 1} da galeria da capa"
                    else "Imagem da página ${pageIndex + 1}"
                result += NoteShareImage(image, label)
            }
        }
        page.blocks.orEmpty().filter { it.kind == "image" && it.image.isNotBlank() }.forEach { block ->
            if (seen.add(block.image)) result += NoteShareImage(block.image, "Imagem do conteúdo da página ${pageIndex + 1}")
        }
        page.boxes.orEmpty().filter { it.image.isNotBlank() }.forEach { box ->
            if (seen.add(box.image)) result += NoteShareImage(box.image, "Imagem da caixa ${box.title.ifBlank { "sem título" }}")
        }
    }
    return result
}

private fun buildNoteShareText(note: Note): String = buildString {
    append(note.title.ifBlank { "Nota sem título" })
    val markers = splitValues(note.markers)
    if (markers.isNotEmpty()) append("\n\nMarcadores: ").append(markers.joinToString(", "))
    normalizePages(note).forEachIndexed { index, page ->
        append("\n\n--- Página ").append(index + 1).append(" ---\n")
        val bodyText = page.body.ifBlank {
            page.blocks.orEmpty().filter { it.kind != "image" }.joinToString("\n\n") { it.text }
        }.trim()
        if (bodyText.isNotBlank()) append(bodyText)
        page.boxes.orEmpty().forEach { box ->
            if (box.title.isNotBlank() || box.text.isNotBlank()) {
                append("\n\n▣ ").append(box.title.ifBlank { "Caixa" })
                if (box.text.isNotBlank()) append("\n").append(box.text)
                if (box.image.isNotBlank()) append("\n[Imagem anexada]")
            }
        }
        val imageCount = (if (index == 0 && note.coverGallery.orEmpty().isNotEmpty()) note.coverGallery.size
            else if (page.image.ifBlank { if (index == 0) note.cover else "" }.isNotBlank()) 1 else 0) +
            page.blocks.orEmpty().count { it.kind == "image" && it.image.isNotBlank() } +
            page.boxes.orEmpty().count { it.image.isNotBlank() }
        if (imageCount > 0) {
            if (bodyText.isNotBlank()) append("\n")
            append("[").append(imageCount).append(if (imageCount == 1) " imagem anexada]" else " imagens anexadas]")
        }
    }
    append("\n\nCompartilhado pelo ESCUDO DO MESTRE")
}

/** Use Android's native share sheet: note text plus the original page images as attachments. */
private fun shareNotesWithOtherApps(context: Context, notes: List<Note>) {
    if (notes.isEmpty()) return
    runCatching {
        val imageUris = mutableListOf<Uri>()
        val noteTexts = mutableListOf<String>()
        var imageIndex = 0
        notes.forEach { note ->
            noteTexts += buildNoteShareText(note)
            collectNoteShareImages(note).forEach { image ->
                val uri = copyNoteImageForSharing(context, image.source, imageIndex++)
                    ?: error("Não foi possível preparar ${image.label.lowercase()} para compartilhar.")
                imageUris += uri
            }
        }
        val subject = if (notes.size == 1) notes.first().title.ifBlank { "Nota do ESCUDO DO MESTRE" }
            else "${notes.size} notas do ESCUDO DO MESTRE"
        val sharedText = noteTexts.joinToString("\n\n====================\n\n")

        val sendIntent = when (imageUris.size) {
            0 -> Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, sharedText)
            }
            1 -> Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, sharedText)
                putExtra(Intent.EXTRA_STREAM, imageUris.first())
                clipData = android.content.ClipData.newUri(context.contentResolver, subject, imageUris.first())
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            else -> Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, sharedText)
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(imageUris))
                val clip = android.content.ClipData.newUri(context.contentResolver, subject, imageUris.first())
                imageUris.drop(1).forEach { clip.addItem(android.content.ClipData.Item(it)) }
                clipData = clip
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(sendIntent, "Compartilhar nota"))
    }.onFailure {
        Toast.makeText(
            context,
            "Não foi possível compartilhar a nota e suas imagens: ${it.message ?: "erro"}",
            Toast.LENGTH_LONG
        ).show()
    }
}

/**
 * Keep the old field names and String representation for markers/links so notes
 * created by version 1.0 remain readable after updating the APK.
 */
data class NoteBlock(
    val id: String = UUID.randomUUID().toString(),
    // "text" or "image". Flat fields keep Gson migration straightforward.
    val kind: String = "text",
    val text: String = "",
    val image: String = "",
    val imageWidthFraction: Float = 1f,
    val imageScale: Float = 1f,
    val imageOffsetX: Float = 0f,
    val imageOffsetY: Float = 0f,
    val imageAspectRatio: Float = 1.7778f
)

data class NoteBox(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Nova caixa",
    val text: String = "",
    val image: String = ""
)

data class NotePage(
    val id: String = UUID.randomUUID().toString(),
    val body: String = "",
    val image: String = "",
    val imageScale: Float = 1f,
    val imageOffsetX: Float = 0f,
    val imageOffsetY: Float = 0f,
    val imageAspectRatio: Float = 1.7778f,
    val blocks: List<NoteBlock> = emptyList(),
    val boxes: List<NoteBox> = emptyList()
)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val cover: String = "",
    val markers: String = "",
    val links: String = "",
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val coverScale: Float = 1f,
    val coverOffsetX: Float = 0f,
    val coverOffsetY: Float = 0f,
    val coverAspectRatio: Float = 1.7778f,
    // First item is the visible cover; later items form the note's cover gallery.
    val coverGallery: List<String> = emptyList(),
    val pages: List<NotePage> = emptyList(),
    // 0 = active note; otherwise epoch millis when moved to the trash.
    val deletedAt: Long = 0L,
    // Paper appearance is shared by all numbered pages in the same note.
    val paperTone: String = "black",
    val paperStyle: String = "blank"
)

/** ZIP backup keeps note data and the actual image bytes together, so restored images
 * do not depend on gallery URIs from the old installation. */
data class NotesBackup(
    val formatVersion: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: List<Note> = emptyList(),
    val markers: List<String> = emptyList()
)

private fun exportNotesBackup(
    context: Context,
    destination: Uri,
    notes: List<Note>,
    markers: List<String>,
    gson: Gson
) {
    val imageEntries = linkedMapOf<String, String>()
    fun archiveImageReference(value: String): String {
        if (value.isBlank()) return value
        return imageEntries.getOrPut(value) { "media/image_${imageEntries.size + 1}.bin" }
    }

    val portableNotes = notes.map { note ->
        note.copy(
            cover = archiveImageReference(note.cover),
            coverGallery = note.coverGallery.orEmpty().map(::archiveImageReference),
            pages = note.pages.orEmpty().map { page ->
                page.copy(
                    image = archiveImageReference(page.image),
                    blocks = page.blocks.orEmpty().map { block ->
                        if (block.kind == "image") block.copy(image = archiveImageReference(block.image)) else block
                    },
                    boxes = page.boxes.orEmpty().map { box -> box.copy(image = archiveImageReference(box.image)) }
                )
            }
        )
    }
    val backup = NotesBackup(notes = portableNotes, markers = markers)
    val output = context.contentResolver.openOutputStream(destination)
        ?: error("Não foi possível abrir o destino do backup.")

    ZipOutputStream(BufferedOutputStream(output)).use { zip ->
        zip.putNextEntry(ZipEntry("backup.json"))
        zip.write(gson.toJson(backup).toByteArray(Charsets.UTF_8))
        zip.closeEntry()

        imageEntries.forEach { (sourceUri, archivePath) ->
            val input = context.contentResolver.openInputStream(Uri.parse(sourceUri))
                ?: error("Não foi possível ler uma imagem da nota. Tente selecionar a imagem novamente antes do backup.")
            zip.putNextEntry(ZipEntry(archivePath))
            input.use { it.copyTo(zip) }
            zip.closeEntry()
        }
    }
}

private fun importNotesBackup(
    context: Context,
    source: Uri,
    gson: Gson
): NotesBackup {
    val root = File(context.filesDir, "restored-backup-media/${UUID.randomUUID()}").apply { mkdirs() }
    val restoredMedia = mutableMapOf<String, String>()
    var manifest: String? = null
    val input = context.contentResolver.openInputStream(source)
        ?: error("Não foi possível abrir o arquivo de backup.")

    ZipInputStream(BufferedInputStream(input)).use { zip ->
        var entry = zip.nextEntry
        while (entry != null) {
            val name = entry.name.replace('\\', '/')
            when {
                name == "backup.json" -> {
                    manifest = zip.readBytes().toString(Charsets.UTF_8)
                }
                name.startsWith("media/") && !name.contains("..") && !entry.isDirectory -> {
                    val fileName = name.substringAfterLast('/')
                    val outFile = File(root, fileName)
                    outFile.outputStream().buffered().use { zip.copyTo(it) }
                    restoredMedia[name] = Uri.fromFile(outFile).toString()
                }
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }
    }

    val json = manifest ?: error("Este arquivo não contém um backup válido do ESCUDO DO MESTRE.")
    val parsed = gson.fromJson(json, NotesBackup::class.java)
        ?: error("Não foi possível interpretar o backup.")
    if (parsed.formatVersion != 1) error("A versão deste backup não é compatível com este aplicativo.")

    fun restoreImage(value: String): String = restoredMedia[value] ?: value
    val restoredNotes = parsed.notes.map { note ->
        note.copy(
            cover = restoreImage(note.cover),
            coverGallery = note.coverGallery.orEmpty().map(::restoreImage),
            pages = note.pages.orEmpty().map { page ->
                page.copy(
                    image = restoreImage(page.image),
                    blocks = page.blocks.orEmpty().map { block ->
                        if (block.kind == "image") block.copy(image = restoreImage(block.image)) else block
                    },
                    boxes = page.boxes.orEmpty().map { box -> box.copy(image = restoreImage(box.image)) }
                )
            }
        )
    }
    return parsed.copy(notes = restoredNotes)
}

private const val CLOUD_COVER_PREFIX = "cloud-cover:"

/**
 * Firestore is used without Firebase Storage. Each numbered page image is compacted
 * to a small JPEG data payload inside the note JSON. The local original stays untouched.
 */
private fun encodeCoverForCloud(context: Context, imageUri: String): String? = runCatching {
    if (imageUri.isBlank()) return null
    if (imageUri.startsWith(CLOUD_COVER_PREFIX)) return imageUri
    val uri = Uri.parse(imageUri)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    val boundsStream = if (uri.scheme == "file") uri.path?.let { File(it).inputStream() }
        else context.contentResolver.openInputStream(uri)
    boundsStream?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > CLOUD_IMAGE_MAX_SIDE * 2) sample *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample.coerceAtLeast(1)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val input = if (uri.scheme == "file") uri.path?.let { File(it).inputStream() }
        else context.contentResolver.openInputStream(uri)
    val source = input?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
    val maxSide = max(source.width, source.height)
    val outputBitmap = if (maxSide > CLOUD_IMAGE_MAX_SIDE) {
        val ratio = CLOUD_IMAGE_MAX_SIDE / maxSide.toFloat()
        Bitmap.createScaledBitmap(source,
            (source.width * ratio).toInt().coerceAtLeast(1),
            (source.height * ratio).toInt().coerceAtLeast(1), true)
    } else source
    val output = ByteArrayOutputStream()
    outputBitmap.compress(Bitmap.CompressFormat.JPEG, CLOUD_IMAGE_JPEG_QUALITY, output)
    if (outputBitmap !== source && !outputBitmap.isRecycled) outputBitmap.recycle()
    if (!source.isRecycled) source.recycle()
    CLOUD_COVER_PREFIX + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
}.getOrNull()

private fun saveCloudCoverLocally(context: Context, noteId: String, pageId: String, cloudValue: String): String? = runCatching {
    val encoded = cloudValue.removePrefix(CLOUD_COVER_PREFIX)
    val bytes = Base64.decode(encoded, Base64.DEFAULT)
    val directory = File(context.filesDir, "cloud-note-covers").apply { mkdirs() }
    val safeNote = noteId.replace(Regex("[^A-Za-z0-9_-]"), "_")
    val safePage = pageId.replace(Regex("[^A-Za-z0-9_-]"), "_")
    val file = File(directory, "${safeNote}_${safePage}.jpg")
    file.writeBytes(bytes)
    Uri.fromFile(file).toString()
}.getOrNull()

private fun noteForCloud(context: Context, note: Note): Note {
    val pages = note.pages.orEmpty().mapIndexed { index, page ->
        val pageImage = page.image.ifBlank { if (index == 0) note.cover else "" }
        page.copy(
            image = if (pageImage.isNotBlank()) encodeCoverForCloud(context, pageImage).orEmpty() else "",
            blocks = page.blocks.orEmpty().map { block ->
                if (block.kind == "image") block.copy(image = "") else block
            },
            boxes = page.boxes.orEmpty().map { box ->
                box.copy(image = if (box.image.isNotBlank()) encodeCoverForCloud(context, box.image).orEmpty() else "")
            }
        )
    }
    val gallery = note.coverGallery.orEmpty().map { image ->
        if (image.isNotBlank()) encodeCoverForCloud(context, image).orEmpty() else ""
    }
    return note.copy(cover = "", coverGallery = gallery, pages = pages)
}

private fun mergeCloudNoteMedia(context: Context, cloud: Note, local: Note?): Note {
    val localPages = local?.pages.orEmpty().associateBy { it.id }
    val mergedPages = cloud.pages.orEmpty().map { cloudPage ->
        val localPage = localPages[cloudPage.id]
        val localBlocks = localPage?.blocks.orEmpty().associateBy { it.id }
        val localBoxes = localPage?.boxes.orEmpty().associateBy { it.id }
        val cloudImage = cloudPage.image.takeIf { it.startsWith(CLOUD_COVER_PREFIX) }
            ?.let { saveCloudCoverLocally(context, cloud.id, cloudPage.id, it) }
        cloudPage.copy(
            image = cloudImage ?: localPage?.image?.takeIf { it.isNotBlank() } ?: cloudPage.image,
            blocks = cloudPage.blocks.orEmpty().map { cloudBlock ->
                val localBlock = localBlocks[cloudBlock.id]
                if (cloudBlock.kind == "image" && !localBlock?.image.isNullOrBlank()) cloudBlock.copy(image = localBlock!!.image)
                else cloudBlock
            },
            boxes = cloudPage.boxes.orEmpty().map { cloudBox ->
                val localBox = localBoxes[cloudBox.id]
                val decoded = cloudBox.image.takeIf { it.startsWith(CLOUD_COVER_PREFIX) }
                    ?.let { saveCloudCoverLocally(context, cloud.id, "${cloudPage.id}_${cloudBox.id}", it) }
                cloudBox.copy(image = decoded ?: localBox?.image?.takeIf { it.isNotBlank() } ?: cloudBox.image)
            }
        )
    }
    val localGallery = local?.coverGallery.orEmpty()
    val mergedGallery = cloud.coverGallery.orEmpty().mapIndexedNotNull { index, value ->
        val decoded = value.takeIf { it.startsWith(CLOUD_COVER_PREFIX) }
            ?.let { saveCloudCoverLocally(context, cloud.id, "gallery_$index", it) }
        (decoded ?: localGallery.getOrNull(index)?.takeIf { it.isNotBlank() } ?: value)
            .takeIf { it.isNotBlank() }
    }
    val gallery = mergedGallery.ifEmpty { localGallery }
    return cloud.copy(
        cover = gallery.firstOrNull() ?: mergedPages.firstOrNull()?.image?.takeIf { it.isNotBlank() }
            ?: local?.cover?.takeIf { it.isNotBlank() } ?: cloud.cover,
        coverGallery = gallery,
        pages = mergedPages
    )
}

/** Copy dropped content into app-owned storage so it remains available after the drag permission ends. */
private fun copyDroppedImageToApp(context: Context, source: Uri, mimeHint: String = ""): String? = runCatching {
    val mime = context.contentResolver.getType(source).orEmpty().ifBlank { mimeHint }
    require(mime.startsWith("image/", ignoreCase = true)) { "O Smart Hub precisa entregar uma imagem." }
    val extension = when (mime.substringAfter('/').substringBefore(';').lowercase()) {
        "jpeg", "jpg" -> "jpg"
        "png" -> "png"
        "webp" -> "webp"
        "gif" -> "gif"
        else -> "img"
    }
    val directory = File(context.filesDir, "note-covers").apply { mkdirs() }
    val target = File(directory, "cover_${UUID.randomUUID()}.$extension")
    val input = context.contentResolver.openInputStream(source)
        ?: error("Não foi possível ler a imagem recebida.")
    input.use { stream -> target.outputStream().use { output -> stream.copyTo(output) } }
    Uri.fromFile(target).toString()
}.getOrNull()

/** Store a compact square avatar in Firestore, avoiding the paid Storage product. */
private fun encodeProfilePhoto(context: Context, uriString: String): String? = runCatching {
    if (uriString.isBlank()) return null
    val uri = Uri.parse(uriString)
    val source = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        ?: return null
    val side = minOf(source.width, source.height)
    val left = (source.width - side) / 2
    val top = (source.height - side) / 2
    val square = Bitmap.createBitmap(source, left, top, side, side)
    val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)
    val output = ByteArrayOutputStream()
    scaled.compress(Bitmap.CompressFormat.JPEG, 68, output)
    if (square !== source && !square.isRecycled) square.recycle()
    if (scaled !== source && !scaled.isRecycled) scaled.recycle()
    if (source !== square && !source.isRecycled) source.recycle()
    Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
}.getOrNull()

private fun cropProfilePhotoToFile(
    context: Context,
    uri: Uri,
    zoom: Float,
    offsetX: Float,
    offsetY: Float
): String? = runCatching {
    val source = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        ?: return null
    val side = (minOf(source.width, source.height) / zoom.coerceIn(1f, 4f)).toInt().coerceAtLeast(1)
    val centerX = (source.width / 2f - offsetX.coerceIn(-1f, 1f) * ((source.width - side) / 2f))
        .toInt().coerceIn(side / 2, source.width - (side - side / 2))
    val centerY = (source.height / 2f - offsetY.coerceIn(-1f, 1f) * ((source.height - side) / 2f))
        .toInt().coerceIn(side / 2, source.height - (side - side / 2))
    val left = (centerX - side / 2).coerceIn(0, source.width - side)
    val top = (centerY - side / 2).coerceIn(0, source.height - side)
    val cropped = Bitmap.createBitmap(source, left, top, side, side)
    val outputBitmap = Bitmap.createScaledBitmap(cropped, 512, 512, true)
    val file = File(context.filesDir, "profile-avatar.jpg")
    file.outputStream().use { outputBitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
    if (cropped !== source && !cropped.isRecycled) cropped.recycle()
    if (outputBitmap !== source && !outputBitmap.isRecycled) outputBitmap.recycle()
    if (!source.isRecycled) source.recycle()
    Uri.fromFile(file).toString()
}.getOrNull()

private fun saveCloudProfilePhoto(context: Context, encoded: String): String? = runCatching {
    if (encoded.isBlank()) return null
    val bytes = Base64.decode(encoded, Base64.DEFAULT)
    val file = File(context.filesDir, "profile-avatar-cloud.jpg")
    file.writeBytes(bytes)
    Uri.fromFile(file).toString()
}.getOrNull()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp() }
    }
}

private fun splitValues(raw: String): List<String> = raw
    .split(',', '\n')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .distinctBy { it.lowercase() }

private fun parseIds(raw: String): Set<String> = raw
    .split(',')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .toSet()

private fun safeScale(note: Note): Float = note.coverScale.takeIf { it >= 1f } ?: 1f

private fun safeAspectRatio(value: Float, fallback: Float = 1.7778f): Float =
    (value.takeIf { it.isFinite() && it > 0.05f } ?: fallback).coerceIn(0.25f, 4f)

private fun collapseAdjacentTextBlocks(source: List<NoteBlock>): List<NoteBlock> {
    val result = mutableListOf<NoteBlock>()
    source.forEach { block ->
        val previous = result.lastOrNull()
        if (block.kind != "image" && previous != null && previous.kind != "image") {
            val separator = if (previous.text.isNotEmpty() && block.text.isNotEmpty()) "\n\n" else ""
            result[result.lastIndex] = previous.copy(text = previous.text + separator + block.text)
        } else {
            result.add(block)
        }
    }
    if (result.isEmpty()) result.add(NoteBlock())
    if (result.last().kind == "image") result.add(NoteBlock())
    return result
}

private fun normalizePageBlocks(page: NotePage): List<NoteBlock> {
    val saved = page.blocks.orEmpty()
    if (saved.isNotEmpty()) {
        val normalized = saved.map { block ->
            if (block.kind == "image") block.copy(
                imageWidthFraction = block.imageWidthFraction.takeIf { it.isFinite() }?.coerceIn(0.15f, 1f) ?: 1f,
                imageScale = block.imageScale.takeIf { it.isFinite() && it >= 1f } ?: 1f,
                imageAspectRatio = safeAspectRatio(block.imageAspectRatio)
            ) else block
        }
        return collapseAdjacentTextBlocks(normalized)
    }
    return listOf(NoteBlock(text = page.body))
}

/** Native editor that keeps notebook guides aligned to the actual text baselines. */
private class NoteEditText(context: Context) : EditText(context) {
    var applyingModel: Boolean = false
    var renderedVersion: Int = -1
    var paperStyle: String = "blank"
    var paperTone: String = "black"
    var paperStepPx: Float = 0f
    private var imageMarginReflowPosted: Boolean = false

    /**
     * Recalculate the wrap height from the real TextView layout, not from a
     * guessed line-height. TextView.getLineHeight() can differ from the actual
     * laid-out baselines (font padding, line spacing, accessibility font scale,
     * and OEM text metrics all affect it). When the estimate is too large, the
     * text remains trapped in the side column below the image.
     *
     * We count only visual lines whose top is still above the image bottom.
     * This also grows the margin as the user types more text next to a tall image.
     */
    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        updateImageFlowLineCounts()
    }

    private fun updateImageFlowLineCounts() {
        if (imageMarginReflowPosted) return
        val textLayout = layout ?: return
        // Editable is required because changing a custom span's internal line
        // count does not, by itself, notify TextView that its cached StaticLayout
        // is stale. We re-attach the UpdateLayout span below so TextView rebuilds
        // the paragraph layout without replacing the Editable or disturbing IME
        // composing text / cursor position.
        val editable = text as? Editable ?: return
        if (editable.isEmpty() || textLayout.lineCount <= 0) return

        var needsReflow = false
        val spans = editable.getSpans(0, editable.length, ImageFlowMarginSpan::class.java)
        spans.forEach { span ->
            // The image anchor is a real span, so its offset follows the cursor as
            // the user inserts or deletes text before the picture.
            val imageOffset = editable.getSpanStart(span.imageAnchor)
            val paragraphStart = editable.getSpanStart(span)
            val paragraphEnd = editable.getSpanEnd(span)
            if (imageOffset < 0 || paragraphStart < 0 || paragraphEnd <= paragraphStart) return@forEach

            val imageLine = textLayout.getLineForOffset(imageOffset.coerceIn(0, editable.length - 1))
                .coerceIn(0, textLayout.lineCount - 1)
            val imageTop = textLayout.getLineTop(imageLine)
            val imageBottom = imageTop + span.imageHeightPx

            // The span is paragraph-scoped. Count only this paragraph's visual
            // lines whose vertical boxes intersect the image rectangle. Since
            // imageBottom is absolute in the TextView layout, later paragraphs
            // naturally receive zero lines once they begin below the image.
            val firstLine = textLayout.getLineForOffset(paragraphStart)
                .coerceIn(0, textLayout.lineCount - 1)
            val lastOffset = (paragraphEnd - 1).coerceIn(paragraphStart, editable.length - 1)
            val lastLine = textLayout.getLineForOffset(lastOffset)
                .coerceIn(firstLine, textLayout.lineCount - 1)

            var occupiedLines = 0
            for (line in firstLine..lastLine) {
                val lineTop = textLayout.getLineTop(line)
                val lineBottom = textLayout.getLineBottom(line)
                if (lineTop >= imageBottom) break
                if (lineTop < imageBottom && lineBottom > imageTop) occupiedLines++
            }

            if (span.updateLineCount(occupiedLines)) {
                // LeadingMarginSpan2 values are read when TextView builds its
                // layout. Merely calling requestLayout() leaves TextView's cached
                // StaticLayout unchanged. Remove/re-add this UpdateLayout span to
                // fire TextView's SpanWatcher and force a true text reflow. The
                // Editable itself is retained, so selection and typing continue.
                val start = editable.getSpanStart(span)
                val end = editable.getSpanEnd(span)
                val flags = editable.getSpanFlags(span)
                if (start >= 0 && end > start) {
                    editable.removeSpan(span)
                    editable.setSpan(span, start, end, flags)
                    needsReflow = true
                }
            }
        }

        if (needsReflow && !imageMarginReflowPosted) {
            imageMarginReflowPosted = true
            post {
                imageMarginReflowPosted = false
                requestLayout()
                invalidate()
            }
        }
    }

    override fun onDraw(canvas: AndroidCanvas) {
        if (paperStyle == "ruled" || paperStyle == "grid") {
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = resources.displayMetrics.density * 0.7f
                color = if (paperTone == "white") {
                    android.graphics.Color.argb(58, 35, 35, 35)
                } else {
                    android.graphics.Color.argb(66, 235, 235, 235)
                }
            }
            val step = paperStepPx.takeIf { it > 0f } ?: (26f * resources.displayMetrics.density)
            val textLayout = layout
            val firstBaseline = if (textLayout != null && textLayout.lineCount > 0) {
                textLayout.getLineBaseline(0).toFloat()
            } else {
                -paint.fontMetrics.ascent
            }

            var y = firstBaseline
            while (y < height + step) {
                if (y >= 0f) canvas.drawLine(paddingLeft.toFloat(), y, (width - paddingRight).toFloat(), y, linePaint)
                y += step
            }

            if (paperStyle == "grid") {
                var x = paddingLeft.toFloat()
                while (x <= width - paddingRight) {
                    canvas.drawLine(x, 0f, x, height.toFloat(), linePaint)
                    x += step
                }
            }
        }

        // Draw the text first. The inline-image margin span only reserves the text
        // column; drawing the bitmap from drawLeadingMargin caused Android to clip
        // and replay the top strip once per visual line. Paint each image exactly
        // once here, anchored to the first text line of its paragraph.
        super.onDraw(canvas)
        val editable = text as? Spanned ?: return
        val textLayout = layout ?: return
        val imageSpans = editable.getSpans(0, editable.length, NoteInlineImageSpan::class.java)
        imageSpans.forEach { span ->
            val spanStart = editable.getSpanStart(span)
            if (spanStart < 0 || spanStart >= editable.length) return@forEach
            val line = textLayout.getLineForOffset(spanStart)
            val direction = textLayout.getParagraphDirection(line)
            val imageWidth = span.drawable.bounds.width()
            val imageHeight = span.drawable.bounds.height()
            val left = if (direction >= 0) {
                compoundPaddingLeft - scrollX
            } else {
                width - compoundPaddingRight - imageWidth + scrollX
            }
            val top = extendedPaddingTop + textLayout.getLineTop(line) - scrollY
            val right = left + imageWidth
            val bottom = top + imageHeight
            if (right <= 0 || left >= width || bottom <= 0 || top >= height) return@forEach

            val save = canvas.save()
            canvas.clipRect(0, 0, width, height)
            canvas.translate(left.toFloat(), top.toFloat())
            span.drawable.setBounds(0, 0, imageWidth, imageHeight)
            span.drawable.draw(canvas)
            canvas.restoreToCount(save)
        }
    }
}

/** Zero-width anchor: the image itself is painted in the paragraph's leading margin. */
private class NoteInlineImageSpan(val block: NoteBlock, val drawable: Drawable) : ReplacementSpan() {
    override fun getSize(
        paint: Paint,
        text: CharSequence,
        start: Int,
        end: Int,
        fm: Paint.FontMetricsInt?
    ): Int = 0

    override fun draw(
        canvas: AndroidCanvas,
        text: CharSequence,
        start: Int,
        end: Int,
        x: Float,
        top: Int,
        y: Int,
        bottom: Int,
        paint: Paint
    ) = Unit
}

/**
 * Floats the image in the paragraph's left margin. Text receives the remaining
 * column beside the image, then expands to the full width after its height ends.
 */
private class ImageFlowMarginSpan(
    val imageAnchor: NoteInlineImageSpan,
    val imageWidthPx: Int,
    val imageHeightPx: Int,
    initialImageLineCount: Int,
    private val gapPx: Int
) : LeadingMarginSpan.LeadingMarginSpan2, UpdateLayout {
    @Volatile
    private var measuredImageLineCount: Int = initialImageLineCount.coerceAtLeast(0)

    /** Returns true only when the layout must be recalculated. */
    val currentImageLineCount: Int
        get() = measuredImageLineCount

    fun updateLineCount(value: Int): Boolean {
        val safeValue = value.coerceAtLeast(0)
        if (measuredImageLineCount == safeValue) return false
        measuredImageLineCount = safeValue
        return true
    }

    // LeadingMarginSpan2 marks only the first N visual lines as `first=true`.
    // The count is continuously measured from the actual layout, so the next
    // line after the image bottom returns to the full page width.
    override fun getLeadingMargin(first: Boolean): Int =
        if (first) imageWidthPx + gapPx else 0

    override fun getLeadingMarginLineCount(): Int = measuredImageLineCount

    override fun drawLeadingMargin(
        c: AndroidCanvas,
        p: Paint,
        x: Int,
        dir: Int,
        top: Int,
        baseline: Int,
        bottom: Int,
        text: CharSequence,
        start: Int,
        end: Int,
        first: Boolean,
        layout: Layout
    ) {
        // Intentionally empty. The bitmap is painted once by NoteEditText.onDraw;
        // LeadingMarginSpan only controls how many lines reserve the side column.
    }
}

private fun configurePaperEditor(edit: NoteEditText, style: String, tone: String) {
    edit.paperStyle = style
    edit.paperTone = tone
    val step = 26f * edit.resources.displayMetrics.density
    edit.paperStepPx = step
    if (style == "ruled" || style == "grid") {
        val metrics = edit.paint.fontMetrics
        val fontHeight = metrics.descent - metrics.ascent
        edit.setLineSpacing((step - fontHeight).coerceAtLeast(0f), 1f)
    } else {
        edit.setLineSpacing(0f, 1.25f)
    }
    edit.invalidate()
}

private fun loadInlineDrawable(context: Context, block: NoteBlock, availableWidthPx: Int): Drawable? {
    return runCatching {
        val uri = Uri.parse(block.image)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null
        val targetWidth = (availableWidthPx * block.imageWidthFraction.coerceIn(0.15f, 1f)).toInt().coerceAtLeast(72)
        val targetHeight = (targetWidth / safeAspectRatio(block.imageAspectRatio)).toInt().coerceAtLeast(48)
        var sample = 1
        while (bounds.outWidth / sample > targetWidth * 2 || bounds.outHeight / sample > targetHeight * 2) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            ?: return@runCatching null
        BitmapDrawable(context.resources, bitmap).apply { setBounds(0, 0, targetWidth, targetHeight) }
    }.getOrNull()
}

private fun blocksToEditable(
    context: Context,
    blocks: List<NoteBlock>,
    availableWidthPx: Int,
    actualLineHeightPx: Int
): SpannableStringBuilder {
    val builder = SpannableStringBuilder()
    val flowImages = mutableListOf<Triple<Int, NoteBlock, NoteInlineImageSpan>>()
    collapseAdjacentTextBlocks(blocks).forEach { block ->
        if (block.kind == "image") {
            // A float starts a new paragraph. Following text shares the free column
            // at the right until the image's bottom, then returns to full width.
            if (builder.isNotEmpty() && builder.last() != '\n') builder.append('\n')
            val start = builder.length
            builder.append('\uFFFC')
            val drawable = loadInlineDrawable(context, block, availableWidthPx)
            if (drawable != null) {
                val imageAnchor = NoteInlineImageSpan(block, drawable)
                builder.setSpan(imageAnchor, start, start + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                flowImages.add(Triple(start, block, imageAnchor))
            } else {
                builder.replace(start, start + 1, "[imagem indisponível]")
            }
        } else {
            builder.append(block.text)
        }
    }

    val density = context.resources.displayMetrics.density
    // Seed the span with an estimate. NoteEditText.onLayout replaces this with
    // a count measured from the actual visual line positions before the final draw.
    val lineHeight = actualLineHeightPx.coerceAtLeast((14f * density).toInt().coerceAtLeast(1))
    val gapPx = (7f * density).toInt().coerceAtLeast(1)

    val orderedImages = flowImages.sortedBy { it.first }
    orderedImages.forEachIndexed { imageIndex, (imageStart, _, imageAnchor) ->
        val drawable = imageAnchor.drawable
        val nextImageStart = orderedImages.getOrNull(imageIndex + 1)?.first ?: builder.length
        val imageHeight = drawable.bounds.height()
        val estimatedLineCount = kotlin.math.ceil(imageHeight.toFloat() / lineHeight.toFloat())
            .toInt().coerceAtLeast(1)

        // LeadingMarginSpan2 is paragraph-scoped on Android. Applying one span
        // only to the paragraph where the image anchor lives makes later text
        // paragraphs jump to inconsistent columns. Attach a companion span to
        // every paragraph up to the next image, then measure each paragraph's
        // actual vertical overlap with the image in NoteEditText.onLayout().
        var paragraphStart = imageStart
        var firstParagraph = true
        while (paragraphStart < nextImageStart && paragraphStart < builder.length) {
            val newline = builder.indexOf("\n", paragraphStart)
            val paragraphEnd = if (newline >= 0 && newline < nextImageStart) {
                newline + 1
            } else {
                nextImageStart
            }
            if (paragraphEnd <= paragraphStart) break

            builder.setSpan(
                ImageFlowMarginSpan(
                    imageAnchor = imageAnchor,
                    imageWidthPx = drawable.bounds.width(),
                    imageHeightPx = imageHeight,
                    // Later paragraphs begin with no side margin. The first real
                    // TextView layout determines whether they still intersect the
                    // image; onLayout then activates only the lines that overlap.
                    // Seeding them with one line traps paragraphs below tall images
                    // when OEM TextView layout does not invalidate cached spans.
                    initialImageLineCount = if (firstParagraph) estimatedLineCount else 0,
                    gapPx = gapPx
                ),
                paragraphStart,
                paragraphEnd,
                Spanned.SPAN_PARAGRAPH
            )
            paragraphStart = paragraphEnd
            firstParagraph = false
        }
    }
    return builder
}

private fun editableToBlocks(editable: Editable): List<NoteBlock> {
    val spans = editable.getSpans(0, editable.length, NoteInlineImageSpan::class.java)
        .sortedBy { editable.getSpanStart(it) }
    if (spans.isEmpty()) return listOf(NoteBlock(text = editable.toString()))

    val result = mutableListOf<NoteBlock>()
    var cursor = 0
    spans.forEach { span ->
        val start = editable.getSpanStart(span).coerceIn(cursor, editable.length)
        val end = editable.getSpanEnd(span).coerceIn(start, editable.length)
        if (start > cursor) result.add(NoteBlock(text = editable.subSequence(cursor, start).toString()))
        if (end > start) result.add(span.block)
        cursor = end
    }
    if (cursor < editable.length) result.add(NoteBlock(text = editable.subSequence(cursor, editable.length).toString()))
    return collapseAdjacentTextBlocks(result)
}

private fun caretOffsetAfterImage(blocks: List<NoteBlock>, imageId: String): Int {
    var offset = 0
    var previousCharacter: Char? = null
    blocks.forEach { block ->
        if (block.kind == "image") {
            if (offset > 0 && previousCharacter != '\n') offset += 1 // synthetic paragraph break added by blocksToEditable
            if (block.id == imageId) return offset + 1
            offset += 1
            previousCharacter = '\uFFFC'
        } else {
            offset += block.text.length
            if (block.text.isNotEmpty()) previousCharacter = block.text.last()
        }
    }
    return offset
}

private fun locateTextBlockAtCursor(blocks: List<NoteBlock>, cursorPosition: Int): Pair<String, Int>? {
    var remaining = cursorPosition.coerceAtLeast(0)
    blocks.forEach { block ->
        if (block.kind == "image") {
            remaining = (remaining - 1).coerceAtLeast(0)
        } else {
            if (remaining <= block.text.length) return block.id to remaining
            remaining -= block.text.length
        }
    }
    val lastText = blocks.lastOrNull { it.kind != "image" } ?: return null
    return lastText.id to lastText.text.length
}

private fun pageBodyFromBlocks(blocks: List<NoteBlock>): String =
    blocks.filter { it.kind != "image" }.joinToString("\n\n") { it.text }

private fun normalizePages(note: Note): List<NotePage> {
    val stored = note.pages.orEmpty()
    if (stored.isNotEmpty()) {
        return stored.map { page ->
            val normalizedBlocks = normalizePageBlocks(page)
            page.copy(
                imageScale = page.imageScale.takeIf { it >= 1f } ?: 1f,
                imageAspectRatio = safeAspectRatio(page.imageAspectRatio),
                blocks = normalizedBlocks,
                body = pageBodyFromBlocks(normalizedBlocks)
            )
        }
    }
    // Migration for notes created before numbered pages existed.
    val firstBlocks = listOf(NoteBlock(text = note.body))
    return listOf(
        NotePage(
            body = note.body,
            image = note.cover,
            imageScale = note.coverScale.takeIf { it >= 1f } ?: 1f,
            imageOffsetX = note.coverOffsetX,
            imageOffsetY = note.coverOffsetY,
            imageAspectRatio = safeAspectRatio(note.coverAspectRatio),
            blocks = firstBlocks
        )
    )
}

private fun readImageAspectRatio(context: Context, uri: Uri): Float {
    return runCatching {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        if (options.outWidth > 0 && options.outHeight > 0) {
            safeAspectRatio(options.outWidth.toFloat() / options.outHeight.toFloat())
        } else 1.7778f
    }.getOrDefault(1.7778f)
}

private fun applyCoverMatrix(view: ImageView, scale: Float, offsetX: Float, offsetY: Float) {
    val drawable = view.drawable ?: return
    val viewW = view.width.toFloat()
    val viewH = view.height.toFloat()
    val imageW = drawable.intrinsicWidth.toFloat()
    val imageH = drawable.intrinsicHeight.toFloat()
    if (viewW <= 0f || viewH <= 0f || imageW <= 0f || imageH <= 0f) return

    val fit = max(viewW / imageW, viewH / imageH)
    val finalScale = fit * scale.coerceAtLeast(1f)
    val drawnW = imageW * finalScale
    val drawnH = imageH * finalScale
    // Pan only inside the crop overflow. This prevents empty bands from appearing
    // when a Lazy grid reuses or remeasures a card after scrolling.
    val overflowX = ((drawnW - viewW) / 2f).coerceAtLeast(0f)
    val overflowY = ((drawnH - viewH) / 2f).coerceAtLeast(0f)
    val tx = (viewW - drawnW) / 2f + offsetX.coerceIn(-1f, 1f) * overflowX
    val ty = (viewH - drawnH) / 2f + offsetY.coerceIn(-1f, 1f) * overflowY
    val matrix = Matrix().apply {
        setScale(finalScale, finalScale)
        postTranslate(tx, ty)
    }
    view.imageMatrix = matrix
}

@Composable
fun EscudoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("escudo_notas", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }
    val noteType = remember { object : TypeToken<List<Note>>() {}.type }
    val markerType = remember { object : TypeToken<List<String>>() {}.type }

    val notes = remember {
        mutableStateListOf<Note>().apply {
            val loaded = runCatching {
                gson.fromJson<List<Note>>(prefs.getString("notes", "[]"), noteType)
            }.getOrNull().orEmpty()
            val cutoff = System.currentTimeMillis() - TRASH_RETENTION_MS
            val retained = loaded.filter { it.deletedAt <= 0L || it.deletedAt > cutoff }
            val normalized = retained.map { old ->
                // Keep notes from older APKs readable while introducing numbered pages.
                val normalizedPages = normalizePages(old)
                val legacyCover = normalizedPages.firstOrNull()?.image?.takeIf { it.isNotBlank() } ?: old.cover
                val gallery = old.coverGallery.orEmpty().filter { it.isNotBlank() }.ifEmpty {
                    listOf(legacyCover).filter { it.isNotBlank() }
                }.distinct().take(MAX_COVER_GALLERY_IMAGES)
                val pagesWithGalleryCover = normalizedPages.mapIndexed { index, page ->
                    if (index == 0 && gallery.isNotEmpty()) page.copy(image = gallery.first()) else page.copy(boxes = page.boxes.orEmpty())
                }
                old.copy(
                    coverScale = safeScale(old),
                    pages = pagesWithGalleryCover,
                    body = pagesWithGalleryCover.firstOrNull()?.body ?: old.body,
                    cover = gallery.firstOrNull() ?: legacyCover,
                    coverGallery = gallery,
                    coverAspectRatio = pagesWithGalleryCover.firstOrNull()?.imageAspectRatio
                        ?: safeAspectRatio(old.coverAspectRatio)
                )
            }
            addAll(normalized)
            if (normalized.size != loaded.size) {
                prefs.edit().putString("notes", gson.toJson(normalized)).apply()
            }
        }
    }
    val savedMarkers = remember {
        mutableStateListOf<String>().apply {
            val fromPrefs = runCatching {
                gson.fromJson<List<String>>(prefs.getString("saved_markers", "[]"), markerType)
            }.getOrNull().orEmpty()
            val fromNotes = notes.flatMap { splitValues(it.markers) }
            addAll((fromPrefs + fromNotes).distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
        }
    }

    var search by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var showingArchived by remember { mutableStateOf(false) }
    var showingTrash by remember { mutableStateOf(false) }
    var activeMarker by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<NotesBackup?>(null) }

    val firebaseAuth = remember { FirebaseAuth.getInstance() }
    val firestore = remember { FirebaseFirestore.getInstance() }
    val appScope = rememberCoroutineScope()
    val localSaveExecutor = remember { Executors.newSingleThreadExecutor() }
    val localSaveVersion = remember { AtomicLong(0L) }
    val cloudWriteVersion = remember { AtomicLong(0L) }
    var cloudWriteJob by remember { mutableStateOf<Job?>(null) }
    var cloudUserId by remember { mutableStateOf(firebaseAuth.currentUser?.uid) }
    var cloudReadyUserId by remember { mutableStateOf<String?>(null) }
    var cloudSyncMessage by remember { mutableStateOf<String?>(null) }

    DisposableEffect(localSaveExecutor) {
        onDispose { localSaveExecutor.shutdown() }
    }

    DisposableEffect(firebaseAuth) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            cloudWriteVersion.incrementAndGet()
            cloudWriteJob?.cancel()
            cloudUserId = auth.currentUser?.uid
            cloudReadyUserId = null
        }
        firebaseAuth.addAuthStateListener(listener)
        onDispose { firebaseAuth.removeAuthStateListener(listener) }
    }

    fun pushCloudSnapshot(
        uid: String,
        localNotes: List<Note>,
        localMarkers: List<String>,
        version: Long
    ) {
        val userRoot = firestore.collection("users").document(uid)
        val notesCollection = userRoot.collection("notes")
        appScope.launch {
            // JSON conversion and size checks stay off the UI thread.
            val payloads = withContext(Dispatchers.Default) {
                localNotes.mapIndexedNotNull { index, note ->
                    val json = gson.toJson(noteForCloud(context, note))
                    if (json.toByteArray(Charsets.UTF_8).size <= 800_000) {
                        note.id to mapOf(
                            "json" to json,
                            "position" to index,
                            "updatedAt" to System.currentTimeMillis()
                        )
                    } else null
                }
            }
            if (version != cloudWriteVersion.get() || firebaseAuth.currentUser?.uid != uid) return@launch
            val localIds = localNotes.map { it.id }.toSet()
            val oversizedCount = localNotes.size - payloads.size
            notesCollection.get()
                .addOnSuccessListener { remote ->
                    if (version != cloudWriteVersion.get() || firebaseAuth.currentUser?.uid != uid) return@addOnSuccessListener
                    val operationsCount = remote.documents.count { it.id !in localIds } + payloads.size + 1
                    if (operationsCount > 500) {
                        cloudSyncMessage = "Muitas fichas para uma única sincronização. Seus dados locais foram preservados."
                        return@addOnSuccessListener
                    }
                    val batch = firestore.batch()
                    remote.documents.filterNot { it.id in localIds }.forEach { batch.delete(it.reference) }
                    payloads.forEach { (noteId, data) -> batch.set(notesCollection.document(noteId), data) }
                    batch.set(
                        userRoot.collection("metadata").document("main"),
                        mapOf("markersJson" to gson.toJson(localMarkers), "updatedAt" to System.currentTimeMillis())
                    )
                    batch.commit()
                        .addOnSuccessListener {
                            if (version == cloudWriteVersion.get() && firebaseAuth.currentUser?.uid == uid) {
                                cloudSyncMessage = if (oversizedCount > 0) {
                                    "Sincronização concluída, mas $oversizedCount ficha(s) excedem o limite da nuvem."
                                } else "Sincronização concluída."
                            }
                        }
                        .addOnFailureListener { error ->
                            if (version == cloudWriteVersion.get()) {
                                cloudSyncMessage = "Falha ao sincronizar: ${error.message ?: "erro de rede"}"
                            }
                        }
                }
                .addOnFailureListener { error ->
                    if (version == cloudWriteVersion.get()) {
                        cloudSyncMessage = "Não foi possível acessar a nuvem: ${error.message ?: "erro de rede"}"
                    }
                }
            if (oversizedCount > 0 && version == cloudWriteVersion.get()) {
                cloudSyncMessage = "Sincronizando. $oversizedCount ficha(s) são grandes demais para a nuvem."
            }
        }
    }

    fun scheduleCloudSnapshot(uid: String) {
        // Editor autosaves can fire repeatedly while typing. Collapse that burst into one
        // cloud transaction after the user pauses, rather than querying/writing on every key.
        val version = cloudWriteVersion.incrementAndGet()
        val localNotes = notes.toList()
        val localMarkers = savedMarkers.toList()
        cloudWriteJob?.cancel()
        cloudWriteJob = appScope.launch {
            delay(1_100)
            if (version == cloudWriteVersion.get() && firebaseAuth.currentUser?.uid == uid) {
                pushCloudSnapshot(uid, localNotes, localMarkers, version)
            }
        }
    }

    LaunchedEffect(cloudUserId) {
        val uid = cloudUserId
        cloudReadyUserId = null
        if (uid == null) {
            cloudSyncMessage = "Dados locais. Entre na sua conta para sincronizar."
        } else {
            cloudSyncMessage = "Carregando dados da nuvem..."
            val userRoot = firestore.collection("users").document(uid)
            userRoot.collection("notes").get()
                .addOnSuccessListener { snapshot ->
                    val localById = notes.associateBy { it.id }
                    val cloudNotes = snapshot.documents
                        .sortedBy { it.getLong("position") ?: Long.MAX_VALUE }
                        .mapNotNull { doc ->
                            val json = doc.getString("json") ?: return@mapNotNull null
                            runCatching { gson.fromJson(json, Note::class.java) }.getOrNull()
                        }
                        .map { mergeCloudNoteMedia(context, it, localById[it.id]) }

                    if (snapshot.isEmpty) {
                        // First sign-in: migrate this device's existing notes to the new account.
                        cloudReadyUserId = uid
                        scheduleCloudSnapshot(uid)
                    } else {
                        notes.clear()
                        notes.addAll(cloudNotes)
                        prefs.edit().putString("notes", gson.toJson(notes)).apply()
                        userRoot.collection("metadata").document("main").get()
                            .addOnSuccessListener { metadata ->
                                val cloudMarkers = runCatching {
                                    gson.fromJson<List<String>>(metadata.getString("markersJson") ?: "[]", markerType)
                                }.getOrNull().orEmpty()
                                val fromNotes = notes.flatMap { splitValues(it.markers) }
                                savedMarkers.clear()
                                savedMarkers.addAll((cloudMarkers + fromNotes).distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
                                prefs.edit().putString("saved_markers", gson.toJson(savedMarkers)).apply()
                                cloudReadyUserId = uid
                                cloudSyncMessage = "Dados carregados da nuvem."
                            }
                            .addOnFailureListener { error ->
                                cloudSyncMessage = "Notas carregadas, mas os marcadores não: ${error.message ?: "erro"}"
                                cloudReadyUserId = uid
                            }
                    }
                }
                .addOnFailureListener { error ->
                    cloudSyncMessage = "A nuvem recusou o acesso. Precisamos publicar as regras de segurança do Firestore."
                }
        }
    }

    val backupCreator = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            val result = runCatching { exportNotesBackup(context, uri, notes.toList(), savedMarkers.toList(), gson) }
            backupMessage = result.fold(
                { "Backup criado com ${notes.size} ficha(s), incluindo imagens. No seletor de arquivos, escolha Google Drive para guardar na nuvem. O backup é manual: faça um novo quando quiser atualizar a cópia." },
                { "Não foi possível criar o backup: ${it.message ?: "erro ao gravar arquivo"}" }
            )
        }
    }
    val backupRestorer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val result = runCatching { importNotesBackup(context, uri, gson) }
            result.onSuccess { pendingRestore = it }
                .onFailure { backupMessage = "Não foi possível restaurar: ${it.message ?: "arquivo inválido"}" }
        }
    }

    fun purgeExpiredTrash() {
        val cutoff = System.currentTimeMillis() - TRASH_RETENTION_MS
        val expiredIds = notes.filter { it.deletedAt > 0L && it.deletedAt <= cutoff }
            .map { it.id }.toSet()
        if (expiredIds.isEmpty()) return
        notes.removeAll { it.id in expiredIds }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in expiredIds }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
    }

    fun persist() {
        purgeExpiredTrash()
        // Snapshot on the main thread, then serialize/write on one background thread.
        // A revision counter drops obsolete queued snapshots when autosave fires rapidly.
        val notesSnapshot = notes.toList()
        val markersSnapshot = savedMarkers.toList()
        val revision = localSaveVersion.incrementAndGet()
        localSaveExecutor.execute {
            if (revision != localSaveVersion.get()) return@execute
            val notesJson = gson.toJson(notesSnapshot)
            val markersJson = gson.toJson(markersSnapshot)
            if (revision == localSaveVersion.get()) {
                prefs.edit()
                    .putString("notes", notesJson)
                    .putString("saved_markers", markersJson)
                    .apply()
            }
        }
        val uid = firebaseAuth.currentUser?.uid
        if (uid != null && cloudReadyUserId == uid) scheduleCloudSnapshot(uid)
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            purgeExpiredTrash()
            prefs.edit().putString("notes", gson.toJson(notes)).apply()
        }
    }

    fun registerMarker(value: String) {
        val clean = value.trim().removePrefix("#")
        if (clean.isNotEmpty() && savedMarkers.none { it.equals(clean, ignoreCase = true) }) {
            savedMarkers.add(clean)
            savedMarkers.sortBy { it.lowercase() }
            persist()
        }
    }

    fun saveNote(updated: Note) {
        splitValues(updated.markers).forEach { registerMarker(it) }
        val index = notes.indexOfFirst { it.id == updated.id }
        if (index >= 0) notes[index] = updated else notes.add(0, updated)
        persist()
    }

    fun deleteNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        val movedAt = System.currentTimeMillis()
        for (i in notes.indices) {
            if (notes[i].id in ids && notes[i].deletedAt <= 0L) {
                notes[i] = notes[i].copy(deletedAt = movedAt)
            }
        }
        persist()
    }

    fun restoreTrashNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        for (i in notes.indices) {
            if (notes[i].id in ids && notes[i].deletedAt > 0L) {
                notes[i] = notes[i].copy(deletedAt = 0L)
            }
        }
        persist()
    }

    fun permanentlyDeleteNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        notes.removeAll { it.id in ids }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in ids }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun emptyTrash() {
        val trashedIds = notes.filter { it.deletedAt > 0L }.map { it.id }.toSet()
        if (trashedIds.isEmpty()) return
        notes.removeAll { it.id in trashedIds }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in trashedIds }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun applyMarkersToNotes(ids: Set<String>, markers: Set<String>, remove: Boolean) {
        if (markers.isEmpty()) return
        markers.forEach { if (!remove) registerMarker(it) }
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val existing = splitValues(current.markers).toMutableSet()
                val next = if (remove) {
                    existing.filterNot { old -> markers.any { it.equals(old, true) } }.toSet()
                } else {
                    (existing + markers).toSet()
                }
                notes[i] = current.copy(markers = next.joinToString(", "))
            }
        }
        persist()
    }

    fun archiveNotes(ids: Set<String>, archived: Boolean) {
        for (i in notes.indices) {
            if (notes[i].id in ids) notes[i] = notes[i].copy(archived = archived)
        }
        persist()
    }

    fun pinNotes(ids: Set<String>, pinned: Boolean) {
        if (ids.isEmpty()) return
        for (i in notes.indices) {
            if (notes[i].id in ids) notes[i] = notes[i].copy(pinned = pinned)
        }
        persist()
    }

    fun relateSelectedNotes(ids: Set<String>) {
        if (ids.size < 2) return
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val related = parseIds(current.links).toMutableSet()
                related.addAll(ids - current.id)
                notes[i] = current.copy(links = related.joinToString(","))
            }
        }
        persist()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg,
        surface = Card,
        surfaceVariant = CardRaised,
        primary = Accent,
        onPrimary = Bg,
        onBackground = Ink,
        onSurface = Ink,
        secondary = Muted
    )) {
        if (editingNote != null) {
            EditorScreen(
                note = editingNote!!,
                allNotes = notes.toList(),
                knownMarkers = savedMarkers.toList(),
                onSave = { updated -> saveNote(updated); editingNote = null },
                onAutoSave = ::saveNote,
                onOpenLinked = { current, targetId ->
                    saveNote(current)
                    editingNote = notes.firstOrNull { it.id == targetId }?.copy()
                }
            )
        } else {
            NotesHome(
                notes = notes,
                knownMarkers = savedMarkers,
                search = search,
                onSearchChange = { search = it },
                showingArchived = showingArchived,
                showingTrash = showingTrash,
                onShowArchived = { showingTrash = false; showingArchived = true; activeMarker = null },
                onShowTrash = { showingTrash = true; showingArchived = false; activeMarker = null },
                onShowNotes = { showingTrash = false; showingArchived = false; activeMarker = null },
                activeMarker = activeMarker,
                onSelectMarker = { marker -> showingTrash = false; showingArchived = false; activeMarker = marker },
                onOpenNote = { editingNote = it.copy(coverScale = safeScale(it)) },
                onNewNote = { editingNote = Note() },
                onBulkApplyMarkers = ::applyMarkersToNotes,
                onBulkArchive = ::archiveNotes,
                onBulkPin = ::pinNotes,
                onBulkRelate = ::relateSelectedNotes,
                onBulkDelete = ::deleteNotes,
                onRestoreTrash = ::restoreTrashNotes,
                onDeleteForever = ::permanentlyDeleteNotes,
                onEmptyTrash = ::emptyTrash,
                onCreateBackup = {
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())
                    backupCreator.launch("ESCUDO-DO-MESTRE-backup-$stamp.zip")
                },
                onRestoreBackup = { backupRestorer.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                cloudSyncMessage = cloudSyncMessage
            )
        }
    }

    if (pendingRestore != null) {
        val backup = pendingRestore!!
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restaurar backup do Drive") },
            text = { Text("O arquivo contém ${backup.notes.size} ficha(s) e ${backup.markers.size} marcador(es). Você pode mesclar com as notas atuais ou substituir tudo.") },
            confirmButton = {
                TextButton(onClick = {
                    val merged = notes.toMutableList()
                    backup.notes.forEach { restored ->
                        val index = merged.indexOfFirst { it.id == restored.id }
                        if (index >= 0) merged[index] = restored else merged.add(0, restored)
                    }
                    notes.clear(); notes.addAll(merged)
                    backup.markers.forEach { marker ->
                        if (savedMarkers.none { it.equals(marker, true) }) savedMarkers.add(marker)
                    }
                    savedMarkers.sortBy { it.lowercase() }
                    persist()
                    pendingRestore = null
                    backupMessage = "Backup mesclado. ${backup.notes.size} ficha(s) foram importadas."
                }) { Text("Mesclar") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingRestore = null }) { Text("Cancelar") }
                    TextButton(onClick = {
                        notes.clear(); notes.addAll(backup.notes)
                        savedMarkers.clear(); savedMarkers.addAll(backup.markers.distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
                        persist()
                        pendingRestore = null
                        backupMessage = "Backup restaurado. As notas atuais foram substituídas."
                    }) { Text("Substituir tudo", color = Danger) }
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
    if (backupMessage != null) {
        AlertDialog(
            onDismissRequest = { backupMessage = null },
            title = { Text("Backup do ESCUDO DO MESTRE") },
            text = { Text(backupMessage!! ) },
            confirmButton = { TextButton(onClick = { backupMessage = null }) { Text("OK") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NotesHome(
    notes: List<Note>,
    knownMarkers: List<String>,
    search: String,
    onSearchChange: (String) -> Unit,
    showingArchived: Boolean,
    showingTrash: Boolean,
    onShowArchived: () -> Unit,
    onShowTrash: () -> Unit,
    onShowNotes: () -> Unit,
    activeMarker: String?,
    onSelectMarker: (String) -> Unit,
    onOpenNote: (Note) -> Unit,
    onNewNote: () -> Unit,
    onBulkApplyMarkers: (Set<String>, Set<String>, Boolean) -> Unit,
    onBulkArchive: (Set<String>, Boolean) -> Unit,
    onBulkPin: (Set<String>, Boolean) -> Unit,
    onBulkRelate: (Set<String>) -> Unit,
    onBulkDelete: (Set<String>) -> Unit,
    onRestoreTrash: (Set<String>) -> Unit,
    onDeleteForever: (Set<String>) -> Unit,
    onEmptyTrash: () -> Unit,
    onCreateBackup: () -> Unit,
    onRestoreBackup: () -> Unit,
    cloudSyncMessage: String?
) {
    val context = LocalContext.current
    val profilePrefs = remember { context.getSharedPreferences("escudo_profile", Context.MODE_PRIVATE) }
    var profileName by remember { mutableStateOf(profilePrefs.getString("name", "").orEmpty()) }
    var profileUsername by remember { mutableStateOf(profilePrefs.getString("username", "").orEmpty()) }
    var profileEmail by remember { mutableStateOf(profilePrefs.getString("email", "").orEmpty()) }
    var profileBio by remember { mutableStateOf(profilePrefs.getString("bio", "").orEmpty()) }
    var profilePhoto by remember { mutableStateOf(profilePrefs.getString("photo", "").orEmpty()) }
    var showAccountDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var listMode by remember { mutableStateOf(false) }
    var accountInfoMessage by remember { mutableStateOf<String?>(null) }
    val auth = remember { FirebaseAuth.getInstance() }
    val profileFirestore = remember { FirebaseFirestore.getInstance() }
    var firebaseUser by remember { mutableStateOf(auth.currentUser) }
    var authEmailInput by remember { mutableStateOf(profilePrefs.getString("email", "").orEmpty()) }
    var authPasswordInput by remember { mutableStateOf("") }
    var authBusy by remember { mutableStateOf(false) }
    var pendingProfilePhotoUri by remember { mutableStateOf<Uri?>(null) }
    var showPhotoCropDialog by remember { mutableStateOf(false) }
    var profileCropZoom by remember { mutableStateOf(1f) }
    var profileCropOffsetX by remember { mutableStateOf(0f) }
    var profileCropOffsetY by remember { mutableStateOf(0f) }
    val density = androidx.compose.ui.platform.LocalDensity.current
    val profilePhotoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pendingProfilePhotoUri = uri
            profileCropZoom = 1f
            profileCropOffsetX = 0f
            profileCropOffsetY = 0f
            showPhotoCropDialog = true
        }
    }
    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { current ->
            firebaseUser = current.currentUser
            val email = current.currentUser?.email.orEmpty()
            if (email.isNotBlank()) {
                profileEmail = email
                authEmailInput = email
                profilePrefs.edit().putString("email", email).apply()
            }
            authPasswordInput = ""
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(firebaseUser?.uid) {
        val user = firebaseUser ?: return@LaunchedEffect
        profileFirestore.collection("users").document(user.uid)
            .collection("profile").document("main").get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    profileName = document.getString("name") ?: profileName
                    profileUsername = document.getString("username") ?: profileUsername
                    profileBio = document.getString("bio") ?: profileBio
                    profileEmail = user.email.orEmpty()
                    val encodedPhoto = document.getString("photoBase64").orEmpty()
                    if (encodedPhoto.isNotBlank()) {
                        val localUri = saveCloudProfilePhoto(context, encodedPhoto)
                        if (!localUri.isNullOrBlank()) {
                            profilePhoto = localUri
                            profilePrefs.edit().putString("photo", localUri).apply()
                        }
                    }
                    profilePrefs.edit()
                        .putString("name", profileName)
                        .putString("username", profileUsername)
                        .putString("email", profileEmail)
                        .putString("bio", profileBio)
                        .apply()
                    accountInfoMessage = "Perfil carregado da nuvem."
                } else {
                    profileEmail = user.email.orEmpty()
                    accountInfoMessage = "Conta conectada. Salve o perfil para enviá-lo à nuvem."
                }
            }
            .addOnFailureListener {
                accountInfoMessage = "Conta conectada, mas não foi possível carregar o perfil. Confira as regras do Firestore."
            }
    }

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val selectedIds = remember { mutableStateListOf<String>() }
    var showBulkMarkers by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showPermanentDeleteConfirmation by remember { mutableStateOf(false) }
    var showEmptyTrashConfirmation by remember { mutableStateOf(false) }
    val selectedNotes = notes.filter { it.id in selectedIds }
    val allSelectedArchived = selectedNotes.isNotEmpty() && selectedNotes.all { it.archived }
    val allSelectedPinned = selectedNotes.isNotEmpty() && selectedNotes.all { it.pinned }

    fun toggleSelected(id: String) {
        if (id in selectedIds) selectedIds.remove(id) else selectedIds.add(id)
    }
    fun openOrSelect(note: Note) {
        if (showingTrash || selectedIds.isNotEmpty()) toggleSelected(note.id) else onOpenNote(note)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Panel,
                drawerContentColor = Ink
            ) {
                Column(
                    Modifier.fillMaxHeight().statusBarsPadding().padding(horizontal = 18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Spacer(Modifier.height(12.dp))
                    // Profile header stays at the very top of the navigation drawer.
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .align(Alignment.CenterHorizontally)
                            .clip(CircleShape)
                            .border(2.dp, Accent, CircleShape)
                            .background(CardRaised)
                            .clickable { profilePhotoPicker.launch(arrayOf("image/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (profilePhoto.isNotBlank()) {
                            AndroidView(
                                factory = { viewContext ->
                                    ImageView(viewContext).apply {
                                        scaleType = ImageView.ScaleType.CENTER_CROP
                                        contentDescription = "Foto de perfil"
                                        setImageURI(Uri.parse(profilePhoto))
                                    }
                                },
                                update = { imageView ->
                                    imageView.setImageURI(Uri.parse(profilePhoto))
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                Icons.Outlined.Person,
                                contentDescription = "Escolher foto de perfil",
                                tint = Accent,
                                modifier = Modifier.size(46.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(
                        profileName.ifBlank { "Conta do mestre" },
                        color = Ink,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    val profileSubtitle = when {
                        profileUsername.isNotBlank() -> "@${profileUsername.removePrefix("@")}"
                        profileEmail.isNotBlank() -> profileEmail
                        else -> "Seu perfil neste aparelho"
                    }
                    Text(
                        profileSubtitle,
                        color = Muted,
                        fontSize = 11.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 1,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        cloudSyncMessage ?: if (firebaseUser == null) "Somente neste aparelho" else "Conectado à nuvem",
                        color = if (firebaseUser != null && cloudSyncMessage?.contains("concluída", true) == true) Accent else Muted,
                        fontSize = 9.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 3.dp)
                    )
                    OutlinedButton(
                        onClick = {
                            scope.launch { drawerState.close() }
                            showAccountDialog = true
                        },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) {
                        Text("Editar perfil", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    HorizontalDivider(color = Color(0xFF373737))
                    Spacer(Modifier.height(14.dp))
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Organização do grimório", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(18.dp))
                    Spacer(Modifier.height(8.dp))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.Description, contentDescription = null, tint = Accent) },
                        label = { Text("Notas") },
                        selected = !showingArchived && !showingTrash && activeMarker == null,
                        onClick = { selectedIds.clear(); onShowNotes(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Outlined.Label, contentDescription = null, tint = Accent, modifier = Modifier.size(16.dp))
                        Text("MARCADORES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    if (knownMarkers.isEmpty()) {
                        Text("Os marcadores das notas aparecerão aqui.", color = Muted, fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 8.dp))
                    } else {
                        knownMarkers.sortedBy { it.lowercase(Locale.ROOT) }.forEach { marker ->
                            NavigationDrawerItem(
                                icon = { Icon(Icons.Outlined.Label, contentDescription = null, tint = Accent, modifier = Modifier.size(18.dp)) },
                                label = { Text(marker, maxLines = 1) },
                                selected = activeMarker == marker,
                                onClick = { selectedIds.clear(); onSelectMarker(marker); scope.launch { drawerState.close() } },
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = CardRaised,
                                    selectedTextColor = Accent,
                                    unselectedTextColor = Ink
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.Archive, contentDescription = null, tint = Accent) },
                        label = { Text("Arquivados") },
                        selected = showingArchived && !showingTrash,
                        onClick = { selectedIds.clear(); onShowArchived(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = Accent) },
                        label = { Text("Lixeira (${notes.count { it.deletedAt > 0L }})") },
                        selected = showingTrash,
                        onClick = { selectedIds.clear(); onShowTrash(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Outlined.Settings, contentDescription = null, tint = Accent) },
                        label = { Text("Configurações") },
                        selected = showSettingsDialog,
                        onClick = {
                            scope.launch { drawerState.close() }
                            showSettingsDialog = true
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    ) {
        val filtered by remember(notes, search, showingTrash, showingArchived, activeMarker) {
            derivedStateOf {
                notes
                    .filter { if (showingTrash) it.deletedAt > 0L else it.deletedAt <= 0L }
                    // A marker view deliberately spans both active and archived notes.
                    .filter { showingTrash || activeMarker != null || it.archived == showingArchived }
                    .filter { activeMarker == null || splitValues(it.markers).any { tag -> tag.equals(activeMarker, true) } }
                    .filter {
                        search.isBlank() || it.title.contains(search, true) ||
                            it.body.contains(search, true) || it.markers.contains(search, true) ||
                            it.pages.orEmpty().any { page -> page.body.contains(search, true) }
                    }
                    .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.title })
            }
        }

        val pinnedNotes = filtered.filter { it.pinned && !showingArchived && !showingTrash && activeMarker == null }
        val pinnedIds = pinnedNotes.map { it.id }.toSet()
        val otherNotes = filtered.filterNot { it.id in pinnedIds }
        val showPinnedSection = pinnedNotes.isNotEmpty()

        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().padding(horizontal = 14.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (selectedIds.isNotEmpty()) {
                    TextButton(onClick = { selectedIds.clear() }, contentPadding = PaddingValues(6.dp)) {
                        Text("✕", color = Ink, fontSize = 21.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${selectedIds.size} selecionada(s)", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Toque em outras notas para incluí-las", color = Muted, fontSize = 10.sp)
                    }
                } else {
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Text("☰", color = Ink, fontSize = 23.sp)
                    }
                    OutlinedTextField(
                        value = search,
                        onValueChange = onSearchChange,
                        modifier = Modifier.weight(1f).height(54.dp),
                        singleLine = true,
                        textStyle = TextStyle(color = Ink, fontSize = 12.sp),
                        placeholder = { Text("Pesquisar notas...", fontSize = 12.sp) },
                        leadingIcon = { Text("⌕", color = Muted, fontSize = 22.sp) },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (search.isNotEmpty()) {
                                    IconButton(onClick = { onSearchChange("") }) {
                                        Icon(Icons.Outlined.Close, contentDescription = "Limpar pesquisa", tint = Muted)
                                    }
                                }
                                IconButton(onClick = { listMode = !listMode }) {
                                    Icon(
                                        if (listMode) Icons.Outlined.GridView else Icons.Outlined.ViewList,
                                        contentDescription = if (listMode) "Mostrar em grade" else "Mostrar em lista",
                                        tint = Accent
                                    )
                                }
                            }
                        },
                        shape = RoundedCornerShape(28.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                    )
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).background(CardRaised)
                            .border(1.dp, Accent.copy(alpha = 0.7f), CircleShape)
                            .clickable { showAccountDialog = true },
                        contentAlignment = Alignment.Center
                    ) {
                        if (profilePhoto.isNotBlank()) {
                            AndroidView(
                                factory = { viewContext -> ImageView(viewContext).apply {
                                    scaleType = ImageView.ScaleType.CENTER_CROP
                                    setImageURI(Uri.parse(profilePhoto))
                                } },
                                update = { it.setImageURI(Uri.parse(profilePhoto)) },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Outlined.Person, contentDescription = "Perfil e login", tint = Accent)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            showingTrash -> "Lixeira"
                            showingArchived -> "Arquivadas"
                            activeMarker != null -> "#${activeMarker}"
                            else -> "Minhas notas"
                        },
                        color = Ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text("${filtered.size} notas", color = Muted, fontSize = 11.sp)
                }
                if (showingTrash) {
                    TextButton(onClick = { showEmptyTrashConfirmation = true }) {
                        Text("Esvaziar", color = Danger)
                    }
                } else if (activeMarker != null || showingArchived) {
                    TextButton(onClick = onShowNotes) { Text("Ver todas", color = Accent) }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◈", color = Accent, fontSize = 41.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when {
                                search.isNotBlank() -> "Nenhuma nota encontrada"
                                showingTrash -> "A lixeira está vazia"
                                showingArchived -> "Nada arquivado por enquanto"
                                activeMarker != null -> "Nenhuma nota com este marcador"
                                else -> "Seu escudo está pronto"
                            },
                            color = Ink, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (showingTrash) "As fichas excluídas ficarão aqui por 7 dias."
                            else "Crie uma nota ou ajuste sua pesquisa.",
                            color = Muted, fontSize = 11.sp
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = if (listMode) GridCells.Fixed(1) else GridCells.Adaptive(minSize = 145.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (showPinnedSection) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text("Fixadas", color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 4.dp, bottom = 1.dp))
                        }
                        items(pinnedNotes, key = { it.id }) { note ->
                            NoteCard(
                                note = note,
                                selected = note.id in selectedIds,
                                onClick = { openOrSelect(note) },
                                onLongClick = { toggleSelected(note.id) },
                                listMode = listMode
                            )
                        }
                    }
                    if (otherNotes.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text(if (showPinnedSection) "Outras" else if (showingTrash) "Lixeira" else if (showingArchived) "Arquivadas" else "Notas",
                                color = Ink, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = if (showPinnedSection) 5.dp else 4.dp, bottom = 1.dp))
                        }
                        items(otherNotes, key = { it.id }) { note ->
                            NoteCard(
                                note = note,
                                selected = note.id in selectedIds,
                                onClick = { openOrSelect(note) },
                                onLongClick = { toggleSelected(note.id) },
                                listMode = listMode
                            )
                        }
                    }
                }
            }
            if (selectedIds.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (showingTrash) {
                        Button(
                            onClick = {
                                onRestoreTrash(selectedIds.toSet())
                                selectedIds.clear()
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Restaurar", fontSize = 11.sp) }
                        OutlinedButton(
                            onClick = { showPermanentDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
                        ) { Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Apagar", fontSize = 11.sp) }
                    } else {
                        IconButton(
                            onClick = {
                                onBulkPin(selectedIds.toSet(), !allSelectedPinned)
                                selectedIds.clear()
                            }
                        ) {
                            Icon(
                                Icons.Outlined.PushPin,
                                contentDescription = if (allSelectedPinned) "Desafixar notas" else "Fixar notas",
                                tint = Accent
                            )
                        }
                        IconButton(
                            onClick = {
                                shareNotesWithOtherApps(context, selectedNotes)
                                selectedIds.clear()
                            }
                        ) {
                            Icon(Icons.Outlined.Share, contentDescription = "Compartilhar notas", tint = Accent)
                        }
                        OutlinedButton(
                            onClick = { showBulkMarkers = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Icon(Icons.Outlined.Label, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Marcadores", fontSize = 9.sp) }
                        OutlinedButton(
                            onClick = {
                                onBulkRelate(selectedIds.toSet())
                                selectedIds.clear()
                            },
                            enabled = selectedIds.size >= 2,
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Icon(Icons.Outlined.Link, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Relacionar", fontSize = 9.sp) }
                        OutlinedButton(
                            onClick = { showDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
                        ) { Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Lixeira", fontSize = 9.sp) }
                        Button(
                            onClick = {
                                onBulkArchive(selectedIds.toSet(), !allSelectedArchived)
                                selectedIds.clear()
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(if (allSelectedArchived) "Restaurar" else "Arquivar", fontSize = 9.sp) }
                    }
                }
            } else if (!showingTrash && !showingArchived) {
                Row(Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(58.dp).clickable(onClick = onNewNote),
                        shape = RoundedCornerShape(14.dp),
                        color = Accent,
                        contentColor = Bg,
                        shadowElevation = 5.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("+", fontSize = 34.sp, fontWeight = FontWeight.Normal, color = Bg)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                }
            }

            if (showBulkMarkers) {
                BulkMarkerDialog(
                    selectedCount = selectedIds.size,
                    knownMarkers = knownMarkers,
                    onDismiss = { showBulkMarkers = false },
                    onApply = { markers, remove ->
                        onBulkApplyMarkers(selectedIds.toSet(), markers, remove)
                        showBulkMarkers = false
                        selectedIds.clear()
                    }
                )
            }
            if (showDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirmation = false },
                    title = { Text("Mover para a lixeira?") },
                    text = { Text("${selectedIds.size} ficha(s) ficarão na lixeira por 7 dias. Nesse período, você poderá restaurá-las ou apagá-las definitivamente.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onBulkDelete(selectedIds.toSet())
                            selectedIds.clear()
                            showDeleteConfirmation = false
                        }) { Text("Mover para a lixeira", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
            if (showPermanentDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showPermanentDeleteConfirmation = false },
                    title = { Text("Apagar definitivamente?") },
                    text = { Text("${selectedIds.size} ficha(s) serão removidas agora. Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onDeleteForever(selectedIds.toSet())
                            selectedIds.clear()
                            showPermanentDeleteConfirmation = false
                        }) { Text("Apagar definitivamente", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showPermanentDeleteConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
            if (showEmptyTrashConfirmation) {
                AlertDialog(
                    onDismissRequest = { showEmptyTrashConfirmation = false },
                    title = { Text("Esvaziar lixeira?") },
                    text = { Text("Todas as fichas na lixeira serão apagadas definitivamente. Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onEmptyTrash()
                            selectedIds.clear()
                            showEmptyTrashConfirmation = false
                        }) { Text("Esvaziar lixeira", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showEmptyTrashConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
        }
    }

    if (showPhotoCropDialog && pendingProfilePhotoUri != null) {
        AlertDialog(
            onDismissRequest = { showPhotoCropDialog = false; pendingProfilePhotoUri = null },
            title = { Text("Ajustar foto de perfil", fontSize = 16.sp) },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 470.dp).verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AndroidView(
                        factory = { viewContext -> ImageView(viewContext).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            setImageURI(pendingProfilePhotoUri)
                        } },
                        update = { imageView ->
                            imageView.setImageURI(pendingProfilePhotoUri)
                            imageView.scaleType = ImageView.ScaleType.CENTER_CROP
                            imageView.scaleX = profileCropZoom
                            imageView.scaleY = profileCropZoom
                            imageView.translationX = with(density) { profileCropOffsetX * 42.dp.toPx() }
                            imageView.translationY = with(density) { profileCropOffsetY * 42.dp.toPx() }
                        },
                        modifier = Modifier.size(190.dp).clip(CircleShape)
                    )
                    Text("Ampliação", color = Ink, fontSize = 12.sp)
                    Slider(
                        value = profileCropZoom,
                        onValueChange = { profileCropZoom = it },
                        valueRange = 1f..3.5f
                    )
                    Text("Mover para os lados", color = Ink, fontSize = 12.sp)
                    Slider(
                        value = profileCropOffsetX,
                        onValueChange = { profileCropOffsetX = it },
                        valueRange = -1f..1f
                    )
                    Text("Mover para cima ou para baixo", color = Ink, fontSize = 12.sp)
                    Slider(
                        value = profileCropOffsetY,
                        onValueChange = { profileCropOffsetY = it },
                        valueRange = -1f..1f
                    )
                    Text("A área circular será usada como foto do perfil.", color = Muted, fontSize = 10.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val uri = pendingProfilePhotoUri
                    if (uri != null) {
                        val cropped = cropProfilePhotoToFile(context, uri, profileCropZoom, profileCropOffsetX, profileCropOffsetY)
                        if (cropped.isNullOrBlank()) {
                            accountInfoMessage = "Não foi possível recortar essa imagem. Escolha outra foto."
                        } else {
                            profilePhoto = cropped
                            profilePrefs.edit().putString("photo", cropped).apply()
                            accountInfoMessage = "Foto ajustada. Toque em Salvar perfil para sincronizá-la."
                            showPhotoCropDialog = false
                            pendingProfilePhotoUri = null
                        }
                    }
                }) { Text("Usar esta foto", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = { showPhotoCropDialog = false; pendingProfilePhotoUri = null }) {
                    Text("Cancelar", color = Muted)
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (showAccountDialog) {
        AlertDialog(
            onDismissRequest = { showAccountDialog = false; accountInfoMessage = null },
            title = { Text("Editar perfil", fontSize = 16.sp) },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 500.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(84.dp)
                            .clip(CircleShape)
                            .border(2.dp, Accent, CircleShape)
                            .background(CardRaised)
                            .clickable { profilePhotoPicker.launch(arrayOf("image/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (profilePhoto.isNotBlank()) {
                            AndroidView(
                                factory = { viewContext ->
                                    ImageView(viewContext).apply {
                                        scaleType = ImageView.ScaleType.CENTER_CROP
                                        contentDescription = "Foto de perfil"
                                        setImageURI(Uri.parse(profilePhoto))
                                    }
                                },
                                update = { imageView -> imageView.setImageURI(Uri.parse(profilePhoto)) },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Outlined.Person, contentDescription = null, tint = Accent, modifier = Modifier.size(42.dp))
                        }
                    }
                    TextButton(onClick = { profilePhotoPicker.launch(arrayOf("image/*")) }) {
                        Text("Alterar foto de perfil", color = Accent, fontSize = 12.sp)
                    }
                    if (firebaseUser == null) {
                        Text("Conta na nuvem", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = authEmailInput,
                            onValueChange = { authEmailInput = it.trim() },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("E-mail para entrar ou cadastrar") },
                            textStyle = TextStyle(color = Ink, fontSize = 13.sp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                        )
                        OutlinedTextField(
                            value = authPasswordInput,
                            onValueChange = { authPasswordInput = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Senha (mínimo 6 caracteres)") },
                            textStyle = TextStyle(color = Ink, fontSize = 13.sp),
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                enabled = !authBusy && authEmailInput.contains("@") && authPasswordInput.length >= 6,
                                onClick = {
                                    authBusy = true
                                    auth.signInWithEmailAndPassword(authEmailInput.trim(), authPasswordInput)
                                        .addOnCompleteListener { task ->
                                            authBusy = false
                                            if (task.isSuccessful) {
                                                profileEmail = task.result.user?.email.orEmpty()
                                                accountInfoMessage = "Login realizado. Carregando seus dados..."
                                            } else accountInfoMessage = task.exception?.localizedMessage ?: "Não foi possível entrar. Confira e-mail e senha."
                                        }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text(if (authBusy) "Aguarde..." else "Entrar", fontSize = 11.sp) }
                            Button(
                                enabled = !authBusy && authEmailInput.contains("@") && authPasswordInput.length >= 6,
                                onClick = {
                                    authBusy = true
                                    auth.createUserWithEmailAndPassword(authEmailInput.trim(), authPasswordInput)
                                        .addOnCompleteListener { task ->
                                            authBusy = false
                                            if (task.isSuccessful) {
                                                profileEmail = task.result.user?.email.orEmpty()
                                                accountInfoMessage = "Conta criada! Salve seu perfil para sincronizá-lo."
                                            } else accountInfoMessage = task.exception?.localizedMessage ?: "Não foi possível criar a conta."
                                        }
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Criar conta", fontSize = 11.sp) }
                        }
                        TextButton(
                            enabled = authEmailInput.contains("@") && !authBusy,
                            onClick = {
                                auth.sendPasswordResetEmail(authEmailInput.trim())
                                    .addOnSuccessListener { accountInfoMessage = "Enviamos um link de recuperação para seu e-mail." }
                                    .addOnFailureListener { accountInfoMessage = it.localizedMessage ?: "Não foi possível enviar o e-mail." }
                            }
                        ) { Text("Esqueci minha senha", color = Accent, fontSize = 11.sp) }
                    } else {
                        Text("Conta conectada", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(firebaseUser?.email.orEmpty(), color = Muted, fontSize = 11.sp)
                        TextButton(onClick = {
                            auth.signOut()
                            accountInfoMessage = "Sessão encerrada. Os dados deste aparelho continuam salvos."
                        }) { Text("Sair da conta", color = Danger, fontSize = 11.sp) }
                    }
                    OutlinedTextField(
                        value = profileName,
                        onValueChange = { profileName = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Nome de exibição") },
                        textStyle = TextStyle(color = Ink, fontSize = 13.sp)
                    )
                    OutlinedTextField(
                        value = profileUsername,
                        onValueChange = { profileUsername = it.trimStart('@').replace(" ", "") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Nome de usuário") },
                        prefix = { Text("@", color = Muted) },
                        textStyle = TextStyle(color = Ink, fontSize = 13.sp)
                    )
                    OutlinedTextField(
                        value = profileEmail,
                        onValueChange = { if (firebaseUser == null) profileEmail = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        readOnly = firebaseUser != null,
                        label = { Text("E-mail da conta") },
                        textStyle = TextStyle(color = Ink, fontSize = 13.sp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    OutlinedTextField(
                        value = profileBio,
                        onValueChange = { profileBio = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 3,
                        label = { Text("Sobre você") },
                        textStyle = TextStyle(color = Ink, fontSize = 13.sp)
                    )
                    Text(
                        "Com uma conta conectada, perfil, notas, capas e imagens das páginas são sincronizados no Firestore. Arquivos que não sejam imagens de página continuam armazenados neste aparelho.",
                        color = Muted,
                        fontSize = 10.sp
                    )
                    if (!accountInfoMessage.isNullOrBlank()) {
                        Text(accountInfoMessage!!, color = Accent, fontSize = 10.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    profilePrefs.edit()
                        .putString("name", profileName.trim())
                        .putString("username", profileUsername.trim().removePrefix("@"))
                        .putString("email", (firebaseUser?.email ?: profileEmail).trim())
                        .putString("bio", profileBio.trim())
                        .putString("photo", profilePhoto)
                        .apply()
                    val user = auth.currentUser
                    if (user == null) {
                        accountInfoMessage = "Perfil salvo neste aparelho. Entre ou crie uma conta para sincronizar."
                    } else {
                        val photoBase64 = encodeProfilePhoto(context, profilePhoto).orEmpty()
                        val profileData = mapOf(
                            "name" to profileName.trim(),
                            "username" to profileUsername.trim().removePrefix("@"),
                            "email" to user.email.orEmpty(),
                            "bio" to profileBio.trim(),
                            "photoBase64" to photoBase64,
                            "updatedAt" to System.currentTimeMillis()
                        )
                        profileFirestore.collection("users").document(user.uid)
                            .collection("profile").document("main").set(profileData)
                            .addOnSuccessListener {
                                accountInfoMessage = "Perfil sincronizado com a nuvem."
                                showAccountDialog = false
                            }
                            .addOnFailureListener { error ->
                                accountInfoMessage = "Perfil salvo localmente, mas a nuvem recusou a gravação. Confira as regras do Firestore: ${error.localizedMessage ?: "erro"}"
                            }
                    }
                    if (auth.currentUser == null) showAccountDialog = false
                }) { Text("Salvar perfil", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = { showAccountDialog = false; accountInfoMessage = null }) {
                    Text("Fechar", color = Muted)
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Configurações") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Conta e sincronização", color = Accent, fontWeight = FontWeight.SemiBold)
                    Text(cloudSyncMessage ?: if (firebaseUser == null) "Entre no perfil para sincronizar." else "Conta conectada.",
                        color = Muted, fontSize = 12.sp)
                    OutlinedButton(onClick = { showSettingsDialog = false; onCreateBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Salvar backup em arquivo ZIP")
                    }
                    OutlinedButton(onClick = { showSettingsDialog = false; onRestoreBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Restaurar backup")
                    }
                    Text("As imagens da capa e das páginas são compactadas e sincronizadas junto das notas pela nuvem. O compartilhamento envia o texto e as imagens originais como anexos separados para aplicativos compatíveis.",
                        color = Muted, fontSize = 10.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showSettingsDialog = false }) { Text("Fechar", color = Accent) } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    note: Note,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    listMode: Boolean = false
) {
    val shape = RoundedCornerShape(17.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) Accent else Color(0xFF353535),
                shape = shape
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = if (selected) CardRaised else Card)
    ) {
        if (listMode) {
            Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(88.dp).height(106.dp).clip(RoundedCornerShape(11.dp))) {
                    if (note.cover.isNotBlank()) {
                        CoverImage(
                            uri = note.cover,
                            scale = safeScale(note),
                            offsetX = note.coverOffsetX,
                            offsetY = note.coverOffsetY,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(Modifier.fillMaxSize().background(Color(0xFF303030)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Description, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
                        }
                    }
                    if (selected) {
                        Box(Modifier.align(Alignment.TopEnd).padding(5.dp).size(22.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                            Text("✓", color = Bg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(note.title.ifBlank { "Sem título" }, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 2, modifier = Modifier.weight(1f))
                        if (note.pinned) Icon(Icons.Outlined.PushPin, contentDescription = "Fixada", tint = Accent, modifier = Modifier.size(15.dp))
                    }
                    if (note.body.isNotBlank()) Text(note.body, color = Muted, fontSize = 11.sp, maxLines = 3)
                    val tags = remember(note.markers) { splitValues(note.markers).take(3) }
                    val relationCount = remember(note.links) { parseIds(note.links).size }
                    if (tags.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Icon(Icons.Outlined.Label, contentDescription = "Marcadores", tint = Accent, modifier = Modifier.size(13.dp))
                            Text(tags.joinToString("  ") { it }, color = Accent, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                    if (relationCount > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            Icon(Icons.Outlined.Link, contentDescription = "Notas relacionadas", tint = Muted, modifier = Modifier.size(13.dp))
                            Text(relationCount.toString(), color = Muted, fontSize = 10.sp)
                        }
                    }
                    if (note.archived) Text("ARQUIVADA", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Column(Modifier.padding(9.dp)) {
                Box {
                    if (note.cover.isNotBlank()) {
                        CoverImage(
                            uri = note.cover,
                            scale = safeScale(note),
                            offsetX = note.coverOffsetX,
                            offsetY = note.coverOffsetY,
                            modifier = Modifier.fillMaxWidth().aspectRatio(0.82f).clip(RoundedCornerShape(11.dp))
                        )
                    } else {
                        Box(Modifier.fillMaxWidth().aspectRatio(0.82f).clip(RoundedCornerShape(11.dp)).background(Color(0xFF303030)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Description, contentDescription = null, tint = Accent, modifier = Modifier.size(30.dp))
                        }
                    }
                    if (selected) {
                        Box(Modifier.align(Alignment.TopEnd).padding(7.dp).size(27.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
                            Text("✓", color = Bg, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(note.title.ifBlank { "Sem título" }, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 2, modifier = Modifier.weight(1f))
                    if (note.pinned) Icon(Icons.Outlined.PushPin, contentDescription = "Fixada", tint = Accent, modifier = Modifier.size(14.dp))
                }
                if (note.body.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(note.body, color = Muted, fontSize = 11.sp, maxLines = 2)
                }
                val tags = remember(note.markers) { splitValues(note.markers).take(2) }
                val relationCount = remember(note.links) { parseIds(note.links).size }
                if (tags.isNotEmpty() || relationCount > 0) {
                    Spacer(Modifier.height(7.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        if (tags.isNotEmpty()) {
                            Icon(Icons.Outlined.Label, contentDescription = "Marcadores", tint = Accent, modifier = Modifier.size(13.dp))
                            Text(tags.joinToString("  ") { it }, color = Accent, fontSize = 10.sp, maxLines = 1)
                        }
                        if (relationCount > 0) {
                            Icon(Icons.Outlined.Link, contentDescription = "Notas relacionadas", tint = Muted, modifier = Modifier.size(13.dp))
                            Text(relationCount.toString(), color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                if (note.archived) {
                    Spacer(Modifier.height(5.dp))
                    Text("ARQUIVADA", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BulkMarkerDialog(
    selectedCount: Int,
    knownMarkers: List<String>,
    onDismiss: () -> Unit,
    onApply: (Set<String>, Boolean) -> Unit
) {
    val choices = remember(knownMarkers) {
        mutableStateListOf<String>().apply { addAll(knownMarkers) }
    }
    val selectedMarkers = remember { mutableStateListOf<String>() }
    var newMarker by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Marcadores • $selectedCount fichas") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 430.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    if (removing) "Escolha os marcadores que serão removidos das fichas selecionadas."
                    else "Escolha os marcadores que serão adicionados às fichas selecionadas.",
                    color = Muted, fontSize = 11.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remover marcadores", modifier = Modifier.weight(1f), color = Ink)
                    Switch(checked = removing, onCheckedChange = { removing = it })
                }
                if (choices.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        choices.forEach { marker ->
                            val isSelected = selectedMarkers.any { it.equals(marker, true) }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) selectedMarkers.removeAll { it.equals(marker, true) }
                                    else selectedMarkers.add(marker)
                                },
                                label = { Text("#${marker}") }
                            )
                        }
                    }
                } else {
                    Text("Ainda não existem marcadores salvos.", color = Muted, fontSize = 11.sp)
                }
                OutlinedTextField(
                    value = newMarker,
                    onValueChange = { newMarker = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Criar marcador") }
                )
                OutlinedButton(
                    onClick = {
                        val clean = newMarker.trim().removePrefix("#")
                        if (clean.isNotEmpty() && choices.none { it.equals(clean, true) }) {
                            choices.add(clean)
                            selectedMarkers.add(clean)
                        }
                        newMarker = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Adicionar marcador à lista") }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onApply(selectedMarkers.toSet(), removing) },
                enabled = selectedMarkers.isNotEmpty()
            ) { Text(if (removing) "Remover" else "Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel,
        titleContentColor = Ink,
        textContentColor = Ink
    )
}

private data class CoverMatrixParams(val scale: Float, val offsetX: Float, val offsetY: Float)

private fun startImageDrag(context: Context, source: String, imageView: ImageView): Boolean = runCatching {
    val sharedUri = copyNoteImageForSharing(context, source, System.currentTimeMillis().toInt()) ?: return false
    val clip = android.content.ClipData.newUri(context.contentResolver, "Imagem do ESCUDO DO MESTRE", sharedUri)
    imageView.startDragAndDrop(
        clip,
        View.DragShadowBuilder(imageView),
        null,
        View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ
    )
}.getOrDefault(false)

private val coverImageMainHandler = Handler(Looper.getMainLooper())
private val coverImageExecutor = Executors.newFixedThreadPool(2)
private val coverBitmapCache: LruCache<String, Bitmap> by lazy {
    val maxKb = minOf(48 * 1024, (Runtime.getRuntime().maxMemory() / 8L / 1024L).toInt())
    object : LruCache<String, Bitmap>(maxKb.coerceAtLeast(8 * 1024)) {
        override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
    }
}

private fun decodeCoverBitmap(context: Context, source: String, maxSide: Int = 1440): Bitmap? = runCatching {
    fun open(): java.io.InputStream? {
        if (source.startsWith(CLOUD_COVER_PREFIX)) {
            return java.io.ByteArrayInputStream(Base64.decode(source.removePrefix(CLOUD_COVER_PREFIX), Base64.DEFAULT))
        }
        val uri = Uri.parse(source)
        return if (uri.scheme == "file") uri.path?.let { File(it).inputStream() }
            else context.contentResolver.openInputStream(uri)
    }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    open()?.use { BitmapFactory.decodeStream(it, null, options) }
}.getOrNull()

private fun loadCoverBitmapAsync(context: Context, view: ImageView, source: String) {
    if (source.isBlank() || view.width <= 0 || view.height <= 0) return
    val cacheKey = source
    val alreadyRequested = view.getTag(R.id.cover_image_request) == cacheKey
    if (alreadyRequested) {
        (view.getTag(R.id.cover_matrix_params) as? CoverMatrixParams)?.let {
            if (view.drawable != null) applyCoverMatrix(view, it.scale, it.offsetX, it.offsetY)
        }
        return
    }
    val cached = coverBitmapCache.get(cacheKey)
    if (cached != null) {
        view.setTag(R.id.cover_image_request, cacheKey)
        view.setImageBitmap(cached)
        (view.getTag(R.id.cover_matrix_params) as? CoverMatrixParams)?.let {
            applyCoverMatrix(view, it.scale, it.offsetX, it.offsetY)
        }
        return
    }
    // A reused ImageView can still have an old request running. The request tag
    // makes sure an older decode can never replace the newly selected picture.
    view.setTag(R.id.cover_image_request, cacheKey)
    coverImageExecutor.execute {
        val decoded = decodeCoverBitmap(context.applicationContext, source)
        if (decoded != null) coverBitmapCache.put(cacheKey, decoded)
        coverImageMainHandler.post {
            if (view.getTag(R.id.cover_image_request) != cacheKey) return@post
            if (decoded != null) {
                view.setImageBitmap(decoded)
                (view.getTag(R.id.cover_matrix_params) as? CoverMatrixParams)?.let {
                    applyCoverMatrix(view, it.scale, it.offsetX, it.offsetY)
                }
            } else {
                view.setTag(R.id.cover_image_request, null)
            }
        }
    }
}

@Composable
private fun CoverImage(
    uri: String,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    onDragOut: ((ImageView) -> Boolean)? = null
) {
    val context = LocalContext.current
    AndroidView(
        factory = { ctx ->
            ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.MATRIX
                addOnLayoutChangeListener(object : android.view.View.OnLayoutChangeListener {
                    override fun onLayoutChange(
                        changed: android.view.View,
                        left: Int,
                        top: Int,
                        right: Int,
                        bottom: Int,
                        oldLeft: Int,
                        oldTop: Int,
                        oldRight: Int,
                        oldBottom: Int
                    ) {
                        val imageView = changed as? ImageView ?: return
                        val params = imageView.getTag(R.id.cover_matrix_params) as? CoverMatrixParams
                        if (params != null) {
                            if (imageView.drawable != null) {
                                applyCoverMatrix(imageView, params.scale, params.offsetX, params.offsetY)
                            } else {
                                val currentUri = imageView.getTag(R.id.cover_image_uri) as? String
                                if (!currentUri.isNullOrBlank()) loadCoverBitmapAsync(ctx, imageView, currentUri)
                            }
                        }
                    }
                })
            }
        },
        update = { view ->
            view.setOnClickListener(if (onClick != null) View.OnClickListener { onClick() } else null)
            view.setOnLongClickListener(if (onDragOut != null) View.OnLongClickListener { onDragOut(view) } else null)
            view.isClickable = onClick != null
            view.isLongClickable = onDragOut != null
            view.setTag(R.id.cover_matrix_params, CoverMatrixParams(scale.coerceAtLeast(1f), offsetX, offsetY))
            val imageChanged = view.getTag(R.id.cover_image_uri) != uri
            if (imageChanged) {
                view.imageMatrix = Matrix()
                view.setImageDrawable(null)
                view.setTag(R.id.cover_image_uri, uri)
                view.setTag(R.id.cover_image_request, null)
            }
            if (uri.isNotBlank()) {
                if (view.width > 0 && view.height > 0) loadCoverBitmapAsync(context, view, uri)
                else view.post { loadCoverBitmapAsync(context, view, uri) }
            } else {
                view.setImageDrawable(null)
            }
            val params = view.getTag(R.id.cover_matrix_params) as CoverMatrixParams
            if (view.drawable != null && view.width > 0 && view.height > 0) {
                applyCoverMatrix(view, params.scale, params.offsetX, params.offsetY)
            }
        },
        modifier = modifier
    )
}

@Composable
private fun PaperStyleSample(
    style: String,
    tone: String,
    selected: Boolean,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val paper = when (tone) {
        "white" -> Color(0xFFF1F0EA)
        "gray" -> Color(0xFF45454B)
        else -> Bg
    }
    val line = if (tone == "white") Color(0x55333333) else Color(0x55FFFFFF)
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(7.dp))
                .background(paper)
                .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Muted.copy(alpha = 0.45f), RoundedCornerShape(7.dp))
        ) {
            ComposeCanvas(Modifier.fillMaxSize().padding(4.dp)) {
                val gap = 9.dp.toPx()
                if (style == "ruled" || style == "grid") {
                    var y = gap
                    while (y < size.height) {
                        drawLine(line, Offset(0f, y), Offset(size.width, y), 0.7.dp.toPx())
                        y += gap
                    }
                }
                if (style == "grid") {
                    var x = gap
                    while (x < size.width) {
                        drawLine(line, Offset(x, 0f), Offset(x, size.height), 0.7.dp.toPx())
                        x += gap
                    }
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = if (selected) Accent else Ink, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun EditorScreen(
    note: Note,
    allNotes: List<Note>,
    knownMarkers: List<String>,
    onSave: (Note) -> Unit,
    onAutoSave: (Note) -> Unit,
    onOpenLinked: (Note, String) -> Unit
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var title by remember(note.id) { mutableStateOf(note.title) }
    var pages by remember(note.id) { mutableStateOf(normalizePages(note)) }
    var activePageIndex by remember(note.id) { mutableIntStateOf(0) }
    var selectedLinks by remember(note.id) { mutableStateOf(parseIds(note.links)) }
    var pageIndexToDelete by remember(note.id) { mutableIntStateOf(-1) }
    var pinned by remember(note.id) { mutableStateOf(note.pinned) }
    var archived by remember(note.id) { mutableStateOf(note.archived) }
    var paperTone by remember(note.id) { mutableStateOf(note.paperTone?.takeIf { it in setOf("black", "white", "gray") } ?: "black") }
    var paperStyle by remember(note.id) { mutableStateOf(note.paperStyle?.takeIf { it in setOf("blank", "ruled", "grid") } ?: "blank") }
    val selectedMarkers = remember(note.id) {
        mutableStateListOf<String>().apply { addAll(splitValues(note.markers)) }
    }
    var coverGallery by remember(note.id) {
        mutableStateOf(note.coverGallery.orEmpty().filter { it.isNotBlank() }.ifEmpty {
            listOf(pages.firstOrNull()?.image.orEmpty()).filter { it.isNotBlank() }
        }.distinct().take(MAX_COVER_GALLERY_IMAGES))
    }
    var viewingImageUri by remember(note.id) { mutableStateOf<String?>(null) }
    var boxImageTarget by remember(note.id) { mutableStateOf<Pair<Int, String>?>(null) }
    var boxDialogTarget by remember(note.id) { mutableStateOf<Pair<Int, String>?>(null) }

    var activeEditText by remember(note.id) { mutableStateOf<NoteEditText?>(null) }
    var editorResetToken by remember(note.id) { mutableIntStateOf(0) }
    var pendingCaretAfterReset by remember(note.id) { mutableIntStateOf(-1) }

    // Every numbered page can have one header image. The first page image is the card cover.
    // Legacy inline-image blocks remain readable for notes created by older releases.

    // Temporary page-image adjustment. Zoom and crop are fixed after confirmation.
    var imageAdjusting by remember(note.id) { mutableStateOf(false) }
    var pendingImageUri by remember(note.id) { mutableStateOf<String?>(null) }
    var pendingScale by remember(note.id) { mutableFloatStateOf(1f) }
    var pendingOffsetX by remember(note.id) { mutableFloatStateOf(0f) }
    var pendingOffsetY by remember(note.id) { mutableFloatStateOf(0f) }
    var pendingAspectRatio by remember(note.id) { mutableFloatStateOf(1.7778f) }
    var pendingImagePageIndex by remember(note.id) { mutableIntStateOf(0) }

    var showMoreMenu by remember(note.id) { mutableStateOf(false) }
    var showMarkerDialog by remember(note.id) { mutableStateOf(false) }
    var showRelatedDialog by remember(note.id) { mutableStateOf(false) }
    var showPaperDialog by remember(note.id) { mutableStateOf(false) }
    var newMarker by remember(note.id) { mutableStateOf("") }
    var imageToDelete by remember(note.id) { mutableStateOf<Pair<Int, String>?>(null) }
    var imageActionsFor by remember(note.id) { mutableStateOf<String?>(null) }
    var lastTouchX by remember(note.id) { mutableFloatStateOf(0f) }
    var lastTouchY by remember(note.id) { mutableFloatStateOf(0f) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pendingImageUri = it.toString()
            pendingScale = 1f
            pendingOffsetX = 0f
            pendingOffsetY = 0f
            pendingAspectRatio = readImageAspectRatio(context, it)
            pendingImagePageIndex = activePageIndex
            imageAdjusting = true
        }
    }
    val coverGalleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val accepted = uris.mapNotNull { uri ->
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                uri.toString().takeIf { it.isNotBlank() }
            }
            val existing = coverGallery.ifEmpty { listOf(pages.firstOrNull()?.image.orEmpty()).filter { it.isNotBlank() } }
            val combined = (existing + accepted).distinct()
            val limited = combined.take(MAX_COVER_GALLERY_IMAGES)
            coverGallery = limited
            val firstUri = limited.firstOrNull()
            if (firstUri != null && pages.isNotEmpty()) {
                val ratio = readImageAspectRatio(context, Uri.parse(firstUri))
                pages = pages.toMutableList().also { list ->
                    list[0] = list[0].copy(image = firstUri, imageScale = 1f, imageOffsetX = 0f, imageOffsetY = 0f, imageAspectRatio = ratio)
                }
            }
            val ignored = combined.size - limited.size
            Toast.makeText(context, if (ignored > 0) "Galeria atualizada. Limite de $MAX_COVER_GALLERY_IMAGES imagens na capa." else "Galeria da capa atualizada.", Toast.LENGTH_SHORT).show()
        }
    }
    val boxImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val target = boxImageTarget
        if (uri != null && target != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val (pageIndex, boxId) = target
            if (pageIndex in pages.indices) {
                val page = pages[pageIndex]
                val updatedBoxes = page.boxes.orEmpty().map { box -> if (box.id == boxId) box.copy(image = uri.toString()) else box }
                pages = pages.toMutableList().also { it[pageIndex] = page.copy(boxes = updatedBoxes) }
            }
        }
        boxImageTarget = null
    }

    // Accept images dragged from Infinix Smart Hub or another Android app.
    // The dropped URI is copied into app storage before the temporary permission is released.
    val externalImageDropTarget = remember(note.id) {
        object : DragAndDropTarget {
            override fun onDrop(event: DragAndDropEvent): Boolean {
                val androidEvent = event.toAndroidDragEvent()
                val clip = androidEvent.clipData ?: return false
                val permission = findActivity(context)?.requestDragAndDropPermissions(androidEvent)
                try {
                    val offeredImageMime = event.mimeTypes()
                        .firstOrNull { it.startsWith("image/", true) }.orEmpty()
                    val imageItem = (0 until clip.itemCount).asSequence()
                        .map { index -> clip.getItemAt(index) }
                        .mapNotNull { item ->
                            val uri = item.uri ?: item.text?.toString()?.trim()?.let { raw ->
                                if (raw.startsWith("content://") || raw.startsWith("file://")) Uri.parse(raw) else null
                            }
                            uri?.let {
                                val resolverMime = context.contentResolver.getType(it).orEmpty()
                                val mime = if (resolverMime.startsWith("image/", true)) resolverMime else offeredImageMime
                                if (mime.startsWith("image/", true)) it to mime else null
                            }
                        }
                        .firstOrNull() ?: return false
                    val imageUri = imageItem.first
                    val localUri = copyDroppedImageToApp(context, imageUri, imageItem.second)
                    if (localUri.isNullOrBlank()) {
                        Toast.makeText(context, "Não foi possível receber essa imagem.", Toast.LENGTH_SHORT).show()
                        return false
                    }
                    pendingImageUri = localUri
                    pendingScale = 1f
                    pendingOffsetX = 0f
                    pendingOffsetY = 0f
                    pendingAspectRatio = readImageAspectRatio(context, Uri.parse(localUri))
                    pendingImagePageIndex = activePageIndex
                    imageAdjusting = true
                    showMoreMenu = false
                    Toast.makeText(context, if (activePageIndex == 0) "Imagem recebida para a capa. Ajuste e confirme." else "Imagem recebida para esta página. Ajuste e confirme.", Toast.LENGTH_SHORT).show()
                    return true
                } finally {
                    permission?.release()
                }
            }
        }
    }
    val externalImageDropModifier = Modifier.dragAndDropTarget(
        shouldStartDragAndDrop = { event ->
            event.mimeTypes().any { it.startsWith("image/") || it == "text/uri-list" || it == "text/plain" || it == "application/octet-stream" }
        },
        target = externalImageDropTarget
    )

    fun updatePage(index: Int, updated: NotePage) {
        if (index !in pages.indices) return
        pages = pages.toMutableList().also { it[index] = updated }
    }

    fun currentPage(): NotePage = pages.getOrNull(activePageIndex) ?: pages.first()

    fun updateBox(pageIndex: Int, updated: NoteBox) {
        if (pageIndex !in pages.indices) return
        val page = pages[pageIndex]
        val boxes = page.boxes.orEmpty().map { if (it.id == updated.id) updated else it }
        updatePage(pageIndex, page.copy(boxes = boxes))
    }

    fun addBox() {
        val page = currentPage()
        val box = NoteBox()
        updatePage(activePageIndex, page.copy(boxes = page.boxes.orEmpty() + box))
        boxDialogTarget = activePageIndex to box.id
    }

    fun removeBox(pageIndex: Int, boxId: String) {
        if (pageIndex !in pages.indices) return
        val page = pages[pageIndex]
        updatePage(pageIndex, page.copy(boxes = page.boxes.orEmpty().filterNot { it.id == boxId }))
        if (boxDialogTarget == (pageIndex to boxId)) boxDialogTarget = null
    }

    fun currentNote(): Note {
        val safeGallery = (coverGallery.ifEmpty { listOf(pages.firstOrNull()?.image.orEmpty()).filter { it.isNotBlank() } })
            .filter { it.isNotBlank() }.distinct().take(MAX_COVER_GALLERY_IMAGES)
        val normalizedPages = pages.mapIndexed { index, page ->
            val storedBlocks = collapseAdjacentTextBlocks(page.blocks.ifEmpty { listOf(NoteBlock(text = page.body)) })
            page.copy(
                body = pageBodyFromBlocks(storedBlocks),
                blocks = storedBlocks,
                boxes = page.boxes.orEmpty(),
                image = if (index == 0 && safeGallery.isNotEmpty()) safeGallery.first() else page.image
            )
        }
        val first = normalizedPages.firstOrNull() ?: NotePage(blocks = listOf(NoteBlock()))
        return note.copy(
            title = title.trim(),
            body = first.body,
            cover = safeGallery.firstOrNull() ?: first.image,
            coverGallery = safeGallery,
            markers = selectedMarkers.joinToString(", "),
            links = selectedLinks.joinToString(","),
            archived = archived,
            pinned = pinned,
            paperTone = paperTone,
            paperStyle = paperStyle,
            coverScale = first.imageScale.coerceIn(1f, 4f),
            coverOffsetX = first.imageOffsetX,
            coverOffsetY = first.imageOffsetY,
            coverAspectRatio = safeAspectRatio(first.imageAspectRatio),
            pages = normalizedPages
        )
    }

    fun saveAndExit() {
        keyboard?.hide()
        onSave(currentNote())
    }

    fun selectPage(index: Int) {
        if (index !in pages.indices || index == activePageIndex) return
        keyboard?.hide()
        activePageIndex = index
        editorResetToken++
        pendingCaretAfterReset = -1
    }

    fun addPage() {
        val newPage = NotePage(blocks = listOf(NoteBlock()))
        pages = pages + newPage
        activePageIndex = pages.lastIndex
        editorResetToken++
        pendingCaretAfterReset = 0
        showMoreMenu = false
    }

    fun preparePageImage() {
        // Page one supplies the card cover; later pages keep their own independent image.
        pendingImagePageIndex = activePageIndex
        showMoreMenu = false
        keyboard?.hide()
        imagePicker.launch(arrayOf("image/*"))
    }

    fun insertAdjustedImage() {
        val uri = pendingImageUri ?: return
        val targetIndex = pendingImagePageIndex.coerceIn(0, (pages.size - 1).coerceAtLeast(0))
        val targetPage = pages.getOrNull(targetIndex) ?: NotePage(blocks = listOf(NoteBlock()))
        val updatedPage = targetPage.copy(
            image = uri,
            imageScale = pendingScale.coerceIn(1f, 4f),
            imageOffsetX = pendingOffsetX.coerceIn(-1f, 1f),
            imageOffsetY = pendingOffsetY.coerceIn(-1f, 1f),
            imageAspectRatio = safeAspectRatio(pendingAspectRatio)
        )
        pages = if (pages.isEmpty()) listOf(updatedPage) else pages.toMutableList().also { it[targetIndex] = updatedPage }
        if (targetIndex == 0) {
            val gallery = coverGallery.toMutableList()
            if (gallery.isEmpty()) gallery.add(uri) else gallery[0] = uri
            coverGallery = gallery.distinct().take(MAX_COVER_GALLERY_IMAGES)
        }
        pendingCaretAfterReset = -1
        editorResetToken++
        pendingImageUri = null
        imageAdjusting = false
    }

    fun removeImageBlock(pageIndex: Int, blockId: String) {
        if (pageIndex !in pages.indices) return
        val page = pages[pageIndex]
        val remaining = page.blocks.filterNot { it.id == blockId }
        val safeBlocks = collapseAdjacentTextBlocks(remaining)
        updatePage(pageIndex, page.copy(blocks = safeBlocks, body = pageBodyFromBlocks(safeBlocks)))
        editorResetToken++
        imageToDelete = null
    }

    fun moveInlineImage(blockId: String, direction: Int) {
        val page = currentPage()
        val blocks = page.blocks.toMutableList()
        val index = blocks.indexOfFirst { it.id == blockId && it.kind == "image" }
        if (index < 0) return
        if (direction < 0) {
            if (index == 0 || blocks[index - 1].kind == "image") return
            val previous = blocks[index - 1]
            if (previous.text.isEmpty()) return
            val moved = previous.text.last()
            blocks[index - 1] = previous.copy(text = previous.text.dropLast(1))
            if (index + 1 < blocks.size && blocks[index + 1].kind != "image") {
                blocks[index + 1] = blocks[index + 1].copy(text = moved + blocks[index + 1].text)
            } else {
                blocks.add(index + 1, NoteBlock(text = moved.toString()))
            }
        } else {
            if (index + 1 >= blocks.size || blocks[index + 1].kind == "image") return
            val next = blocks[index + 1]
            if (next.text.isEmpty()) return
            val moved = next.text.first()
            if (index > 0 && blocks[index - 1].kind != "image") {
                blocks[index - 1] = blocks[index - 1].copy(text = blocks[index - 1].text + moved)
            } else {
                blocks.add(index, NoteBlock(text = moved.toString()))
            }
            val newImageIndex = blocks.indexOfFirst { it.id == blockId }
            blocks[newImageIndex + 1] = next.copy(text = next.text.drop(1))
        }
        val normalized = collapseAdjacentTextBlocks(blocks)
        updatePage(activePageIndex, page.copy(blocks = normalized, body = pageBodyFromBlocks(normalized)))
        pendingCaretAfterReset = caretOffsetAfterImage(normalized, blockId)
        editorResetToken++
        imageActionsFor = null
    }

    val markerSnapshot = selectedMarkers.toList()
    LaunchedEffect(title, pages, coverGallery, selectedLinks, markerSnapshot, pinned, archived, paperTone, paperStyle, imageAdjusting) {
        if (!imageAdjusting) {
            delay(900)
            val draft = currentNote()
            val hasContent = draft.title.isNotBlank() || draft.pages.any { page ->
                page.body.isNotBlank() || page.image.isNotBlank() || page.blocks.any { it.kind == "image" } ||
                    page.boxes.orEmpty().any { it.title.isNotBlank() || it.text.isNotBlank() || it.image.isNotBlank() }
            } || draft.coverGallery.isNotEmpty() || draft.links.isNotBlank()
            if (hasContent) onAutoSave(draft)
        }
    }

    BackHandler {
        when {
            imageAdjusting -> {
                imageAdjusting = false
                pendingImageUri = null
            }
            showMoreMenu -> showMoreMenu = false
            showMarkerDialog -> showMarkerDialog = false
            showRelatedDialog -> showRelatedDialog = false
            showPaperDialog -> showPaperDialog = false
            imageActionsFor != null -> imageActionsFor = null
            else -> saveAndExit()
        }
    }

    if (imageAdjusting && pendingImageUri != null) {
        Column(
            externalImageDropModifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding().padding(horizontal = 18.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    imageAdjusting = false
                    pendingImageUri = null
                }) { Text("Cancelar", color = Ink, fontSize = 11.sp) }
                Text(if (pendingImagePageIndex == 0) "Capa da nota" else "Imagem da página ${pendingImagePageIndex + 1}",
                    color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { insertAdjustedImage() }) {
                    Text("Confirmar", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
            Text("Ajuste o zoom e o enquadramento da imagem desta página. A imagem da primeira página também será a capa da nota.",
                color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                val previewWidth = maxWidth
                val desiredHeight = (previewWidth / safeAspectRatio(pendingAspectRatio)).coerceAtMost(maxHeight)
                CoverImage(
                    uri = pendingImageUri.orEmpty(), scale = pendingScale, offsetX = pendingOffsetX, offsetY = pendingOffsetY,
                    modifier = Modifier.width(previewWidth).height(desiredHeight).clip(RoundedCornerShape(16.dp))
                        .pointerInput(pendingImageUri) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                pendingOffsetX = (pendingOffsetX + dragAmount.x / size.width.toFloat()).coerceIn(-1f, 1f)
                                pendingOffsetY = (pendingOffsetY + dragAmount.y / size.height.toFloat()).coerceIn(-1f, 1f)
                            }
                        }
                )
            }
            Text("Zoom", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Slider(value = pendingScale, onValueChange = { pendingScale = it }, valueRange = 1f..4f)
            OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Escolher outra imagem", fontSize = 11.sp)
            }
            Spacer(Modifier.height(12.dp))
        }
    } else {
        Column(
            externalImageDropModifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding()
        ) {
            // Fixed header and page strip. Only the note content scrolls.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { saveAndExit() }) { Text("←", color = Ink, fontSize = 23.sp) }
                Text(if (note.title.isBlank() && title.isBlank()) "Nova nota" else "Nota",
                    color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { saveAndExit() }) {
                    Text("✓", color = Accent, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                pages.forEachIndexed { index, _ ->
                    val isSelected = index == activePageIndex
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(if (isSelected) Accent else CardRaised)
                            .combinedClickable(
                                onClick = { selectPage(index) },
                                onLongClick = { pageIndexToDelete = index }
                            ).padding(horizontal = 15.dp, vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${index + 1}", color = if (isSelected) Bg else Ink,
                            fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }

            val activePage = currentPage()
            val paperComposeColor = when (paperTone) {
                "white" -> Color(0xFFF1F0EA)
                "gray" -> Color(0xFF45454B)
                else -> Bg
            }
            val paperInk = if (paperTone == "white") Color(0xFF181818) else Ink
            val paperMuted = if (paperTone == "white") Color(0xFF66645F) else Muted
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                    .background(paperComposeColor)
                    .padding(horizontal = 20.dp).padding(top = 10.dp, bottom = 16.dp)
            ) {
                if (activePage.image.isNotBlank()) {
                    CoverImage(
                        uri = activePage.image,
                        scale = activePage.imageScale,
                        offsetX = activePage.imageOffsetX,
                        offsetY = activePage.imageOffsetY,
                        onClick = { viewingImageUri = activePage.image },
                        onDragOut = { imageView -> startImageDrag(context, activePage.image, imageView) },
                        modifier = Modifier.fillMaxWidth().aspectRatio(safeAspectRatio(activePage.imageAspectRatio))
                            .clip(RoundedCornerShape(14.dp))
                    )
                    if (activePageIndex == 0) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            coverGallery.drop(1).forEachIndexed { index, imageUri ->
                                Box {
                                    CoverImage(
                                        uri = imageUri,
                                        scale = 1f,
                                        offsetX = 0f,
                                        offsetY = 0f,
                                        onClick = { viewingImageUri = imageUri },
                                        onDragOut = { imageView -> startImageDrag(context, imageUri, imageView) },
                                        modifier = Modifier.size(width = 82.dp, height = 96.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .border(1.dp, Accent.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
                                    )
                                    Text(
                                        (index + 2).toString(), color = Ink, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp)
                                            .background(Color.Black.copy(alpha = 0.65f), CircleShape).padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Box(
                                Modifier.size(42.dp).clip(CircleShape)
                                    .background(CardRaised)
                                    .border(1.dp, Accent.copy(alpha = 0.65f), CircleShape)
                                    .clickable { coverGalleryPicker.launch(arrayOf("image/*")) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("+", color = Accent, fontSize = 25.sp, fontWeight = FontWeight.Light)
                            }
                        }
                        Text("Segure uma imagem para arrastá-la ao Smart Hub. Toque para ampliar.", color = paperMuted, fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                } else if (activePageIndex == 0) {
                    Box(
                        Modifier.size(42.dp).clip(CircleShape)
                            .background(CardRaised)
                            .border(1.dp, Accent.copy(alpha = 0.65f), CircleShape)
                            .clickable { coverGalleryPicker.launch(arrayOf("image/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("+", color = Accent, fontSize = 25.sp, fontWeight = FontWeight.Light)
                    }
                }

                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(color = paperInk, fontSize = 20.sp, fontWeight = FontWeight.Medium, lineHeight = 26.sp),
                    cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    decorationBox = { inner ->
                        Box {
                            if (title.isEmpty()) Text("Título", color = paperMuted, fontSize = 20.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.height(14.dp))

                // One native EditText renders text and floating images in the same paragraph flow.
                key(activePage.id) {
                    AndroidView(
                        modifier = Modifier.fillMaxWidth().heightIn(min = 390.dp),
                        factory = { viewContext ->
                            NoteEditText(viewContext).apply {
                                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                                setTextColor(if (paperTone == "white") android.graphics.Color.rgb(24, 24, 24) else android.graphics.Color.rgb(242, 240, 234))
                                setHintTextColor(if (paperTone == "white") android.graphics.Color.rgb(102, 100, 95) else android.graphics.Color.rgb(170, 166, 157))
                                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                                setPadding(0, 0, 0, 0)
                                includeFontPadding = false
                                gravity = Gravity.TOP or Gravity.START
                                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                                imeOptions = EditorInfo.IME_ACTION_NONE
                                isSingleLine = false
                                minLines = 8
                                hint = "Comece a escrever..."
                                val available = (resources.displayMetrics.widthPixels - (40 * resources.displayMetrics.density).toInt()).coerceAtLeast(240)
                                applyingModel = true
                                configurePaperEditor(this, paperStyle, paperTone)
                                setText(blocksToEditable(viewContext, activePage.blocks, available, getLineHeight()))
                                applyingModel = false
                                renderedVersion = editorResetToken
                                activeEditText = this

                                addTextChangedListener(object : TextWatcher {
                                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                                    override fun afterTextChanged(editable: Editable?) {
                                        if (applyingModel || editable == null) return
                                        val blocks = editableToBlocks(editable)
                                        val idx = activePageIndex
                                        val page = pages.getOrNull(idx) ?: return
                                        if (blocks != page.blocks) {
                                            updatePage(idx, page.copy(blocks = blocks, body = pageBodyFromBlocks(blocks)))
                                        }
                                    }
                                })

                                setOnTouchListener { _, event ->
                                    if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
                                        lastTouchX = event.x
                                        lastTouchY = event.y
                                    }
                                    false
                                }
                                setOnLongClickListener {
                                    val layout = layout
                                    val editable = text as? Editable
                                    if (layout == null || editable == null || editable.isEmpty()) return@setOnLongClickListener false
                                    val line = layout.getLineForVertical((lastTouchY + scrollY - totalPaddingTop).toInt().coerceIn(0, (layout.height - 1).coerceAtLeast(0)))
                                    val offset = layout.getOffsetForHorizontal(line, lastTouchX + scrollX - totalPaddingLeft)
                                    val flowSpan = editable.getSpans(0, editable.length, ImageFlowMarginSpan::class.java)
                                        .firstOrNull { candidate ->
                                            val spanStart = editable.getSpanStart(candidate).coerceAtLeast(0)
                                            val firstLine = layout.getLineForOffset(spanStart.coerceAtMost(editable.length))
                                            val lineIsBesideImage = candidate.currentImageLineCount > 0 &&
                                                line >= firstLine && line < firstLine + candidate.currentImageLineCount
                                            val touchIsInsideImageColumn = lastTouchX <= candidate.imageWidthPx + 10 * resources.displayMetrics.density
                                            lineIsBesideImage && touchIsInsideImageColumn
                                        }
                                    val anchor = editable.getSpans(0, editable.length, NoteInlineImageSpan::class.java)
                                        .firstOrNull { offset >= editable.getSpanStart(it) && offset <= editable.getSpanEnd(it) }
                                    val imageId = flowSpan?.imageAnchor?.block?.id ?: anchor?.block?.id
                                    if (imageId != null) {
                                        imageActionsFor = imageId
                                        true
                                    } else false
                                }
                            }
                        },
                        update = { edit ->
                            activeEditText = edit
                            edit.setTextColor(if (paperTone == "white") android.graphics.Color.rgb(24, 24, 24) else android.graphics.Color.rgb(242, 240, 234))
                            edit.setHintTextColor(if (paperTone == "white") android.graphics.Color.rgb(102, 100, 95) else android.graphics.Color.rgb(170, 166, 157))
                            if (edit.paperStyle != paperStyle || edit.paperTone != paperTone || edit.paperStepPx <= 0f) {
                                configurePaperEditor(edit, paperStyle, paperTone)
                            }
                            if (edit.renderedVersion != editorResetToken) {
                                val available = (edit.width.takeIf { it > 0 } ?: edit.resources.displayMetrics.widthPixels) - edit.paddingLeft - edit.paddingRight
                                edit.applyingModel = true
                                edit.setText(blocksToEditable(context, activePage.blocks, available.coerceAtLeast(240), edit.getLineHeight()))
                                edit.applyingModel = false
                                edit.renderedVersion = editorResetToken
                                val selection = if (pendingCaretAfterReset >= 0) pendingCaretAfterReset else edit.text.length
                                edit.setSelection(selection.coerceIn(0, edit.text.length))
                                pendingCaretAfterReset = -1
                            }
                        }
                    )
                }

                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Caixinhas", color = paperInk, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { addBox() }) {
                        Text("+ Adicionar", color = Accent, fontSize = 11.sp)
                    }
                }
                if (activePage.boxes.orEmpty().isNotEmpty()) {
                    activePage.boxes.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { box ->
                                Surface(
                                    modifier = Modifier.weight(1f).clickable {
                                        boxDialogTarget = activePageIndex to box.id
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (paperTone == "white") Color(0xFFE6E4DD) else Card,
                                    border = BorderStroke(1.dp, Accent.copy(alpha = 0.35f))
                                ) {
                                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            box.title.ifBlank { "Caixa" },
                                            color = paperInk,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 2,
                                            lineHeight = 15.sp
                                        )
                                        if (box.image.isNotBlank()) {
                                            CoverImage(
                                                uri = box.image, scale = 1f, offsetX = 0f, offsetY = 0f,
                                                onDragOut = { imageView -> startImageDrag(context, box.image, imageView) },
                                                modifier = Modifier.fillMaxWidth().height(66.dp).clip(RoundedCornerShape(8.dp))
                                            )
                                        } else {
                                            Box(
                                                Modifier.fillMaxWidth().height(42.dp).clip(RoundedCornerShape(8.dp))
                                                    .background(if (paperTone == "white") Color(0xFFDAD8D0) else CardRaised),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("Abrir caixa", color = paperMuted, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // Compact action rail sits immediately above the keyboard.
            Row(
                Modifier.fillMaxWidth().padding(start = 9.dp, end = 12.dp, top = 1.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    IconButton(onClick = { showMoreMenu = true }) {
                        Text("⋮", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(expanded = showMoreMenu, onDismissRequest = { showMoreMenu = false }) {
                        DropdownMenuItem(
                            leadingIcon = { Icon(Icons.Outlined.Share, contentDescription = null, tint = Accent) },
                            text = { Text("Compartilhar nota", fontSize = 12.sp) },
                            onClick = {
                                val noteToShare = currentNote()
                                onAutoSave(noteToShare)
                                showMoreMenu = false
                                shareNotesWithOtherApps(context, listOf(noteToShare))
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            leadingIcon = { Text("▤", color = Accent) },
                            text = { Text("Criar nova página", fontSize = 12.sp) },
                            onClick = { addPage() }
                        )
                        DropdownMenuItem(
                            leadingIcon = { Text("▣", color = Accent) },
                            text = { Text("Adicionar caixinha", fontSize = 12.sp) },
                            onClick = { addBox(); showMoreMenu = false }
                        )
                        if (activePageIndex == 0) {
                            DropdownMenuItem(
                                leadingIcon = { Text("▧", color = Accent) },
                                text = { Text("Adicionar imagens à galeria da capa", fontSize = 12.sp) },
                                onClick = { showMoreMenu = false; coverGalleryPicker.launch(arrayOf("image/*")) }
                            )
                        }
                        DropdownMenuItem(
                            leadingIcon = { Text("▧", color = Accent) },
                            text = {
                                Text(
                                    when {
                                        activePageIndex == 0 && currentPage().image.isBlank() -> "Adicionar imagem de capa"
                                        activePageIndex == 0 -> "Trocar imagem de capa"
                                        currentPage().image.isBlank() -> "Adicionar imagem à página ${activePageIndex + 1}"
                                        else -> "Trocar imagem da página ${activePageIndex + 1}"
                                    },
                                    fontSize = 12.sp
                                )
                            },
                            onClick = { preparePageImage() }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            leadingIcon = { Icon(Icons.Outlined.PushPin, contentDescription = null, tint = Accent) },
                            text = { Text(if (pinned) "Desafixar nota" else "Fixar nota", fontSize = 12.sp) },
                            onClick = { pinned = !pinned; showMoreMenu = false }
                        )
                        DropdownMenuItem(
                            leadingIcon = { Icon(Icons.Outlined.Archive, contentDescription = null, tint = Accent) },
                            text = { Text(if (archived) "Restaurar nota" else "Arquivar nota", fontSize = 12.sp) },
                            onClick = { archived = !archived; showMoreMenu = false }
                        )
                        DropdownMenuItem(
                            leadingIcon = { Icon(Icons.Outlined.Label, contentDescription = null, tint = Accent) },
                            text = { Text("Marcadores", fontSize = 12.sp) },
                            onClick = { showMoreMenu = false; showMarkerDialog = true }
                        )
                    }
                }
                IconButton(onClick = { showPaperDialog = true }) {
                    Icon(Icons.Outlined.Palette, contentDescription = "Fundo da nota", tint = Accent)
                }
                IconButton(onClick = { showRelatedDialog = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Link, contentDescription = "Notas relacionadas", tint = Accent)
                        if (selectedLinks.isNotEmpty()) {
                            Spacer(Modifier.width(4.dp))
                            Text(selectedLinks.size.toString(), color = Accent, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            }
        }
    }

    if (viewingImageUri != null) {
        val uriToView = viewingImageUri.orEmpty()
        AlertDialog(
            onDismissRequest = { viewingImageUri = null },
            title = { Text("Imagem", color = Ink, fontSize = 15.sp) },
            text = {
                CoverImage(
                    uri = uriToView, scale = 1f, offsetX = 0f, offsetY = 0f,
                    onDragOut = { imageView -> startImageDrag(context, uriToView, imageView) },
                    modifier = Modifier.fillMaxWidth()
                        .aspectRatio(safeAspectRatio(readImageAspectRatio(context, Uri.parse(uriToView))))
                        .heightIn(max = 440.dp).clip(RoundedCornerShape(12.dp))
                )
            },
            confirmButton = {
                Row {
                    if (coverGallery.contains(uriToView)) {
                        TextButton(onClick = {
                            val reordered = listOf(uriToView) + coverGallery.filterNot { it == uriToView }
                            coverGallery = reordered.distinct().take(MAX_COVER_GALLERY_IMAGES)
                            if (pages.isNotEmpty()) {
                                val ratio = readImageAspectRatio(context, Uri.parse(uriToView))
                                pages = pages.toMutableList().also { it[0] = it[0].copy(image = uriToView, imageAspectRatio = ratio, imageScale = 1f, imageOffsetX = 0f, imageOffsetY = 0f) }
                            }
                            viewingImageUri = null
                        }) { Text("Definir como capa", color = Accent, fontSize = 11.sp) }
                    }
                    TextButton(onClick = { viewingImageUri = null }) { Text("Fechar") }
                }
            },
            dismissButton = {
                if (coverGallery.contains(uriToView)) {
                    TextButton(onClick = {
                        val remaining = coverGallery.filterNot { it == uriToView }
                        coverGallery = remaining
                        if (pages.isNotEmpty()) {
                            val first = remaining.firstOrNull().orEmpty()
                            val ratio = if (first.isNotBlank()) readImageAspectRatio(context, Uri.parse(first)) else 1.7778f
                            pages = pages.toMutableList().also { it[0] = it[0].copy(image = first, imageScale = 1f, imageOffsetX = 0f, imageOffsetY = 0f, imageAspectRatio = ratio) }
                        }
                        viewingImageUri = null
                    }) { Text("Remover da galeria", color = Danger, fontSize = 11.sp) }
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    val boxTarget = boxDialogTarget
    val dialogBox = boxTarget?.let { target ->
        pages.getOrNull(target.first)?.boxes?.firstOrNull { it.id == target.second }
    }
    if (boxTarget != null && dialogBox != null) {
        Dialog(
            onDismissRequest = { boxDialogTarget = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(0.92f).heightIn(max = 620.dp),
                shape = RoundedCornerShape(20.dp),
                color = Panel,
                border = BorderStroke(1.dp, Accent.copy(alpha = 0.55f))
            ) {
                Column(
                    Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(17.dp),
                    verticalArrangement = Arrangement.spacedBy(11.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = dialogBox.title,
                            onValueChange = { updateBox(boxTarget.first, dialogBox.copy(title = it)) },
                            modifier = Modifier.weight(1f),
                            textStyle = TextStyle(color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold),
                            cursorBrush = SolidColor(Accent),
                            singleLine = true,
                            decorationBox = { inner ->
                                Box {
                                    if (dialogBox.title.isEmpty()) Text("Título da caixa", color = Muted, fontSize = 17.sp)
                                    inner()
                                }
                            }
                        )
                        TextButton(onClick = { boxDialogTarget = null }) { Text("Fechar", color = Accent) }
                    }
                    HorizontalDivider(color = Accent.copy(alpha = 0.25f))
                    BasicTextField(
                        value = dialogBox.text,
                        onValueChange = { updateBox(boxTarget.first, dialogBox.copy(text = it)) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp, max = 300.dp),
                        textStyle = TextStyle(color = Ink, fontSize = 14.sp, lineHeight = 21.sp),
                        cursorBrush = SolidColor(Accent),
                        decorationBox = { inner ->
                            Box {
                                if (dialogBox.text.isEmpty()) Text("Escreva aqui...", color = Muted, fontSize = 14.sp)
                                inner()
                            }
                        }
                    )
                    if (dialogBox.image.isNotBlank()) {
                        CoverImage(
                            uri = dialogBox.image, scale = 1f, offsetX = 0f, offsetY = 0f,
                            onClick = { viewingImageUri = dialogBox.image },
                            onDragOut = { imageView -> startImageDrag(context, dialogBox.image, imageView) },
                            modifier = Modifier.fillMaxWidth().heightIn(max = 230.dp)
                                .aspectRatio(1.45f)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = {
                                boxImageTarget = boxTarget
                                boxImagePicker.launch(arrayOf("image/*"))
                            }) { Text("Trocar imagem", color = Accent, fontSize = 11.sp) }
                            TextButton(onClick = { updateBox(boxTarget.first, dialogBox.copy(image = "")) }) {
                                Text("Remover imagem", color = Danger, fontSize = 11.sp)
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = {
                                boxImageTarget = boxTarget
                                boxImagePicker.launch(arrayOf("image/*"))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("+ Adicionar uma imagem", color = Accent, fontSize = 12.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        TextButton(onClick = { removeBox(boxTarget.first, boxTarget.second) }) {
                            Text("Excluir caixa", color = Danger)
                        }
                        TextButton(onClick = { boxDialogTarget = null }) { Text("Concluir", color = Accent) }
                    }
                }
            }
        }
    }

    if (showPaperDialog) {
        AlertDialog(
            onDismissRequest = { showPaperDialog = false },
            title = { Text("Fundo da nota", fontSize = 15.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Cor do fundo", color = Muted, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            Triple("black", "Preto", Color(0xFF101010)),
                            Triple("white", "Branco", Color(0xFFF1F0EA)),
                            Triple("gray", "Cinza", Color(0xFF45454B))
                        ).forEach { (tone, label, swatch) ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.clickable {
                                    paperTone = tone
                                }
                            ) {
                                Box(
                                    Modifier.size(30.dp).clip(CircleShape)
                                        .background(swatch)
                                        .border(
                                            width = if (paperTone == tone) 3.dp else 1.dp,
                                            color = if (paperTone == tone) Accent else Muted.copy(alpha = 0.55f),
                                            shape = CircleShape
                                        )
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(label, color = Ink, fontSize = 10.sp)
                            }
                        }
                    }
                    HorizontalDivider(color = Color(0x33444444))
                    Text("Estilo do papel", color = Muted, fontSize = 11.sp)
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("blank" to "Vazio", "ruled" to "Linhas", "grid" to "Grade").forEach { (style, label) ->
                            PaperStyleSample(
                                style = style,
                                tone = paperTone,
                                selected = paperStyle == style,
                                label = label,
                                modifier = Modifier.weight(1f),
                                onClick = { paperStyle = style }
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPaperDialog = false }) { Text("Concluir") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (showRelatedDialog) {
        val relatedNotes = allNotes.filter { it.deletedAt <= 0L && it.id in selectedLinks }
        AlertDialog(
            onDismissRequest = { showRelatedDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Link, contentDescription = null, tint = Accent)
                    Spacer(Modifier.width(8.dp))
                    Text("Notas relacionadas (${relatedNotes.size})", fontSize = 15.sp)
                }
            },
            text = {
                if (relatedNotes.isEmpty()) {
                    Text("Nenhuma nota relacionada.", color = Muted, fontSize = 12.sp)
                } else {
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        relatedNotes.forEach { other ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Card)
                                    .clickable {
                                        showRelatedDialog = false
                                        onOpenLinked(currentNote(), other.id)
                                    }.padding(horizontal = 12.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(other.title.ifBlank { "Sem título" }, color = Ink, fontSize = 12.sp,
                                    modifier = Modifier.weight(1f), maxLines = 1)
                                Text("Abrir ↗", color = Accent, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showRelatedDialog = false }) { Text("Fechar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (showMarkerDialog) {
        AlertDialog(
            onDismissRequest = { showMarkerDialog = false },
            title = { Text("Marcadores da nota", fontSize = 16.sp) },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Text("Toque nos marcadores para adicionar ou remover desta nota.", color = Muted, fontSize = 11.sp)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        (knownMarkers + selectedMarkers).distinctBy { it.lowercase() }.forEach { marker ->
                            val checked = selectedMarkers.any { it.equals(marker, true) }
                            FilterChip(
                                selected = checked,
                                onClick = {
                                    if (checked) selectedMarkers.removeAll { it.equals(marker, true) }
                                    else selectedMarkers.add(marker)
                                },
                                label = { Text("#${marker}", fontSize = 11.sp) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = newMarker,
                        onValueChange = { newMarker = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Novo marcador", fontSize = 11.sp) }
                    )
                    OutlinedButton(
                        onClick = {
                            val clean = newMarker.trim().removePrefix("#")
                            if (clean.isNotEmpty() && selectedMarkers.none { it.equals(clean, true) }) selectedMarkers.add(clean)
                            newMarker = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Adicionar marcador", fontSize = 11.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { showMarkerDialog = false }) { Text("Concluir") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (pageIndexToDelete >= 0) {
        val deletingPageNumber = pageIndexToDelete + 1
        AlertDialog(
            onDismissRequest = { pageIndexToDelete = -1 },
            title = { Text("Excluir página $deletingPageNumber?") },
            text = { Text("O texto e as imagens desta página serão removidos. As outras páginas serão mantidas.") },
            confirmButton = {
                TextButton(onClick = {
                    val target = pageIndexToDelete
                    if (pages.size > 1 && target in pages.indices) {
                        pages = pages.toMutableList().also { it.removeAt(target) }
                        activePageIndex = when {
                            target < activePageIndex -> activePageIndex - 1
                            target == activePageIndex -> minOf(target, pages.lastIndex)
                            else -> activePageIndex
                        }.coerceIn(0, pages.lastIndex)
                        editorResetToken++
                        pendingCaretAfterReset = -1
                    }
                    pageIndexToDelete = -1
                }) { Text("Excluir página", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { pageIndexToDelete = -1 }) { Text("Cancelar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (imageActionsFor != null) {
        val imageId = imageActionsFor!!
        AlertDialog(
            onDismissRequest = { imageActionsFor = null },
            title = { Text("Imagem selecionada", fontSize = 15.sp) },
            text = { Text("Você pode deslocar a imagem dentro do texto ou removê-la. Para alterar o tamanho, remova e insira novamente.", fontSize = 12.sp) },
            confirmButton = {
                Row {
                    TextButton(onClick = { moveInlineImage(imageId, -1) }) { Text("← Mover") }
                    TextButton(onClick = { moveInlineImage(imageId, 1) }) { Text("Mover →") }
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { imageToDelete = activePageIndex to imageId; imageActionsFor = null }) {
                        Text("Remover", color = Danger)
                    }
                    TextButton(onClick = { imageActionsFor = null }) { Text("Fechar") }
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }

    if (imageToDelete != null) {
        val target = imageToDelete!!
        AlertDialog(
            onDismissRequest = { imageToDelete = null },
            title = { Text("Remover imagem?") },
            text = { Text("A imagem será removida do texto. Para alterar o tamanho, remova e insira novamente.") },
            confirmButton = {
                TextButton(onClick = { removeImageBlock(target.first, target.second) }) {
                    Text("Remover imagem", color = Danger)
                }
            },
            dismissButton = { TextButton(onClick = { imageToDelete = null }) { Text("Cancelar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
}

