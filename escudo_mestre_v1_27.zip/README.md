ESCUDO DO MESTRE 1.27

Notas com caixinhas em janela flutuante, galeria de capa, carregamento assíncrono de imagens e sincronização Firestore.
