# ESCUDO DO MESTRE 1.28

Atualização de interface e editor: capas inteiras em cartões, seletor de fotos do Android com cópia privada das imagens selecionadas, compressão de nuvem com maior resolução e caixinhas inseridas no ponto do cursor do texto. Mantém Firebase, login, sincronização, galeria da capa, imagens por página, compartilhamento nativo e assinatura de release.
