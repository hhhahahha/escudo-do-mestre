# ESCUDO DO MESTRE 1.29

Atualização de desempenho e interação das caixinhas: atualização imediata ao inserir, editar imagem/título ou excluir; cópia da imagem e decodificação das miniaturas em segundo plano com cache; toque em toda a área fechada da caixinha para abrir; caixinhas sem imagem em formato compacto de uma linha. Preserva Firebase Authentication, Firestore, login, sincronização, galeria da capa, imagens por página, compartilhamento nativo e assinatura de release.
