# ESCUDO DO MESTRE 1.3 🎲

Aplicativo Android pessoal de notas para mestres de RPG.

## Recursos desta versão
- Editor em tela inteira com salvamento automático.
- Capas e imagens em cada página interna, preservando a proporção da imagem original e permitindo reposicionamento/zoom.
- Páginas numeradas dentro da mesma nota, com conteúdo e imagem independentes.
- Seleção de várias notas por toque longo e criação de relações entre todas as notas selecionadas.
- Dentro de uma nota, a seção de relações mostra somente as notas já ligadas.
- Marcadores reutilizáveis, pesquisa de conteúdo e painel lateral com arquivadas/marcadores.
- Dados locais no aparelho.

## Atualização
A versão mantém o mesmo applicationId (`br.com.escudodomestre`) e amplia o modelo de dados com páginas internas. Notas antigas são migradas para uma primeira página quando abertas pela primeira vez.

## Compilação
O GitHub Actions compila o APK de depuração com Java 17 e Gradle 8.9.
