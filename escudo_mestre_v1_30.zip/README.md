# ESCUDO DO MESTRE

Versão 1.30 (versionCode 31).

Esta revisão amplia as caixinhas fechadas para ocupar a largura da área de texto e desenha o título em múltiplas linhas. Quando há imagem, a miniatura fica à esquerda e o título começa no topo ao lado dela. Quando não há imagem, a caixa permanece baixa e compacta para títulos curtos, crescendo apenas quando o título realmente precisa de mais linhas.

O aplicativo mantém o applicationId, Firebase Authentication, Firestore e a configuração de assinatura permanente existentes.
