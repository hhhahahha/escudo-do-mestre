# ESCUDO DO MESTRE

Versão 1.32 (versionCode 33).

As caixinhas fechadas passam a dimensionar a largura pelo conteúdo até o limite de metade da linha, permitindo duas caixas lado a lado. O título é exibido em 20sp, com quebra automática; miniaturas preservam a proporção original e a moldura acompanha melhor a imagem e o texto.

O aplicativo mantém o applicationId, Firebase Authentication, Firestore e a configuração de assinatura permanente existentes.
