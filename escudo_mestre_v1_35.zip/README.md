# ESCUDO DO MESTRE

Versão 1.35 (versionCode 36).

A janela de perfil mantém o login/cadastro e o nome de exibição, com os campos extras removidos da edição. O editor de notas recebe botões de desfazer e refazer por página, incluindo alterações de texto e mudanças estruturais em caixinhas e imagens em linha. O histórico é temporário enquanto a nota está aberta; o conteúdo atual continua sendo salvo ao sair ou pelo salvamento automático.

O aplicativo mantém o applicationId, Firebase Authentication, Firestore e a configuração de assinatura permanente existentes.
