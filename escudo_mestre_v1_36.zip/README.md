# ESCUDO DO MESTRE

Versão 1.36 (versionCode 37).

A tela inicial usa grade em alvenaria para reduzir espaços vazios entre notas e ordena as notas recém-criadas no topo. As imagens da capa são aplicadas sem tela de ajuste e continuam podendo ser arrastadas para outros aplicativos; imagens em linha podem ser reposicionadas por arrastar dentro do editor.

Os marcadores podem ser editados ou apagados com gesto lateral no menu. A abertura das caixinhas usa limites de toque próprios, a leitura de miniaturas e a cópia de imagens usam tarefas em segundo plano, e cada caixinha pode ser compartilhada individualmente com sua imagem. As ações de imagem e exclusão ficam no rodapé do editor da caixinha, com Concluir no topo.

O aplicativo preserva o applicationId, Firebase Authentication, Firestore, as regras de segurança, o histórico por página de desfazer/refazer e a configuração de assinatura permanente existentes.
