# ESCUDO DO MESTRE

Versão 1.38 (versionCode 39). Correção do carregamento inicial das imagens das caixinhas e otimização do pipeline de miniaturas, baseada na versão 1.37 aprovada.

## Auditoria e limpeza

- Removidos seis imports sem uso: `ColorDrawable`, `roundToInt`, `TextFieldValue`, `TextRange`, `onFocusChanged` e `FirebaseUser`.
- Removidas duas funções privadas sem chamadas: `locateTextBlockAtCursor` e `BoxThumbnailImage`.
- O decodificador inline síncrono `loadInlineDrawable` foi substituído por placeholders de tamanho conhecido e decodificação assíncrona com cache LRU e deduplicação de solicitações.
- Removida a cópia duplicada do workflow de dentro do ZIP de fontes. O workflow ativo permanece em `.github/workflows/android.yml` na raiz do repositório.
- Removidas as dependências de preview do Compose, pois o projeto não contém usos de `@Preview`.
- Não foram removidos recursos Android adicionais: o ícone D20, os três IDs, o `FileProvider`, `google-services.json`, as regras Firestore e os arquivos Gradle continuam presentes e referenciados.

## Otimizações de execução

- Cópias da galeria, perfil e imagens recebidas do Smart Hub executadas em segundo plano; a permissão temporária de arrastar é mantida até a cópia terminar.
- Decodificação de imagens inline, miniaturas de caixinhas e capas movida para tarefas em segundo plano. Solicitações repetidas da mesma imagem são agrupadas e reutilizam caches LRU.
- Cache de proporções de imagem para evitar reabrir os mesmos arquivos durante recomposições.
- Preparação de anexos de compartilhamento e leitura/escrita de backups movidas para tarefas em segundo plano.
- Imagens já armazenadas em diretórios privados do aplicativo são compartilhadas via FileProvider diretamente, evitando cópias extras no cache e acelerando o arraste das imagens locais.
- Decodificação e gravação de imagens recebidas da nuvem executadas fora da thread da interface.
- Serialização JSON e gravação das notas mantidas em executor de gravação único, com controle de revisão para descartar snapshots antigos.
- O checkpoint de recuperação periódico de 60 segundos foi preservado, mas a serialização e gravação passaram a ocorrer em segundo plano.
- Caches limitados: miniaturas de caixas 8 MB, imagens inline 8 MB, proporções de imagem 256 entradas e cache de capas limitado a 32 MB ou 10% da memória disponível.

## Preservado

- `applicationId` e namespace `br.com.escudodomestre`.
- Firebase Authentication, Firestore, `google-services.json` e `firebase/firestore.rules`.
- Modelos Gson e estrutura de dados das notas, páginas, marcadores, links, caixas e backups.
- Histórico de desfazer/refazer, compartilhamento nativo, Smart Hub, galerias, capas e login.
- `FileProvider` continua não exportado e concede acesso por URI apenas aos diretórios de imagem de notas e ao cache de compartilhamento.
- Assinatura permanente configurada pelo mesmo segredo `ANDROID_SIGNING_BUNDLE`; nenhuma chave foi substituída.

## Arquivos mantidos no pacote

O ZIP mantém o código Android, manifesto, recursos usados, configurações Gradle, configuração Firebase, regras Firestore e este README. O workflow é entregue separadamente para substituir `.github/workflows/android.yml` no repositório, evitando armazenar uma segunda cópia que não participa da compilação.

A auditoria foi estática. A compilação Android completa e a verificação da assinatura devem ser confirmadas pelo GitHub Actions antes de considerar a versão pronta.


## Correção de miniaturas das caixinhas (1.38)

- O editor identifica a página associada a cada instância de `NoteEditText`; respostas assíncronas são encaminhadas ao editor atualmente visível daquela página, evitando atualizar uma view já descartada durante a troca de página.
- Ao terminar a decodificação, o `ReplacementSpan` é removido e recolocado na mesma `Editable`, disparando o reflow real do `TextView` sem substituir o texto, perder seleção ou interferir no teclado.
- Miniaturas usam executor dedicado, evitando disputar as filas de capas e imagens inline.
- Payloads Base64 são decodificados uma única vez por solicitação; arquivos locais usam `BitmapFactory.decodeFile` com amostragem.
- Acesso aos caches LRU de miniaturas e imagens inline é sincronizado entre a interface e os workers.
- Decodificações malsucedidas mantêm o placeholder sem forçar reflow.
