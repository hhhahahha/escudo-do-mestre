# ESCUDO DO MESTRE 1.4 🎲

Aplicativo Android pessoal de notas para mestres de RPG.

## Recursos desta versão
- Editor em tela inteira, páginas internas numeradas e imagens por página.
- Exclusão de fichas pela biblioteca: segure uma ficha fechada, toque em Excluir e confirme. Também permite excluir várias fichas selecionadas.
- Miniaturas das capas com enquadramento priorizando a parte superior da imagem.
- Backup em ZIP com notas, marcadores, relações, páginas e bytes das imagens.
- Restauração de backup com opção de mesclar ou substituir as notas atuais.
- O seletor de arquivos Android permite escolher Google Drive como destino/origem, quando o Drive estiver disponível no aparelho. O backup é manual, não sincronização automática.
- Marcadores reutilizáveis, pesquisa de conteúdo, painel lateral, arquivamento e relações entre notas.

## Compatibilidade e dados
- Mantém o applicationId `br.com.escudodomestre` para instalar como atualização da versão anterior.
- Mantém o formato dos dados locais e os campos anteriores de nota.
- Os backups ZIP incluem as imagens, para que a restauração não dependa dos caminhos de galeria da instalação antiga.

## Compilação
O GitHub Actions compila o APK de depuração com Java 17 e Gradle 8.9.
