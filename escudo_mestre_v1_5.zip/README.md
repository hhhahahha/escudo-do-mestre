# ESCUDO DO MESTRE 1.5 🎲

Aplicativo Android pessoal de anotações para mestres de RPG.

## Novidades desta versão
- Lixeira: fichas excluídas ficam recuperáveis por 7 dias.
- Restauração individual ou em grupo a partir da lixeira.
- Exclusão permanente individual/em grupo e opção de esvaziar a lixeira.
- Limpeza automática de fichas com mais de 7 dias na lixeira, ao iniciar o app e periodicamente enquanto estiver aberto.
- Cada página interna pode ser excluída individualmente pelo botão X da aba, com confirmação. Uma nota mantém pelo menos uma página.
- Ícones padrão de etiqueta para marcadores e corrente/link para relações entre fichas.
- Miniaturas de capas reposicionadas para mostrar melhor rosto e parte superior dos personagens.

## Recursos mantidos
- Tema preto, cartões com capas quadradas, editor de tela inteira.
- Páginas internas numeradas e imagens individuais por página.
- Marcadores reutilizáveis, pesquisa no conteúdo, painel lateral e arquivamento.
- Relações entre fichas, seleção múltipla e operações em grupo.
- Backup ZIP com notas, imagens, páginas, marcadores e relações, com restauração por mesclagem ou substituição.

## Compatibilidade e dados
- Mantém o applicationId `br.com.escudodomestre` para atualizar a instalação anterior.
- Mantém os campos anteriores da ficha e acrescenta `deletedAt`, com padrão zero para notas antigas.
- A lixeira é local e incluída nos backups.

## Compilação
O GitHub Actions compila o APK de depuração com Java 17 e Gradle 8.9.
