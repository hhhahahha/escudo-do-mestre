package br.com.escudodomestre

import android.content.Context
import android.graphics.Matrix
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Label
import androidx.compose.material.icons.outlined.Link
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.UUID
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF191919)
private val Card = Color(0xFF202020)
private val CardRaised = Color(0xFF282828)
private val Ink = Color(0xFFF2F0EA)
private val Muted = Color(0xFFAAA69D)
private val Accent = Color(0xFFD6C9A8)
private val Danger = Color(0xFFE58A82)
private const val TRASH_RETENTION_MS = 7L * 24L * 60L * 60L * 1000L

/**
 * Keep the old field names and String representation for markers/links so notes
 * created by version 1.0 remain readable after updating the APK.
 */
data class NotePage(
    val id: String = UUID.randomUUID().toString(),
    val body: String = "",
    val image: String = "",
    val imageScale: Float = 1f,
    val imageOffsetX: Float = 0f,
    val imageOffsetY: Float = 0f,
    val imageAspectRatio: Float = 1.7778f
)

data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val cover: String = "",
    val markers: String = "",
    val links: String = "",
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val coverScale: Float = 1f,
    val coverOffsetX: Float = 0f,
    val coverOffsetY: Float = 0f,
    val coverAspectRatio: Float = 1.7778f,
    val pages: List<NotePage> = emptyList(),
    // 0 = active note; otherwise epoch millis when moved to the trash.
    val deletedAt: Long = 0L
)

/** ZIP backup keeps note data and the actual image bytes together, so restored images
 * do not depend on gallery URIs from the old installation. */
data class NotesBackup(
    val formatVersion: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: List<Note> = emptyList(),
    val markers: List<String> = emptyList()
)

private fun exportNotesBackup(
    context: Context,
    destination: Uri,
    notes: List<Note>,
    markers: List<String>,
    gson: Gson
) {
    val imageEntries = linkedMapOf<String, String>()
    fun archiveImageReference(value: String): String {
        if (value.isBlank()) return value
        return imageEntries.getOrPut(value) { "media/image_${imageEntries.size + 1}.bin" }
    }

    val portableNotes = notes.map { note ->
        note.copy(
            cover = archiveImageReference(note.cover),
            pages = note.pages.orEmpty().map { page ->
                page.copy(image = archiveImageReference(page.image))
            }
        )
    }
    val backup = NotesBackup(notes = portableNotes, markers = markers)
    val output = context.contentResolver.openOutputStream(destination)
        ?: error("Não foi possível abrir o destino do backup.")

    ZipOutputStream(BufferedOutputStream(output)).use { zip ->
        zip.putNextEntry(ZipEntry("backup.json"))
        zip.write(gson.toJson(backup).toByteArray(Charsets.UTF_8))
        zip.closeEntry()

        imageEntries.forEach { (sourceUri, archivePath) ->
            val input = context.contentResolver.openInputStream(Uri.parse(sourceUri))
                ?: error("Não foi possível ler uma imagem da nota. Tente selecionar a imagem novamente antes do backup.")
            zip.putNextEntry(ZipEntry(archivePath))
            input.use { it.copyTo(zip) }
            zip.closeEntry()
        }
    }
}

private fun importNotesBackup(
    context: Context,
    source: Uri,
    gson: Gson
): NotesBackup {
    val root = File(context.filesDir, "restored-backup-media/${UUID.randomUUID()}").apply { mkdirs() }
    val restoredMedia = mutableMapOf<String, String>()
    var manifest: String? = null
    val input = context.contentResolver.openInputStream(source)
        ?: error("Não foi possível abrir o arquivo de backup.")

    ZipInputStream(BufferedInputStream(input)).use { zip ->
        var entry = zip.nextEntry
        while (entry != null) {
            val name = entry.name.replace('\\', '/')
            when {
                name == "backup.json" -> {
                    manifest = zip.readBytes().toString(Charsets.UTF_8)
                }
                name.startsWith("media/") && !name.contains("..") && !entry.isDirectory -> {
                    val fileName = name.substringAfterLast('/')
                    val outFile = File(root, fileName)
                    outFile.outputStream().buffered().use { zip.copyTo(it) }
                    restoredMedia[name] = Uri.fromFile(outFile).toString()
                }
            }
            zip.closeEntry()
            entry = zip.nextEntry
        }
    }

    val json = manifest ?: error("Este arquivo não contém um backup válido do ESCUDO DO MESTRE.")
    val parsed = gson.fromJson(json, NotesBackup::class.java)
        ?: error("Não foi possível interpretar o backup.")
    if (parsed.formatVersion != 1) error("A versão deste backup não é compatível com este aplicativo.")

    fun restoreImage(value: String): String = restoredMedia[value] ?: value
    val restoredNotes = parsed.notes.map { note ->
        note.copy(
            cover = restoreImage(note.cover),
            pages = note.pages.orEmpty().map { page -> page.copy(image = restoreImage(page.image)) }
        )
    }
    return parsed.copy(notes = restoredNotes)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp() }
    }
}

private fun splitValues(raw: String): List<String> = raw
    .split(',', '\n')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .distinctBy { it.lowercase() }

private fun parseIds(raw: String): Set<String> = raw
    .split(',')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .toSet()

private fun safeScale(note: Note): Float = note.coverScale.takeIf { it >= 1f } ?: 1f

private fun safeAspectRatio(value: Float, fallback: Float = 1.7778f): Float =
    (value.takeIf { it.isFinite() && it > 0.05f } ?: fallback).coerceIn(0.25f, 4f)

private fun normalizePages(note: Note): List<NotePage> {
    val stored = note.pages.orEmpty()
    if (stored.isNotEmpty()) {
        return stored.map { page ->
            page.copy(
                imageScale = page.imageScale.takeIf { it >= 1f } ?: 1f,
                imageAspectRatio = safeAspectRatio(page.imageAspectRatio)
            )
        }
    }
    // Migration for notes created before numbered pages existed.
    return listOf(
        NotePage(
            body = note.body,
            image = note.cover,
            imageScale = note.coverScale.takeIf { it >= 1f } ?: 1f,
            imageOffsetX = note.coverOffsetX,
            imageOffsetY = note.coverOffsetY,
            imageAspectRatio = safeAspectRatio(note.coverAspectRatio)
        )
    )
}

private fun readImageAspectRatio(context: Context, uri: Uri): Float {
    return runCatching {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
        if (options.outWidth > 0 && options.outHeight > 0) {
            safeAspectRatio(options.outWidth.toFloat() / options.outHeight.toFloat())
        } else 1.7778f
    }.getOrDefault(1.7778f)
}

private fun applyCoverMatrix(view: ImageView, scale: Float, offsetX: Float, offsetY: Float) {
    val drawable = view.drawable ?: return
    val viewW = view.width.toFloat()
    val viewH = view.height.toFloat()
    val imageW = drawable.intrinsicWidth.toFloat()
    val imageH = drawable.intrinsicHeight.toFloat()
    if (viewW <= 0f || viewH <= 0f || imageW <= 0f || imageH <= 0f) return

    val fit = max(viewW / imageW, viewH / imageH)
    val finalScale = fit * scale.coerceAtLeast(1f)
    val drawnW = imageW * finalScale
    val drawnH = imageH * finalScale
    val tx = (viewW - drawnW) / 2f + offsetX * viewW
    val ty = (viewH - drawnH) / 2f + offsetY * viewH
    val matrix = Matrix().apply {
        setScale(finalScale, finalScale)
        postTranslate(tx, ty)
    }
    view.imageMatrix = matrix
}

@Composable
fun EscudoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("escudo_notas", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }
    val noteType = remember { object : TypeToken<List<Note>>() {}.type }
    val markerType = remember { object : TypeToken<List<String>>() {}.type }

    val notes = remember {
        mutableStateListOf<Note>().apply {
            val loaded = runCatching {
                gson.fromJson<List<Note>>(prefs.getString("notes", "[]"), noteType)
            }.getOrNull().orEmpty()
            val cutoff = System.currentTimeMillis() - TRASH_RETENTION_MS
            val retained = loaded.filter { it.deletedAt <= 0L || it.deletedAt > cutoff }
            val normalized = retained.map { old ->
                // Keep notes from older APKs readable while introducing numbered pages.
                val normalizedPages = normalizePages(old)
                old.copy(
                    coverScale = safeScale(old),
                    pages = normalizedPages,
                    body = normalizedPages.firstOrNull()?.body ?: old.body,
                    cover = normalizedPages.firstOrNull()?.image ?: old.cover,
                    coverAspectRatio = normalizedPages.firstOrNull()?.imageAspectRatio
                        ?: safeAspectRatio(old.coverAspectRatio)
                )
            }
            addAll(normalized)
            if (normalized.size != loaded.size) {
                prefs.edit().putString("notes", gson.toJson(normalized)).apply()
            }
        }
    }
    val savedMarkers = remember {
        mutableStateListOf<String>().apply {
            val fromPrefs = runCatching {
                gson.fromJson<List<String>>(prefs.getString("saved_markers", "[]"), markerType)
            }.getOrNull().orEmpty()
            val fromNotes = notes.flatMap { splitValues(it.markers) }
            addAll((fromPrefs + fromNotes).distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
        }
    }

    var search by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var showingArchived by remember { mutableStateOf(false) }
    var showingTrash by remember { mutableStateOf(false) }
    var activeMarker by remember { mutableStateOf<String?>(null) }
    var backupMessage by remember { mutableStateOf<String?>(null) }
    var pendingRestore by remember { mutableStateOf<NotesBackup?>(null) }

    val backupCreator = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            val result = runCatching { exportNotesBackup(context, uri, notes.toList(), savedMarkers.toList(), gson) }
            backupMessage = result.fold(
                { "Backup criado com ${notes.size} ficha(s), incluindo imagens. No seletor de arquivos, escolha Google Drive para guardar na nuvem. O backup é manual: faça um novo quando quiser atualizar a cópia." },
                { "Não foi possível criar o backup: ${it.message ?: "erro ao gravar arquivo"}" }
            )
        }
    }
    val backupRestorer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val result = runCatching { importNotesBackup(context, uri, gson) }
            result.onSuccess { pendingRestore = it }
                .onFailure { backupMessage = "Não foi possível restaurar: ${it.message ?: "arquivo inválido"}" }
        }
    }

    fun purgeExpiredTrash() {
        val cutoff = System.currentTimeMillis() - TRASH_RETENTION_MS
        val expiredIds = notes.filter { it.deletedAt > 0L && it.deletedAt <= cutoff }
            .map { it.id }.toSet()
        if (expiredIds.isEmpty()) return
        notes.removeAll { it.id in expiredIds }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in expiredIds }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
    }

    fun persist() {
        purgeExpiredTrash()
        prefs.edit()
            .putString("notes", gson.toJson(notes))
            .putString("saved_markers", gson.toJson(savedMarkers))
            .apply()
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            purgeExpiredTrash()
            prefs.edit().putString("notes", gson.toJson(notes)).apply()
        }
    }

    fun registerMarker(value: String) {
        val clean = value.trim().removePrefix("#")
        if (clean.isNotEmpty() && savedMarkers.none { it.equals(clean, ignoreCase = true) }) {
            savedMarkers.add(clean)
            savedMarkers.sortBy { it.lowercase() }
            persist()
        }
    }

    fun saveNote(updated: Note) {
        splitValues(updated.markers).forEach { registerMarker(it) }
        val index = notes.indexOfFirst { it.id == updated.id }
        if (index >= 0) notes[index] = updated else notes.add(0, updated)
        persist()
    }

    fun deleteNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        val movedAt = System.currentTimeMillis()
        for (i in notes.indices) {
            if (notes[i].id in ids && notes[i].deletedAt <= 0L) {
                notes[i] = notes[i].copy(deletedAt = movedAt)
            }
        }
        persist()
    }

    fun restoreTrashNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        for (i in notes.indices) {
            if (notes[i].id in ids && notes[i].deletedAt > 0L) {
                notes[i] = notes[i].copy(deletedAt = 0L)
            }
        }
        persist()
    }

    fun permanentlyDeleteNotes(ids: Set<String>) {
        if (ids.isEmpty()) return
        notes.removeAll { it.id in ids }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in ids }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun emptyTrash() {
        val trashedIds = notes.filter { it.deletedAt > 0L }.map { it.id }.toSet()
        if (trashedIds.isEmpty()) return
        notes.removeAll { it.id in trashedIds }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it in trashedIds }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    fun applyMarkersToNotes(ids: Set<String>, markers: Set<String>, remove: Boolean) {
        if (markers.isEmpty()) return
        markers.forEach { if (!remove) registerMarker(it) }
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val existing = splitValues(current.markers).toMutableSet()
                val next = if (remove) {
                    existing.filterNot { old -> markers.any { it.equals(old, true) } }.toSet()
                } else {
                    (existing + markers).toSet()
                }
                notes[i] = current.copy(markers = next.joinToString(", "))
            }
        }
        persist()
    }

    fun archiveNotes(ids: Set<String>, archived: Boolean) {
        for (i in notes.indices) {
            if (notes[i].id in ids) notes[i] = notes[i].copy(archived = archived)
        }
        persist()
    }

    fun relateSelectedNotes(ids: Set<String>) {
        if (ids.size < 2) return
        for (i in notes.indices) {
            val current = notes[i]
            if (current.id in ids) {
                val related = parseIds(current.links).toMutableSet()
                related.addAll(ids - current.id)
                notes[i] = current.copy(links = related.joinToString(","))
            }
        }
        persist()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg,
        surface = Card,
        surfaceVariant = CardRaised,
        primary = Accent,
        onPrimary = Bg,
        onBackground = Ink,
        onSurface = Ink,
        secondary = Muted
    )) {
        if (editingNote != null) {
            EditorScreen(
                note = editingNote!!,
                allNotes = notes.toList(),
                onSave = { updated -> saveNote(updated); editingNote = null },
                onAutoSave = ::saveNote,
                onOpenLinked = { current, targetId ->
                    saveNote(current)
                    editingNote = notes.firstOrNull { it.id == targetId }?.copy()
                }
            )
        } else {
            NotesHome(
                notes = notes,
                knownMarkers = savedMarkers,
                search = search,
                onSearchChange = { search = it },
                showingArchived = showingArchived,
                showingTrash = showingTrash,
                onShowArchived = { showingTrash = false; showingArchived = true; activeMarker = null },
                onShowTrash = { showingTrash = true; showingArchived = false; activeMarker = null },
                onShowNotes = { showingTrash = false; showingArchived = false; activeMarker = null },
                activeMarker = activeMarker,
                onSelectMarker = { marker -> showingTrash = false; showingArchived = false; activeMarker = marker },
                onOpenNote = { editingNote = it.copy(coverScale = safeScale(it)) },
                onNewNote = { editingNote = Note() },
                onBulkApplyMarkers = ::applyMarkersToNotes,
                onBulkArchive = ::archiveNotes,
                onBulkRelate = ::relateSelectedNotes,
                onBulkDelete = ::deleteNotes,
                onRestoreTrash = ::restoreTrashNotes,
                onDeleteForever = ::permanentlyDeleteNotes,
                onEmptyTrash = ::emptyTrash,
                onCreateBackup = {
                    val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())
                    backupCreator.launch("ESCUDO-DO-MESTRE-backup-$stamp.zip")
                },
                onRestoreBackup = { backupRestorer.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
            )
        }
    }

    if (pendingRestore != null) {
        val backup = pendingRestore!!
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("Restaurar backup do Drive") },
            text = { Text("O arquivo contém ${backup.notes.size} ficha(s) e ${backup.markers.size} marcador(es). Você pode mesclar com as notas atuais ou substituir tudo.") },
            confirmButton = {
                TextButton(onClick = {
                    val merged = notes.toMutableList()
                    backup.notes.forEach { restored ->
                        val index = merged.indexOfFirst { it.id == restored.id }
                        if (index >= 0) merged[index] = restored else merged.add(0, restored)
                    }
                    notes.clear(); notes.addAll(merged)
                    backup.markers.forEach { marker ->
                        if (savedMarkers.none { it.equals(marker, true) }) savedMarkers.add(marker)
                    }
                    savedMarkers.sortBy { it.lowercase() }
                    persist()
                    pendingRestore = null
                    backupMessage = "Backup mesclado. ${backup.notes.size} ficha(s) foram importadas."
                }) { Text("Mesclar") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingRestore = null }) { Text("Cancelar") }
                    TextButton(onClick = {
                        notes.clear(); notes.addAll(backup.notes)
                        savedMarkers.clear(); savedMarkers.addAll(backup.markers.distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
                        persist()
                        pendingRestore = null
                        backupMessage = "Backup restaurado. As notas atuais foram substituídas."
                    }) { Text("Substituir tudo", color = Danger) }
                }
            },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
    if (backupMessage != null) {
        AlertDialog(
            onDismissRequest = { backupMessage = null },
            title = { Text("Backup do ESCUDO DO MESTRE") },
            text = { Text(backupMessage!! ) },
            confirmButton = { TextButton(onClick = { backupMessage = null }) { Text("OK") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NotesHome(
    notes: List<Note>,
    knownMarkers: List<String>,
    search: String,
    onSearchChange: (String) -> Unit,
    showingArchived: Boolean,
    showingTrash: Boolean,
    onShowArchived: () -> Unit,
    onShowTrash: () -> Unit,
    onShowNotes: () -> Unit,
    activeMarker: String?,
    onSelectMarker: (String) -> Unit,
    onOpenNote: (Note) -> Unit,
    onNewNote: () -> Unit,
    onBulkApplyMarkers: (Set<String>, Set<String>, Boolean) -> Unit,
    onBulkArchive: (Set<String>, Boolean) -> Unit,
    onBulkRelate: (Set<String>) -> Unit,
    onBulkDelete: (Set<String>) -> Unit,
    onRestoreTrash: (Set<String>) -> Unit,
    onDeleteForever: (Set<String>) -> Unit,
    onEmptyTrash: () -> Unit,
    onCreateBackup: () -> Unit,
    onRestoreBackup: () -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val selectedIds = remember { mutableStateListOf<String>() }
    var showBulkMarkers by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showPermanentDeleteConfirmation by remember { mutableStateOf(false) }
    var showEmptyTrashConfirmation by remember { mutableStateOf(false) }
    val selectedNotes = notes.filter { it.id in selectedIds }
    val allSelectedArchived = selectedNotes.isNotEmpty() && selectedNotes.all { it.archived }

    fun toggleSelected(id: String) {
        if (id in selectedIds) selectedIds.remove(id) else selectedIds.add(id)
    }
    fun openOrSelect(note: Note) {
        if (showingTrash || selectedIds.isNotEmpty()) toggleSelected(note.id) else onOpenNote(note)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Panel,
                drawerContentColor = Ink
            ) {
                Column(
                    Modifier.fillMaxHeight().statusBarsPadding().padding(horizontal = 18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Spacer(Modifier.height(20.dp))
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Organização do grimório", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        value = search,
                        onValueChange = onSearchChange,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Pesquisar notas e palavras") },
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                    )
                    Spacer(Modifier.height(16.dp))
                    NavigationDrawerItem(
                        label = { Text("Todas as notas") },
                        selected = !showingArchived && !showingTrash && activeMarker == null,
                        onClick = { selectedIds.clear(); onShowNotes(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        label = { Text("Arquivadas") },
                        selected = showingArchived && !showingTrash,
                        onClick = { selectedIds.clear(); onShowArchived(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        label = { Text("Lixeira (${notes.count { it.deletedAt > 0L }})") },
                        selected = showingTrash,
                        onClick = { selectedIds.clear(); onShowTrash(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("SEGURANÇA DAS NOTAS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    NavigationDrawerItem(
                        label = { Text("Salvar backup na nuvem (ZIP)") },
                        selected = false,
                        onClick = { scope.launch { drawerState.close() }; onCreateBackup() },
                        colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Ink)
                    )
                    NavigationDrawerItem(
                        label = { Text("Restaurar backup do Drive") },
                        selected = false,
                        onClick = { scope.launch { drawerState.close() }; onRestoreBackup() },
                        colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Ink)
                    )
                    HorizontalDivider(color = Color(0xFF373737), modifier = Modifier.padding(vertical = 12.dp))
                    Text("MARCADORES SALVOS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (knownMarkers.isEmpty()) {
                        Text("Seus marcadores aparecerão aqui quando você criar o primeiro.", color = Muted, fontSize = 12.sp)
                    } else {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            knownMarkers.forEach { marker ->
                                FilterChip(
                                    selected = activeMarker == marker,
                                    onClick = { selectedIds.clear(); onSelectMarker(marker); scope.launch { drawerState.close() } },
                                    label = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Outlined.Label, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(marker, maxLines = 1)
                                        }
                                    }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("Dica: deslize da borda esquerda para abrir este painel.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    ) {
        val filtered = notes
            .filter { if (showingTrash) it.deletedAt > 0L else it.deletedAt <= 0L }
            // A marker view deliberately spans both active and archived notes.
            .filter { showingTrash || activeMarker != null || it.archived == showingArchived }
            .filter { activeMarker == null || splitValues(it.markers).any { tag -> tag.equals(activeMarker, true) } }
            .filter {
                search.isBlank() || it.title.contains(search, true) ||
                    it.body.contains(search, true) || it.markers.contains(search, true) ||
                    it.pages.orEmpty().any { page -> page.body.contains(search, true) }
            }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.title })

        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectedIds.isNotEmpty()) {
                    TextButton(onClick = { selectedIds.clear() }, contentPadding = PaddingValues(8.dp)) {
                        Text("✕", color = Ink, fontSize = 22.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${selectedIds.size} selecionada(s)", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Toque em outras fichas para incluí-las", color = Muted, fontSize = 11.sp)
                    }
                } else {
                    TextButton(onClick = { scope.launch { drawerState.open() } }, contentPadding = PaddingValues(8.dp)) {
                        Text("☰", color = Ink, fontSize = 25.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("ESCUDO DO MESTRE", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Seu grimório de anotações", color = Muted, fontSize = 12.sp)
                    }
                    Text("◈ D20", color = Accent, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Pesquisar notas ou palavras dentro delas") },
                shape = RoundedCornerShape(15.dp),
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        TextButton(onClick = { onSearchChange("") }) { Text("Limpar") }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
            )
            Text("Segure uma ficha para selecionar várias e editar marcadores em grupo.",
                color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            showingTrash -> "Lixeira"
                            showingArchived -> "Arquivadas"
                            activeMarker != null -> "#${activeMarker}"
                            else -> "Minhas notas"
                        },
                        color = Ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text("${filtered.size} notas", color = Muted, fontSize = 11.sp)
                }
                if (showingTrash) {
                    TextButton(onClick = { showEmptyTrashConfirmation = true }) {
                        Text("Esvaziar", color = Danger)
                    }
                } else if (activeMarker != null || showingArchived) {
                    TextButton(onClick = onShowNotes) { Text("Ver todas", color = Accent) }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◈", color = Accent, fontSize = 42.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when {
                                search.isNotBlank() -> "Nenhuma nota encontrada"
                                showingTrash -> "A lixeira está vazia"
                                showingArchived -> "Nada arquivado por enquanto"
                                activeMarker != null -> "Nenhuma nota com este marcador"
                                else -> "Seu escudo está pronto"
                            },
                            color = Ink, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            if (showingTrash) "As fichas excluídas ficarão aqui por 7 dias."
                            else "Crie uma nota ou ajuste sua pesquisa.",
                            color = Muted, fontSize = 12.sp
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 145.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        NoteCard(
                            note = note,
                            selected = note.id in selectedIds,
                            onClick = { openOrSelect(note) },
                            onLongClick = { toggleSelected(note.id) }
                        )
                    }
                }
            }
            if (selectedIds.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (showingTrash) {
                        Button(
                            onClick = {
                                onRestoreTrash(selectedIds.toSet())
                                selectedIds.clear()
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Restaurar", fontSize = 11.sp) }
                        OutlinedButton(
                            onClick = { showPermanentDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
                        ) { Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Apagar", fontSize = 11.sp) }
                    } else {
                        OutlinedButton(
                            onClick = { showBulkMarkers = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Icon(Icons.Outlined.Label, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Marcadores", fontSize = 9.sp) }
                        OutlinedButton(
                            onClick = {
                                onBulkRelate(selectedIds.toSet())
                                selectedIds.clear()
                            },
                            enabled = selectedIds.size >= 2,
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) { Icon(Icons.Outlined.Link, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Relacionar", fontSize = 9.sp) }
                        OutlinedButton(
                            onClick = { showDeleteConfirmation = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Danger)
                        ) { Icon(Icons.Outlined.Delete, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(3.dp)); Text("Lixeira", fontSize = 9.sp) }
                        Button(
                            onClick = {
                                onBulkArchive(selectedIds.toSet(), !allSelectedArchived)
                                selectedIds.clear()
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text(if (allSelectedArchived) "Restaurar" else "Arquivar", fontSize = 9.sp) }
                    }
                }
            } else if (!showingTrash) {
                Button(
                    onClick = onNewNote,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text("+ Nova nota", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 5.dp))
                }
            }

            if (showBulkMarkers) {
                BulkMarkerDialog(
                    selectedCount = selectedIds.size,
                    knownMarkers = knownMarkers,
                    onDismiss = { showBulkMarkers = false },
                    onApply = { markers, remove ->
                        onBulkApplyMarkers(selectedIds.toSet(), markers, remove)
                        showBulkMarkers = false
                        selectedIds.clear()
                    }
                )
            }
            if (showDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirmation = false },
                    title = { Text("Mover para a lixeira?") },
                    text = { Text("${selectedIds.size} ficha(s) ficarão na lixeira por 7 dias. Nesse período, você poderá restaurá-las ou apagá-las definitivamente.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onBulkDelete(selectedIds.toSet())
                            selectedIds.clear()
                            showDeleteConfirmation = false
                        }) { Text("Mover para a lixeira", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
            if (showPermanentDeleteConfirmation) {
                AlertDialog(
                    onDismissRequest = { showPermanentDeleteConfirmation = false },
                    title = { Text("Apagar definitivamente?") },
                    text = { Text("${selectedIds.size} ficha(s) serão removidas agora. Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onDeleteForever(selectedIds.toSet())
                            selectedIds.clear()
                            showPermanentDeleteConfirmation = false
                        }) { Text("Apagar definitivamente", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showPermanentDeleteConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
            if (showEmptyTrashConfirmation) {
                AlertDialog(
                    onDismissRequest = { showEmptyTrashConfirmation = false },
                    title = { Text("Esvaziar lixeira?") },
                    text = { Text("Todas as fichas na lixeira serão apagadas definitivamente. Esta ação não pode ser desfeita.") },
                    confirmButton = {
                        TextButton(onClick = {
                            onEmptyTrash()
                            selectedIds.clear()
                            showEmptyTrashConfirmation = false
                        }) { Text("Esvaziar lixeira", color = Danger) }
                    },
                    dismissButton = { TextButton(onClick = { showEmptyTrashConfirmation = false }) { Text("Cancelar") } },
                    containerColor = Panel,
                    titleContentColor = Ink,
                    textContentColor = Ink
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCard(
    note: Note,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val shape = RoundedCornerShape(17.dp)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) Accent else Color.Transparent,
                shape = shape
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = if (selected) CardRaised else Card)
    ) {
        Column(Modifier.padding(9.dp)) {
            Box {
                if (note.cover.isNotBlank()) {
                    CoverImage(
                        uri = note.cover,
                        scale = safeScale(note),
                        offsetX = note.coverOffsetX,
                        // Move portrait artwork down inside the square viewport so the face
                        // and upper body are shown instead of the abdomen.
                        offsetY = (note.coverOffsetY + 0.28f).coerceIn(-1f, 1f),
                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                    )
                } else {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                            .background(Color(0xFF303030)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("◈ D20", color = Accent, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (selected) {
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(7.dp)
                            .size(27.dp).clip(RoundedCornerShape(50)).background(Accent),
                        contentAlignment = Alignment.Center
                    ) { Text("✓", color = Bg, fontWeight = FontWeight.Bold) }
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(note.title.ifBlank { "Sem título" }, color = Ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, modifier = Modifier.weight(1f))
                if (note.pinned) Text("📌", fontSize = 12.sp)
            }
            if (note.body.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(note.body, color = Muted, fontSize = 11.sp, maxLines = 2)
            }
            val tags = splitValues(note.markers).take(2)
            val relationCount = parseIds(note.links).size
            if (tags.isNotEmpty() || relationCount > 0) {
                Spacer(Modifier.height(7.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (tags.isNotEmpty()) {
                        Icon(Icons.Outlined.Label, contentDescription = "Marcadores", tint = Accent, modifier = Modifier.size(13.dp))
                        Text(tags.joinToString("  ") { it }, color = Accent, fontSize = 10.sp, maxLines = 1)
                    }
                    if (relationCount > 0) {
                        Icon(Icons.Outlined.Link, contentDescription = "Notas relacionadas", tint = Muted, modifier = Modifier.size(13.dp))
                        Text(relationCount.toString(), color = Muted, fontSize = 10.sp)
                    }
                }
            }
            if (note.archived) {
                Spacer(Modifier.height(5.dp))
                Text("ARQUIVADA", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BulkMarkerDialog(
    selectedCount: Int,
    knownMarkers: List<String>,
    onDismiss: () -> Unit,
    onApply: (Set<String>, Boolean) -> Unit
) {
    val choices = remember(knownMarkers) {
        mutableStateListOf<String>().apply { addAll(knownMarkers) }
    }
    val selectedMarkers = remember { mutableStateListOf<String>() }
    var newMarker by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Marcadores • $selectedCount fichas") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 430.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    if (removing) "Escolha os marcadores que serão removidos das fichas selecionadas."
                    else "Escolha os marcadores que serão adicionados às fichas selecionadas.",
                    color = Muted, fontSize = 12.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remover marcadores", modifier = Modifier.weight(1f), color = Ink)
                    Switch(checked = removing, onCheckedChange = { removing = it })
                }
                if (choices.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(7.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        choices.forEach { marker ->
                            val isSelected = selectedMarkers.any { it.equals(marker, true) }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) selectedMarkers.removeAll { it.equals(marker, true) }
                                    else selectedMarkers.add(marker)
                                },
                                label = { Text("#${marker}") }
                            )
                        }
                    }
                } else {
                    Text("Ainda não existem marcadores salvos.", color = Muted, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = newMarker,
                    onValueChange = { newMarker = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Criar marcador") }
                )
                OutlinedButton(
                    onClick = {
                        val clean = newMarker.trim().removePrefix("#")
                        if (clean.isNotEmpty() && choices.none { it.equals(clean, true) }) {
                            choices.add(clean)
                            selectedMarkers.add(clean)
                        }
                        newMarker = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Adicionar marcador à lista") }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onApply(selectedMarkers.toSet(), removing) },
                enabled = selectedMarkers.isNotEmpty()
            ) { Text(if (removing) "Remover" else "Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
        containerColor = Panel,
        titleContentColor = Ink,
        textContentColor = Ink
    )
}

@Composable
private fun CoverImage(
    uri: String,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.MATRIX } },
        update = { view ->
            if (view.tag != uri) {
                runCatching { view.setImageURI(Uri.parse(uri)) }
                view.tag = uri
            }
            view.post { applyCoverMatrix(view, scale.coerceAtLeast(1f), offsetX, offsetY) }
        },
        modifier = modifier
    )
}

@Composable
private fun EditorScreen(
    note: Note,
    allNotes: List<Note>,
    onSave: (Note) -> Unit,
    onAutoSave: (Note) -> Unit,
    onOpenLinked: (Note, String) -> Unit
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var title by remember(note.id) { mutableStateOf(note.title) }
    var pages by remember(note.id) { mutableStateOf(normalizePages(note)) }
    var activePageIndex by remember(note.id) { mutableIntStateOf(0) }
    var selectedLinks by remember(note.id) { mutableStateOf(parseIds(note.links)) }
    var pageIndexToDelete by remember(note.id) { mutableIntStateOf(-1) }
    var pinned by remember(note.id) { mutableStateOf(note.pinned) }
    var archived by remember(note.id) { mutableStateOf(note.archived) }

    // Image editing is a temporary mode. Each numbered page owns its own image,
    // aspect ratio, zoom and crop coordinates.
    var imageAdjusting by remember(note.id) { mutableStateOf(false) }
    var pendingImageUri by remember(note.id) { mutableStateOf<String?>(null) }
    var pendingScale by remember(note.id) { mutableFloatStateOf(1f) }
    var pendingOffsetX by remember(note.id) { mutableFloatStateOf(0f) }
    var pendingOffsetY by remember(note.id) { mutableFloatStateOf(0f) }
    var pendingAspectRatio by remember(note.id) { mutableFloatStateOf(1.7778f) }

    fun updatePage(index: Int, updated: NotePage) {
        if (index !in pages.indices) return
        pages = pages.toMutableList().also { it[index] = updated }
    }

    fun currentPage(): NotePage = pages.getOrNull(activePageIndex) ?: pages.first()

    fun currentNote(): Note {
        val first = pages.firstOrNull() ?: NotePage()
        return note.copy(
            title = title.trim(),
            body = first.body,
            cover = first.image,
            markers = note.markers,
            links = selectedLinks.joinToString(","),
            archived = archived,
            pinned = pinned,
            coverScale = first.imageScale.coerceIn(1f, 3.5f),
            coverOffsetX = first.imageOffsetX,
            coverOffsetY = first.imageOffsetY,
            coverAspectRatio = safeAspectRatio(first.imageAspectRatio),
            pages = pages.toList()
        )
    }

    fun saveAndExit() {
        keyboard?.hide()
        onSave(currentNote())
    }

    fun openImageAdjuster() {
        val page = currentPage()
        if (page.image.isBlank()) return
        pendingImageUri = page.image
        pendingScale = page.imageScale.coerceAtLeast(1f)
        pendingOffsetX = page.imageOffsetX
        pendingOffsetY = page.imageOffsetY
        pendingAspectRatio = safeAspectRatio(page.imageAspectRatio)
        imageAdjusting = true
    }

    fun confirmImageAdjustments() {
        val uri = pendingImageUri.orEmpty()
        updatePage(
            activePageIndex,
            currentPage().copy(
                image = uri,
                imageScale = pendingScale.coerceIn(1f, 4f),
                imageOffsetX = pendingOffsetX,
                imageOffsetY = pendingOffsetY,
                imageAspectRatio = safeAspectRatio(pendingAspectRatio)
            )
        )
        imageAdjusting = false
        pendingImageUri = null
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pendingImageUri = it.toString()
            pendingScale = 1f
            pendingOffsetX = 0f
            pendingOffsetY = 0f
            pendingAspectRatio = readImageAspectRatio(context, it)
            imageAdjusting = true
        }
    }

    LaunchedEffect(title, pages, selectedLinks, pinned, archived, imageAdjusting) {
        if (!imageAdjusting) {
            delay(650)
            val draft = currentNote()
            val hasContent = draft.title.isNotBlank() || draft.pages.any {
                it.body.isNotBlank() || it.image.isNotBlank()
            } || draft.links.isNotBlank()
            if (hasContent) onAutoSave(draft)
        }
    }

    BackHandler {
        if (imageAdjusting) {
            imageAdjusting = false
            pendingImageUri = null
        } else {
            saveAndExit()
        }
    }

    if (imageAdjusting && pendingImageUri != null) {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding().padding(horizontal = 18.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {
                    imageAdjusting = false
                    pendingImageUri = null
                }) { Text("Cancelar", color = Ink) }
                Text("Ajustar imagem", color = Ink, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = { confirmImageAdjustments() }) {
                    Text("Confirmar", color = Accent, fontWeight = FontWeight.Bold)
                }
            }
            Text("A imagem mantém sua proporção original. Arraste para reposicionar e ajuste o zoom.",
                color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                val desiredHeight = (maxWidth / safeAspectRatio(pendingAspectRatio)).coerceAtMost(maxHeight)
                CoverImage(
                    uri = pendingImageUri.orEmpty(),
                    scale = pendingScale,
                    offsetX = pendingOffsetX,
                    offsetY = pendingOffsetY,
                    modifier = Modifier.width(maxWidth).height(desiredHeight)
                        .clip(RoundedCornerShape(18.dp))
                        .pointerInput(pendingImageUri) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                pendingOffsetX = (pendingOffsetX + dragAmount.x / size.width.toFloat()).coerceIn(-1f, 1f)
                                pendingOffsetY = (pendingOffsetY + dragAmount.y / size.height.toFloat()).coerceIn(-1f, 1f)
                            }
                        }
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("Zoom", color = Ink, fontWeight = FontWeight.Medium)
            Slider(value = pendingScale, onValueChange = { pendingScale = it }, valueRange = 1f..4f)
            OutlinedButton(
                onClick = { imagePicker.launch(arrayOf("image/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Escolher outra imagem") }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        updatePage(activePageIndex, currentPage().copy(
                            image = "", imageScale = 1f, imageOffsetX = 0f,
                            imageOffsetY = 0f, imageAspectRatio = 1.7778f
                        ))
                        pendingImageUri = null
                        imageAdjusting = false
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Remover imagem") }
                Button(
                    onClick = { confirmImageAdjustments() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                ) { Text("Confirmar", fontWeight = FontWeight.Bold) }
            }
        }
    } else {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().imePadding()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { saveAndExit() }) { Text("←", color = Ink, fontSize = 28.sp) }
                Text(if (note.title.isBlank() && title.isBlank()) "Nova nota" else "Nota", color = Muted,
                    fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { pinned = !pinned }) {
                    Text(if (pinned) "📌" else "Fixar", color = if (pinned) Accent else Muted)
                }
                TextButton(onClick = { archived = !archived }) {
                    Text(if (archived) "Restaurar" else "Arquivar", color = Accent, fontSize = 12.sp)
                }
                TextButton(onClick = { saveAndExit() }) {
                    Text("✓", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Numbered internal pages. Each tab stores its own writing and image.
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pages.forEachIndexed { index, page ->
                    val isSelected = index == activePageIndex
                    Row(
                        Modifier.clip(RoundedCornerShape(11.dp))
                            .background(if (isSelected) Accent else CardRaised)
                            .clickable { activePageIndex = index }
                            .padding(start = 14.dp, end = if (pages.size > 1) 4.dp else 14.dp, top = 5.dp, bottom = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Text("${index + 1}", color = if (isSelected) Bg else Ink,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                        if (pages.size > 1) {
                            IconButton(
                                onClick = { pageIndexToDelete = index },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.Close,
                                    contentDescription = "Excluir página ${index + 1}",
                                    tint = if (isSelected) Bg else Muted,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
                Box(
                    Modifier.clip(RoundedCornerShape(11.dp)).background(Panel)
                        .clickable {
                            pages = pages + NotePage()
                            activePageIndex = pages.lastIndex
                        }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) { Text("+", color = Accent, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }

            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 22.dp).padding(bottom = 28.dp)
            ) {
                Spacer(Modifier.height(10.dp))
                val activePage = currentPage()
                if (activePage.image.isNotBlank()) {
                    CoverImage(
                        uri = activePage.image,
                        scale = activePage.imageScale,
                        offsetX = activePage.imageOffsetX,
                        offsetY = activePage.imageOffsetY,
                        modifier = Modifier.fillMaxWidth()
                            .aspectRatio(safeAspectRatio(activePage.imageAspectRatio))
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { openImageAdjuster() }
                    )
                } else {
                    OutlinedButton(
                        onClick = { imagePicker.launch(arrayOf("image/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("＋ Adicionar imagem nesta página") }
                }

                Spacer(Modifier.height(18.dp))
                BasicTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    decorationBox = { inner ->
                        Box {
                            if (title.isEmpty()) Text("Título", color = Muted, fontSize = 27.sp)
                            inner()
                        }
                    }
                )
                Spacer(Modifier.height(22.dp))
                BasicTextField(
                    value = activePage.body,
                    onValueChange = { text -> updatePage(activePageIndex, currentPage().copy(body = text)) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 360.dp),
                    textStyle = TextStyle(color = Ink, fontSize = 17.sp, lineHeight = 26.sp),
                    cursorBrush = SolidColor(Accent),
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Sentences,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Default
                    ),
                    decorationBox = { inner ->
                        Box {
                            if (activePage.body.isEmpty()) Text("Comece a escrever...", color = Muted, fontSize = 17.sp)
                            inner()
                        }
                    }
                )

                Spacer(Modifier.height(24.dp))
                HorizontalDivider(color = Color(0xFF333333))
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Link, contentDescription = null, tint = Muted, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("NOTAS RELACIONADAS", color = Muted, fontSize = 11.sp,
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${selectedLinks.size}", color = Accent, fontSize = 10.sp)
                }
                val relatedNotes = allNotes.filter { it.deletedAt <= 0L && it.id in selectedLinks }
                if (relatedNotes.isEmpty()) {
                    Text("Nenhuma nota relacionada. Na biblioteca, selecione duas fichas e use ‘Relacionar’.",
                        color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                } else {
                    relatedNotes.forEach { other ->
                        Row(
                            Modifier.fillMaxWidth().padding(top = 7.dp)
                                .clip(RoundedCornerShape(12.dp)).background(Panel)
                                .clickable { onOpenLinked(currentNote(), other.id) }
                                .padding(horizontal = 13.dp, vertical = 13.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(other.title.ifBlank { "Sem título" }, color = Ink,
                                modifier = Modifier.weight(1f), maxLines = 1)
                            Text("Abrir  ↗", color = Accent, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(Modifier.height(28.dp))
                Button(
                    onClick = { saveAndExit() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                ) { Text("Salvar nota", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    if (pageIndexToDelete >= 0) {
        val deletingPageNumber = pageIndexToDelete + 1
        AlertDialog(
            onDismissRequest = { pageIndexToDelete = -1 },
            title = { Text("Excluir página $deletingPageNumber?") },
            text = { Text("O conteúdo e a imagem desta página serão removidos. As outras páginas serão mantidas.") },
            confirmButton = {
                TextButton(onClick = {
                    val target = pageIndexToDelete
                    if (pages.size > 1 && target in pages.indices) {
                        pages = pages.toMutableList().also { it.removeAt(target) }
                        activePageIndex = when {
                            target < activePageIndex -> activePageIndex - 1
                            target == activePageIndex -> minOf(target, pages.lastIndex)
                            else -> activePageIndex
                        }.coerceIn(0, pages.lastIndex)
                    }
                    pageIndexToDelete = -1
                }) { Text("Excluir página", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { pageIndexToDelete = -1 }) { Text("Cancelar") } },
            containerColor = Panel,
            titleContentColor = Ink,
            textContentColor = Ink
        )
    }
}
