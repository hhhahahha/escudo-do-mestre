# ESCUDO DO MESTRE 1.6 🎲

Aplicativo Android pessoal de anotações para mestres de RPG.

## Novidades 1.6
- Barra de pesquisa compacta e tipografia geral um pouco menor.
- Abas de páginas fixas no topo enquanto o conteúdo da página rola.
- Toque numa aba para abrir a página; segure o número para confirmar a exclusão.
- Menu de três pontos no canto inferior esquerdo, acima do teclado: criar página, inserir imagem, fixar, arquivar e editar marcadores.
- Imagens inseridas na posição atual do cursor, entre blocos de texto, com largura e enquadramento definidos durante a inserção.
- Depois de inserida, a imagem não oferece redimensionamento; pressione a imagem para removê-la e insira novamente para escolher outro tamanho.
- Imagens em blocos também são incluídas nos backups ZIP.

## Compatibilidade
- applicationId: `br.com.escudodomestre`
- versionCode: 7
- versionName: 1.6
- Java 17 e Gradle 8.9.
