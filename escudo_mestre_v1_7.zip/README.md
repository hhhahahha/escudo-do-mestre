# ESCUDO DO MESTRE 1.7 🎲

Aplicativo Android pessoal de notas para mestres de RPG.

## Mudanças 1.7
- Campo de escrita único por página, corrigindo caixas vazias duplicadas.
- Imagens inseridas como elementos inline no texto usando ImageSpan, permitindo texto antes e depois na mesma linha.
- Toque longo em uma imagem inline abre ações para movê-la caractere a caractere para a esquerda/direita ou removê-la.
- Menu de três pontos ganhou opções para adicionar/trocar a imagem de capa da página e inserir imagem no texto.
- Notas relacionadas saíram do corpo da página e passaram para um botão de corrente acima do teclado, que abre uma lista em diálogo.
- Mantém o identificador do aplicativo e eleva versionCode para 8/versionName para 1.7.

## Compilar
A partir da raiz do projeto, execute `gradle assembleDebug` com JDK 17. O APK debug fica em `app/build/outputs/apk/debug/app-debug.apk`.
