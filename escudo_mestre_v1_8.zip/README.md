# ESCUDO DO MESTRE 1.8

Aplicativo Android pessoal de organização de notas para campanhas de RPG.

## Novidades 1.8
- Imagens inseridas no texto iniciam um parágrafo flutuante: as linhas seguintes reservam uma coluna ao lado da imagem enquanto ela ocupa altura, liberando a largura total abaixo dela.
- Novo seletor de aparência da nota.
- Três cores de papel: preto, branco e cinza.
- Três padrões: vazio, linhas e grade.
- Amostras visuais mostram as cores em círculos e os padrões em miniaturas antes da seleção.
- A aparência é compartilhada por todas as páginas numeradas da mesma nota e permanece salva.

## Compilar
O projeto usa Kotlin, Jetpack Compose e Gradle. No GitHub Actions, execute `gradle assembleDebug` com JDK 17.
