# ESCUDO DO MESTRE 1.9

Atualização corretiva do editor Android.

## Correções nesta versão
- Imagens inseridas no texto são desenhadas na margem esquerda do parágrafo por um `LeadingMarginSpan2`, usando uma âncora de largura zero. O texto pode usar a coluna livre à direita e depois retorna à largura completa abaixo da imagem.
- Linhas e grade são desenhadas dentro do próprio editor de texto, alinhadas às linhas de base reais do texto. O fundo não desenha mais a grade sobre o título e sobre outras áreas.
- Em papel pautado ou quadriculado, o espaçamento de linha do `EditText` usa o mesmo passo de 26 dp das guias, mantendo o texto assentado nas linhas.
- Mantém a estrutura de dados da versão 1.8 e atualiza `versionCode` para 10 e `versionName` para 1.9.

## Compilação
O fluxo GitHub Actions usa `gradle assembleDebug` e publica `app-debug.apk` como artefato.
