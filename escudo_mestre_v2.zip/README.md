# ESCUDO DO MESTRE 1.1 🎲

Atualização de usabilidade do aplicativo Android pessoal para organização de notas e fichas de RPG.

## Melhorias desta versão
- Editor de notas em tela inteira, sem janela flutuante.
- Campos de título e texto com estado Compose independente, corrigindo o problema de digitação.
- Salvamento automático após uma breve pausa ao escrever, além de salvar ao sair.
- Pesquisa em títulos, marcadores e conteúdo das notas.
- Gaveta lateral que abre por gesto da borda esquerda, com notas arquivadas e marcadores salvos.
- Marcadores reutilizáveis: crie uma vez e toque para aplicar em outras notas.
- Ligações reais entre notas por seleção de outras fichas, com ação para abrir a ficha conectada.
- Capa quadrada com ajuste de zoom e reposicionamento por arraste.
- Mantém o mesmo applicationId e o formato de dados anterior para permitir atualização preservando dados locais.

## Compilação
O workflow do GitHub Actions gera um APK de depuração ao receber um push na branch `main`.
