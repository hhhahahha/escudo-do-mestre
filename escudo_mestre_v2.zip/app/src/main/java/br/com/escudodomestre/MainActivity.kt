package br.com.escudodomestre

import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.UUID
import kotlin.math.max

private val Bg = Color(0xFF101010)
private val Panel = Color(0xFF191919)
private val Card = Color(0xFF202020)
private val CardRaised = Color(0xFF282828)
private val Ink = Color(0xFFF2F0EA)
private val Muted = Color(0xFFAAA69D)
private val Accent = Color(0xFFD6C9A8)
private val Danger = Color(0xFFE58A82)

/**
 * Keep the old field names and String representation for markers/links so notes
 * created by version 1.0 remain readable after updating the APK.
 */
data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val body: String = "",
    val cover: String = "",
    val markers: String = "",
    val links: String = "",
    val archived: Boolean = false,
    val pinned: Boolean = false,
    val coverScale: Float = 1f,
    val coverOffsetX: Float = 0f,
    val coverOffsetY: Float = 0f
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EscudoApp() }
    }
}

private fun splitValues(raw: String): List<String> = raw
    .split(',', '\n')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .distinctBy { it.lowercase() }

private fun parseIds(raw: String): Set<String> = raw
    .split(',')
    .map { it.trim() }
    .filter { it.isNotEmpty() }
    .toSet()

private fun safeScale(note: Note): Float = note.coverScale.takeIf { it >= 1f } ?: 1f

private fun applyCoverMatrix(view: ImageView, scale: Float, offsetX: Float, offsetY: Float) {
    val drawable = view.drawable ?: return
    val viewW = view.width.toFloat()
    val viewH = view.height.toFloat()
    val imageW = drawable.intrinsicWidth.toFloat()
    val imageH = drawable.intrinsicHeight.toFloat()
    if (viewW <= 0f || viewH <= 0f || imageW <= 0f || imageH <= 0f) return

    val fit = max(viewW / imageW, viewH / imageH)
    val finalScale = fit * scale.coerceAtLeast(1f)
    val drawnW = imageW * finalScale
    val drawnH = imageH * finalScale
    val tx = (viewW - drawnW) / 2f + offsetX * viewW
    val ty = (viewH - drawnH) / 2f + offsetY * viewH
    val matrix = Matrix().apply {
        setScale(finalScale, finalScale)
        postTranslate(tx, ty)
    }
    view.imageMatrix = matrix
}

@Composable
fun EscudoApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("escudo_notas", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }
    val noteType = remember { object : TypeToken<List<Note>>() {}.type }
    val markerType = remember { object : TypeToken<List<String>>() {}.type }

    val notes = remember {
        mutableStateListOf<Note>().apply {
            val loaded = runCatching {
                gson.fromJson<List<Note>>(prefs.getString("notes", "[]"), noteType)
            }.getOrNull().orEmpty()
            addAll(loaded.map { old ->
                // Older notes did not store cover adjustments or archive/pin state.
                old.copy(coverScale = safeScale(old))
            })
        }
    }
    val savedMarkers = remember {
        mutableStateListOf<String>().apply {
            val fromPrefs = runCatching {
                gson.fromJson<List<String>>(prefs.getString("saved_markers", "[]"), markerType)
            }.getOrNull().orEmpty()
            val fromNotes = notes.flatMap { splitValues(it.markers) }
            addAll((fromPrefs + fromNotes).distinctBy { it.lowercase() }.sortedBy { it.lowercase() })
        }
    }

    var search by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var showingArchived by remember { mutableStateOf(false) }
    var activeMarker by remember { mutableStateOf<String?>(null) }

    fun persist() {
        prefs.edit()
            .putString("notes", gson.toJson(notes))
            .putString("saved_markers", gson.toJson(savedMarkers))
            .apply()
    }

    fun registerMarker(value: String) {
        val clean = value.trim().removePrefix("#")
        if (clean.isNotEmpty() && savedMarkers.none { it.equals(clean, ignoreCase = true) }) {
            savedMarkers.add(clean)
            savedMarkers.sortBy { it.lowercase() }
            persist()
        }
    }

    fun saveNote(updated: Note) {
        splitValues(updated.markers).forEach { registerMarker(it) }
        val index = notes.indexOfFirst { it.id == updated.id }
        if (index >= 0) notes[index] = updated else notes.add(0, updated)
        persist()
    }

    fun deleteNote(id: String) {
        notes.removeAll { it.id == id }
        for (i in notes.indices) {
            val remaining = parseIds(notes[i].links).filterNot { it == id }
            notes[i] = notes[i].copy(links = remaining.joinToString(","))
        }
        persist()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg,
        surface = Card,
        surfaceVariant = CardRaised,
        primary = Accent,
        onPrimary = Bg,
        onBackground = Ink,
        onSurface = Ink,
        secondary = Muted
    )) {
        if (editingNote != null) {
            EditorScreen(
                note = editingNote!!,
                allNotes = notes.toList(),
                knownMarkers = savedMarkers.toList(),
                onRegisterMarker = ::registerMarker,
                onSave = { updated -> saveNote(updated); editingNote = null },
                onAutoSave = ::saveNote,
                onDelete = { id -> deleteNote(id); editingNote = null },
                onOpenLinked = { current, targetId ->
                    saveNote(current)
                    editingNote = notes.firstOrNull { it.id == targetId }?.copy()
                }
            )
        } else {
            NotesHome(
                notes = notes,
                knownMarkers = savedMarkers,
                search = search,
                onSearchChange = { search = it },
                showingArchived = showingArchived,
                onShowArchived = { showingArchived = true; activeMarker = null },
                onShowNotes = { showingArchived = false; activeMarker = null },
                activeMarker = activeMarker,
                onSelectMarker = { marker -> showingArchived = false; activeMarker = marker },
                onOpenNote = { editingNote = it.copy(coverScale = safeScale(it)) },
                onNewNote = { editingNote = Note() }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NotesHome(
    notes: List<Note>,
    knownMarkers: List<String>,
    search: String,
    onSearchChange: (String) -> Unit,
    showingArchived: Boolean,
    onShowArchived: () -> Unit,
    onShowNotes: () -> Unit,
    activeMarker: String?,
    onSelectMarker: (String) -> Unit,
    onOpenNote: (Note) -> Unit,
    onNewNote: () -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Panel,
                drawerContentColor = Ink
            ) {
                Column(
                    Modifier.fillMaxHeight().statusBarsPadding().padding(horizontal = 18.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Spacer(Modifier.height(20.dp))
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Organização do grimório", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(
                        value = search,
                        onValueChange = onSearchChange,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Pesquisar notas e palavras") },
                        shape = RoundedCornerShape(14.dp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
                    )
                    Spacer(Modifier.height(16.dp))
                    NavigationDrawerItem(
                        label = { Text("Todas as notas") },
                        selected = !showingArchived && activeMarker == null,
                        onClick = { onShowNotes(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    NavigationDrawerItem(
                        label = { Text("Arquivadas") },
                        selected = showingArchived,
                        onClick = { onShowArchived(); scope.launch { drawerState.close() } },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = CardRaised,
                            selectedTextColor = Accent,
                            unselectedTextColor = Ink
                        )
                    )
                    HorizontalDivider(color = Color(0xFF373737), modifier = Modifier.padding(vertical = 12.dp))
                    Text("MARCADORES SALVOS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (knownMarkers.isEmpty()) {
                        Text("Seus marcadores aparecerão aqui quando você criar o primeiro.", color = Muted, fontSize = 12.sp)
                    } else {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            knownMarkers.forEach { marker ->
                                FilterChip(
                                    selected = activeMarker == marker,
                                    onClick = { onSelectMarker(marker); scope.launch { drawerState.close() } },
                                    label = { Text("#${marker}", maxLines = 1) }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Text("Dica: deslize da borda esquerda para abrir este painel.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    ) {
        val filtered = notes
            .filter { it.archived == showingArchived }
            .filter { activeMarker == null || splitValues(it.markers).any { tag -> tag.equals(activeMarker, true) } }
            .filter {
                search.isBlank() || it.title.contains(search, true) ||
                    it.body.contains(search, true) || it.markers.contains(search, true)
            }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.title })

        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding()
                .navigationBarsPadding().padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { scope.launch { drawerState.open() } }, contentPadding = PaddingValues(8.dp)) {
                    Text("☰", color = Ink, fontSize = 25.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text("ESCUDO DO MESTRE", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Seu grimório de anotações", color = Muted, fontSize = 12.sp)
                }
                Text("◈ D20", color = Accent, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Pesquisar notas ou palavras dentro delas") },
                shape = RoundedCornerShape(15.dp),
                trailingIcon = {
                    if (search.isNotEmpty()) {
                        TextButton(onClick = { onSearchChange("") }) { Text("Limpar") }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search)
            )
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        when {
                            showingArchived -> "Arquivadas"
                            activeMarker != null -> "#${activeMarker}"
                            else -> "Minhas notas"
                        },
                        color = Ink, fontSize = 19.sp, fontWeight = FontWeight.SemiBold
                    )
                    Text("${filtered.size} notas", color = Muted, fontSize = 11.sp)
                }
                if (activeMarker != null || showingArchived) {
                    TextButton(onClick = onShowNotes) { Text("Ver todas", color = Accent) }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◈", color = Accent, fontSize = 42.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when {
                                search.isNotBlank() -> "Nenhuma nota encontrada"
                                showingArchived -> "Nada arquivado por enquanto"
                                activeMarker != null -> "Nenhuma nota com este marcador"
                                else -> "Seu escudo está pronto"
                            },
                            color = Ink, fontWeight = FontWeight.SemiBold
                        )
                        Text("Crie uma nota ou ajuste sua pesquisa.", color = Muted, fontSize = 12.sp)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 145.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { note ->
                        NoteCard(note = note, onClick = { onOpenNote(note) })
                    }
                }
            }
            Button(
                onClick = onNewNote,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text("+ Nova nota", fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 5.dp))
            }
        }
    }
}

@Composable
private fun NoteCard(note: Note, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column(Modifier.padding(9.dp)) {
            if (note.cover.isNotBlank()) {
                CoverImage(
                    uri = note.cover,
                    scale = safeScale(note),
                    offsetX = note.coverOffsetX,
                    offsetY = note.coverOffsetY,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                )
            } else {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp))
                        .background(Color(0xFF303030)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("◈ D20", color = Accent, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(note.title.ifBlank { "Sem título" }, color = Ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 2, modifier = Modifier.weight(1f))
                if (note.pinned) Text("📌", fontSize = 12.sp)
            }
            if (note.body.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(note.body, color = Muted, fontSize = 11.sp, maxLines = 2)
            }
            val tags = splitValues(note.markers).take(2)
            if (tags.isNotEmpty()) {
                Spacer(Modifier.height(7.dp))
                Text(tags.joinToString("  ") { "#${it}" }, color = Accent, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun CoverImage(
    uri: String,
    scale: Float,
    offsetX: Float,
    offsetY: Float,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { ctx -> ImageView(ctx).apply { scaleType = ImageView.ScaleType.MATRIX } },
        update = { view ->
            if (view.tag != uri) {
                runCatching { view.setImageURI(Uri.parse(uri)) }
                view.tag = uri
            }
            view.post { applyCoverMatrix(view, scale.coerceAtLeast(1f), offsetX, offsetY) }
        },
        modifier = modifier
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EditorScreen(
    note: Note,
    allNotes: List<Note>,
    knownMarkers: List<String>,
    onRegisterMarker: (String) -> Unit,
    onSave: (Note) -> Unit,
    onAutoSave: (Note) -> Unit,
    onDelete: (String) -> Unit,
    onOpenLinked: (Note, String) -> Unit
) {
    val context = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var title by remember(note.id) { mutableStateOf(note.title) }
    var body by remember(note.id) { mutableStateOf(note.body) }
    var coverUri by remember(note.id) { mutableStateOf(note.cover) }
    var coverScale by remember(note.id) { mutableFloatStateOf(safeScale(note)) }
    var coverOffsetX by remember(note.id) { mutableFloatStateOf(note.coverOffsetX) }
    var coverOffsetY by remember(note.id) { mutableFloatStateOf(note.coverOffsetY) }
    var selectedMarkers by remember(note.id) { mutableStateOf(splitValues(note.markers).toSet()) }
    var markerInput by remember(note.id) { mutableStateOf("") }
    var selectedLinks by remember(note.id) { mutableStateOf(parseIds(note.links)) }
    var pinned by remember(note.id) { mutableStateOf(note.pinned) }
    var archived by remember(note.id) { mutableStateOf(note.archived) }
    var showCoverTools by remember(note.id) { mutableStateOf(coverUri.isNotBlank()) }

    fun currentNote(): Note = note.copy(
        title = title.trim(),
        body = body,
        cover = coverUri,
        markers = selectedMarkers.joinToString(", "),
        links = selectedLinks.joinToString(","),
        archived = archived,
        pinned = pinned,
        coverScale = coverScale.coerceIn(1f, 3.5f),
        coverOffsetX = coverOffsetX,
        coverOffsetY = coverOffsetY
    )

    fun saveAndExit() {
        keyboard?.hide()
        onSave(currentNote())
    }

    // Autosave after a short pause while typing, so leaving the app will not
    // discard an unfinished note. The explicit Save button remains available.
    LaunchedEffect(title, body, coverUri, selectedMarkers, selectedLinks, pinned, archived, coverScale, coverOffsetX, coverOffsetY) {
        delay(650)
        val draft = currentNote()
        val hasContent = draft.title.isNotBlank() || draft.body.isNotBlank() ||
            draft.cover.isNotBlank() || draft.markers.isNotBlank() || draft.links.isNotBlank()
        if (hasContent) onAutoSave(draft)
    }

    BackHandler { saveAndExit() }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            coverUri = it.toString()
            showCoverTools = true
            coverScale = 1f
            coverOffsetX = 0f
            coverOffsetY = 0f
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding()
            .navigationBarsPadding().imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { saveAndExit() }) { Text("←", color = Ink, fontSize = 28.sp) }
            Text(if (note.title.isBlank() && title.isBlank()) "Nova nota" else "Nota", color = Muted,
                fontSize = 13.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { pinned = !pinned }) {
                Text(if (pinned) "📌" else "Fixar", color = if (pinned) Accent else Muted)
            }
            TextButton(onClick = { archived = !archived }) {
                Text(if (archived) "Restaurar" else "Arquivar", color = Accent, fontSize = 12.sp)
            }
            TextButton(onClick = { saveAndExit() }) {
                Text("✓", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp).padding(bottom = 28.dp)
        ) {
            Spacer(Modifier.height(22.dp))
            BasicTextField(
                value = title,
                onValueChange = { title = it },
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Medium),
                cursorBrush = SolidColor(Accent),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next
                ),
                decorationBox = { inner ->
                    Box {
                        if (title.isEmpty()) Text("Título", color = Muted, fontSize = 27.sp)
                        inner()
                    }
                }
            )
            Spacer(Modifier.height(22.dp))
            BasicTextField(
                value = body,
                onValueChange = { body = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp),
                textStyle = TextStyle(color = Ink, fontSize = 17.sp, lineHeight = 26.sp),
                cursorBrush = SolidColor(Accent),
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Default
                ),
                decorationBox = { inner ->
                    Box {
                        if (body.isEmpty()) Text("Nota", color = Muted, fontSize = 17.sp)
                        inner()
                    }
                }
            )

            Spacer(Modifier.height(24.dp))
            HorizontalDivider(color = Color(0xFF333333))
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("CAPA", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { showCoverTools = !showCoverTools }) {
                    Text(if (showCoverTools) "Ocultar ajustes" else "Adicionar / ajustar", color = Accent)
                }
            }
            if (showCoverTools) {
                if (coverUri.isNotBlank()) {
                    CoverImage(
                        uri = coverUri,
                        scale = coverScale,
                        offsetX = coverOffsetX,
                        offsetY = coverOffsetY,
                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                            .pointerInput(coverUri) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    coverOffsetX = (coverOffsetX + dragAmount.x / size.width.toFloat()).coerceIn(-0.8f, 0.8f)
                                    coverOffsetY = (coverOffsetY + dragAmount.y / size.height.toFloat()).coerceIn(-0.8f, 0.8f)
                                }
                            }
                    )
                    Text("Arraste a imagem para reposicionar.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 7.dp))
                    Text("Zoom", color = Ink, fontSize = 13.sp)
                    Slider(value = coverScale, onValueChange = { coverScale = it }, valueRange = 1f..3.5f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Text("Trocar imagem") }
                        OutlinedButton(onClick = { coverUri = ""; coverScale = 1f; coverOffsetX = 0f; coverOffsetY = 0f }, modifier = Modifier.weight(1f)) { Text("Remover capa") }
                    }
                } else {
                    OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Escolher imagem da galeria")
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            HorizontalDivider(color = Color(0xFF333333))
            Spacer(Modifier.height(16.dp))
            Text("MARCADORES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (knownMarkers.isNotEmpty()) {
                Text("Toque para adicionar ou remover desta nota", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(7.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    knownMarkers.forEach { marker ->
                        FilterChip(
                            selected = selectedMarkers.any { it.equals(marker, true) },
                            onClick = {
                                selectedMarkers = if (selectedMarkers.any { it.equals(marker, true) }) {
                                    selectedMarkers.filterNot { it.equals(marker, true) }.toSet()
                                } else selectedMarkers + marker
                            },
                            label = { Text("#${marker}") }
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = markerInput,
                    onValueChange = { markerInput = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("Novo marcador") },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = {
                        val tag = markerInput.trim().removePrefix("#")
                        if (tag.isNotEmpty()) {
                            onRegisterMarker(tag)
                            selectedMarkers = selectedMarkers + tag
                            markerInput = ""
                        }
                    })
                )
                Button(onClick = {
                    val tag = markerInput.trim().removePrefix("#")
                    if (tag.isNotEmpty()) {
                        onRegisterMarker(tag)
                        selectedMarkers = selectedMarkers + tag
                        markerInput = ""
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)) { Text("Adicionar") }
            }
            if (selectedMarkers.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("Nesta nota: ${selectedMarkers.joinToString("  ") { "#${it}" }}", color = Accent, fontSize = 12.sp)
            }

            Spacer(Modifier.height(22.dp))
            HorizontalDivider(color = Color(0xFF333333))
            Spacer(Modifier.height(16.dp))
            Text("CONEXÕES ENTRE NOTAS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Selecione outras notas para criar ligações entre suas fichas.", color = Muted, fontSize = 11.sp,
                modifier = Modifier.padding(top = 5.dp, bottom = 9.dp))
            val candidates = allNotes.filter { it.id != note.id && !it.archived }
            if (candidates.isEmpty()) {
                Text("Crie outra nota para começar a fazer conexões.", color = Muted, fontSize = 12.sp)
            } else {
                candidates.forEach { other ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = selectedLinks.contains(other.id),
                            onCheckedChange = { checked ->
                                selectedLinks = if (checked) selectedLinks + other.id else selectedLinks - other.id
                            },
                            colors = CheckboxDefaults.colors(checkedColor = Accent, checkmarkColor = Bg)
                        )
                        Text(other.title.ifBlank { "Sem título" }, color = Ink, modifier = Modifier.weight(1f), maxLines = 1)
                        TextButton(onClick = { onOpenLinked(currentNote(), other.id) }) { Text("Abrir", color = Accent, fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(5.dp))
                }
            }

            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { onDelete(note.id) }, modifier = Modifier.weight(1f)) {
                    Text("Excluir", color = Danger)
                }
                Button(
                    onClick = { saveAndExit() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Bg)
                ) { Text("Salvar nota", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
